//Check sign up form
function checkemail() {
    var infem = document.getElementById('signup_username');
    var infem_i = document.getElementById('signup_username_i');
    val = infem.value;
    if (/^\w+([-+.]\w+)*@\w+([-.]\w+)*\.\w+([-.]\w+)*$/.test(val)) {
        infem_i.innerHTML = "";
        return true;
    } else {
        infem_i.innerHTML = "<font color=red>   Please enter a valid email address!</font> ";
        return false;
    }
}
//Check the length of password
function checkpassword() {
    var infpwd = document.getElementById('signup_password');
    var infpwd_i = document.getElementById('signup_password_i');
    val = infpwd.value;
    console.log(val === '')
    if (val === '') {
        infpwd_i.innerHTML = "<font color=red>    Please input password！</font> ";
        return false;
    }
    if (val.length < 6) {
        infpwd_i.innerHTML = " <font color=red>  Password must include minimum 6 characters！</font>";
        return false;
    } else {
        infpwd_i.innerHTML = "You can use this password!";
        return true;
    }
}
//Check if the passwords entered twice are the same
function checkconfirmpassword() {
    var infpwd = document.getElementById('signup_password');
    val1 = infpwd.value;
    var infrepwd = document.getElementById('signup_confirmpassword');
    val2 = infrepwd.value;
    var repeatpsw_i = document.getElementById('signup_confirmpassword_i');
    if (val2 === '') {
        repeatpsw_i.innerHTML = " <font color=red>Please confirm password！</font>";
        return false;
    }
    if (val1 !== val2) {
        repeatpsw_i.innerHTML = " <font color=red>The two passwords you entered were inconsistent！</font>";
        return false;
    } else {
        repeatpsw_i.innerHTML = " Please remember your password！";
        return true;
    }
}

//Check the length of password
function checkeditpassword() {
    var infpwd = document.getElementById('edit_password');
    var infpwd_i = document.getElementById('edit_password_i');
    val = infpwd.value;
    console.log(val === '')
    if (val === '') {
        infpwd_i.innerHTML = "   Please input password！ ";
        return false;
    }
    if (val.length < 6) {
        infpwd_i.innerHTML = "  <font color=red> Password must include minimum 6 characters！</font>";
        return false;
    } else {
        infpwd_i.innerHTML = "You can use this password!";
        return true;
    }
}
//Check if the passwords entered twice are the same
function checkeditconfirmpassword() {
    var infpwd = document.getElementById('edit_password');
    val1 = infpwd.value;
    var infrepwd = document.getElementById('edit_confirmpassword');
    val2 = infrepwd.value;
    var repeatpsw_i = document.getElementById('edit_confirmpassword_i');
    if (val2 === '') {
        repeatpsw_i.innerHTML = " Please confirm password！";
        return false;
    }
    if (val1 !== val2) {
        repeatpsw_i.innerHTML = " The two passwords you entered were inconsistent！";
        return false;
    } else {
        repeatpsw_i.innerHTML = " Please remember your password！";
        return true;
    }
}

function $(id) {
    return document.getElementById(id);
}

function check_form() {
    var username = document.getElementById("signup_username").value;
    var password = document.getElementById("signup_password").value;
    var confirm_password = document.getElementById("signup_confirmpassword").value;
    var firstname = document.getElementById("signup_firstname").value;
    var lastname = document.getElementById("signup_lastname").value;
    var reg = new RegExp("^[a-z0-9]+([._\\-]*[a-z0-9])*@([a-z0-9]+[-a-z0-9]*[a-z0-9]+.){1,63}[a-z0-9]+$"); //Verify the email address
    var phone= document.getElementById("signup_phone").value;


    if (!reg.test(username)) {
        alert("Please input an available email address!!");
        return false;
    }
    if (password.length < 6) {
        alert("Please enter 6 digital password!!");
        return false;
    }
    if (password != confirm_password) {
        alert("The passwords are not match, Please enter again");
        return false;
    }
    if (firstname.length == 0) {
        alert("Please enter the first name!");
        return false;
    }
    if (lastname.length == 0) {
        alert("Please enter the last name!");
        return false;
    }
    if (phone.length == 0) {
        alert("Please enter the right phone number!");
        return false;
    }

    return true;

}

function check_reset(){
    var password = document.getElementById("new_password").value;
    var confirm_password = document.getElementById("confirm_newpassword").value;


    if (password.length < 6) {
        alert("Please enter 6 digital password!!");
        return false;
    }
    if (password != confirm_password) {
        alert("The passwords are not match, Please enter again");
        return false;
    }
    return true;
}