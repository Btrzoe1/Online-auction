<!DOCTYPE html>
<html>
<body>
<!-- navbar-->

<?php require_once "header.php";
    require_once "../Database/database.php";
    $dbh=connectDBPDO();
    $statement=$dbh->query("select count(*) from User");
    $row=$statement->fetch(PDO::FETCH_ASSOC);
    $statement1=$dbh->query("select count(*) from Auction WHERE auction_status='available'");
    $row1=$statement1->fetch(PDO::FETCH_ASSOC);

    $page=$dbh->query("SELECT date,times FROM Pageview ORDER BY pageview_id DESC LIMIT 7 ");
    $result=$page->fetchAll(PDO::FETCH_ASSOC);
    $day1=$result[0]['date'];   $times1=$result[0]['times'];
    $day2=$result[1]['date'];   $times2=$result[1]['times'];
    $day3=$result[2]['date'];   $times3=$result[2]['times'];
    $day4=$result[3]['date'];   $times4=$result[3]['times'];
    $day5=$result[4]['date'];   $times5=$result[4]['times'];
    $day6=$result[5]['date'];   $times6=$result[5]['times'];
    $day7=$result[6]['date'];   $times7=$result[6]['times'];

?>
    <div class="page-holder w-100 d-flex flex-wrap">
        <div class="container-fluid px-xl-5">
            <section class="py-5">
                <div class="row">
                    <div class="col-xl-3 col-lg-6 mb-4 mb-xl-0">
                        <div class="bg-white shadow roundy p-4 h-100 d-flex align-items-center justify-content-between">
                            <div class="flex-grow-1 d-flex align-items-center">
                                <div class="dot mr-3 bg-violet"></div>
                                <div class="text">
                                    <h6 class="mb-0">Users amount</h6><span class="text-gray"><?php echo $row['count(*)'] ?></span>
                                </div>
                            </div>
                            <div class="icon text-white bg-violet"><i class="fas fa-server"></i></div>
                        </div>
                    </div>
                    <div class="col-xl-3 col-lg-6 mb-4 mb-xl-0">
                        <div class="bg-white shadow roundy p-4 h-100 d-flex align-items-center justify-content-between">
                            <div class="flex-grow-1 d-flex align-items-center">
                                <div class="dot mr-3 bg-green"></div>
                                <div class="text">
                                    <h6 class="mb-0">Available auction amount</h6><span class="text-gray"><?php echo $row1['count(*)'] ?></span>
                                </div>
                            </div>
                            <div class="icon text-white bg-green"><i class="far fa-clipboard"></i></div>
                        </div>
                    </div>
                    <div class="col-lg-12 mb-5">
                        <div class="card">
                            <div class="card-header">
                                <h2 class="h6 text-uppercase mb-0">PV(Page View) over the past 7 days </h2>
                            </div>
                            <div class="card-body">
                                <div id="container" style="height: 350%"></div>
                            </div>
                        </div>
                    </div>
                </div>
            </section>
            <section class="py-5">
                <div class="row">
                    <table id="tbody">

                    </table>
                </div>
            </section>
        </div>
    </div>
</body>
<script type="text/javascript" src="http://echarts.baidu.com/gallery/vendors/echarts/echarts.min.js"></script>
<script type="text/javascript">
    var dom = document.getElementById("container");
    var myChart = echarts.init(dom);
    var day7='<?php echo $day1 ?>';   var times7='<?php echo $times1 ?>';
    var day6='<?php echo $day2 ?>';   var times6='<?php echo $times2 ?>';
    var day5='<?php echo $day3 ?>';   var times5='<?php echo $times3 ?>';
    var day4='<?php echo $day4 ?>';   var times4='<?php echo $times4 ?>';
    var day3='<?php echo $day5 ?>';   var times3='<?php echo $times5 ?>';
    var day2='<?php echo $day6 ?>';   var times2='<?php echo $times6 ?>';
    var day1='<?php echo $day7 ?>';   var times1='<?php echo $times7 ?>';
    var app = {};
    option = null;
    option = {
        tooltip: {
            trigger: 'axis'
        },
        legend: {
            data:['PV(Page View)']
        },
        toolbox: {
            show: true,
            feature: {
                dataZoom: {
                    yAxisIndex: 'none'
                },
                dataView: {readOnly: false},
                magicType: {type: ['line', 'bar']},
                restore: {},
                saveAsImage: {}
            }
        },
        xAxis:  {
            type: 'category',
            boundaryGap: false,
            data: [day1,day2,day3,day4,day5,day6,day7]
        },
        yAxis: {
            type: 'value',
            axisLabel: {
                formatter: '{value}'
            }
        },
        series: [
            {
                type:'line',
                data:[times1, times2, times3, times4, times5, times6, times7],
                lineStyle: {
                    normal: {
                        width: 3,
                    }
                },
                markLine: {
                    data: [
                        {type: 'average', name: '平均值'}
                    ]
                }
            }
        ]
    };
    if (option && typeof option === "object") {
        myChart.setOption(option, true);
    }

    window.onload=function(){
        $.ajax({
            url: "Back-end/Manage_user.php",
            type:"post",
            data:{
                type:'authentication'
            },
            dataType:"json",
            success: function (data) {
                var html = "";
                data.forEach(function (data, index, array) {
                html += `
                        <div class="col-lg-12"><a class="message card px-5 py-3 mb-4 bg-hover-gradient-primary no-anchor-style">
                            <div class="row">
                                <div class="col-lg-3 d-flex align-items-center flex-column flex-lg-row text-center text-md-left"><strong class="h5 mb-0">Id: </strong><strong class="h5 mb-0">${data.user_id} </strong><img src="${data.id_card}" alt="Id card" style="padding:10px; max-width: 8rem">
                                    <h6 class="mb-0">${data.firstname} </h6>
                                    <h6 class="mb-0">${data.lastname}</h6>
                                </div>
                                <div class="col-lg-9 d-flex align-items-center flex-column flex-lg-row text-center text-md-left">
                                    <input type="button" class="bg-gray-100 roundy px-4 py-1 mr-0 mr-lg-3 mt-2 mt-lg-0 text-dark exclode" data-id='${data.user_id}' data-type='activate' value="Verify">
                                    <p class="mb-0 mt-3 mt-lg-0">Click the 'verify' button to activate the user account, and this operation cannot be revoked. Please check the user's ID card carefully.</p>
                                </div>
                            </div></a></div>`
                })
                $('#tbody').html(html);
            }
        })
    }

    $('#tbody').click(function (e) {
        let type = $(e.target).attr("data-type");
        let id = $(e.target).attr("data-id");
        if (type === 'activate' && id) {
            var gnl=confirm("Confirm to activate this user account?");
            if (gnl==true){
                $.ajax({
                    url: "Back-end/Manage_user.php",
                    type:"post",
                    data:{
                        id:id,
                        type:'activate'
                    },
                    dataType:"json",
                    success: function (data) {
                        alert('Activate successfully!');
                        window.location.reload();
                    },
                })
            }else{
                return false;
            }
        }
    })
    </script>
</html>