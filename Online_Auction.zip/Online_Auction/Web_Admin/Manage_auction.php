
<!DOCTYPE html>
<html>
<body>
<!-- navbar-->
<?php require_once "header.php";
?>
<div class="page-holder w-100 d-flex flex-wrap">
    <div class="container-fluid px-xl-5">
        <section class="py-5">
            <div class="row">
                <div class="col-lg-12 mb-5">
                    <div class="card">
                        <div class="card-header">
                            <div class="card-tools">
                                <div class="input-group input-group-sm" >
                                    <input type="text" style="width: 40%;float: right" id="searchInput" placeholder="Auction id/product name">
                                    <span class="input-group-append"><button type="button" id="get"  class="btn btn-primary">Search</button>
                                        <button type="button" class="btn btn-success btn-sm" data-toggle="modal" data-target="#addModal">Add new auction</button></span>
                                </div>
                            </div>
                        </div>
                        <div class="card-body">
                            <table class="table card-text">
                                <thead>
                                <tr>
                                    <th>Product Name</th>
                                    <th>Picture</th>
                                    <th>Auction time</th>
                                    <th>Auction type</th>
                                    <th>Description</th>
                                    <th>Operation</th>
                                </tr>
                                </thead>
                                <tbody id="tbody">
                                </tbody>
                            </table>
                        </div>
                        <!-- edit auction start -->
                        <div class="modal fade" id="editModal" tabindex="-1" role="dialog" aria-labelledby="editModalLabel">
                            <div class="modal-dialog" role="document">
                                <div class="modal-content">
                                    <div class="modal-header">
                                        <h4 class="modal-title" id="editModalLabel">Edit Auction</h4>
                                    </div>
                                    <div class="modal-body">
                                        <form role="form">
                                            <input type="hidden" id="editId" class="form-control">
                                            <p>Auction type:
                                            <div>
                                                <input id="edittype" type="radio" name="edittype" style="margin-right: 5px" value="English auction" checked="checked">English auction
                                                <input id="edittype" type="radio" name="edittype" style="margin-right: 5px" value="Dutch auction" >Dutch auction
                                                <input id="edittype" type="radio" name="edittype" style="margin-right: 5px" value="Repeated second-bid auction" >Repeated second-bid auction
                                            </div></p>
                                            <div class="email-w3ls">
                                                <p>Start time: <input type="datetime-local" id="editstarttime" class="form-control" required=""></p>
                                            </div>
                                            <div class="email-w3ls">
                                                <p>End time: <input type="datetime-local" id="editendtime" class="form-control" required=""></p>
                                            </div>
                                            <div class="email-w3ls">
                                                <p>Product name: <input type="text" id="editproductname" class="form-control" required=""></p>
                                            </div>
                                            <div class="email-w3ls">
                                                <p>Product description: <input type="text" id="editdescription" class="form-control" required=""></p>
                                            </div>
                                            <div class="w3ls-password">
                                                <p>Product prcture: <input type="file" class="form-control" id="editpicture" name="Fimage" required="">
                                                <div id="image" style="height:100px;width:100px;"><img height="90px" src="" ></div></p>
                                            </div>
                                            <div>
                                                <p><input type="button" class="btn btn-danger" data-dismiss="modal" value="Cancel">
                                                    <input type="button" id="editDataBtn" class="btn btn-success" value="Submit" /></p>
                                            </div>
                                        </form>
                                    </div>
                                </div>
                            </div>
                        </div>
                        <!-- edit auction end -->
                        <!-- add auction start -->
                        <div class="modal fade" id="addModal" tabindex="-1" role="dialog" aria-labelledby="addModalLabel">
                            <div class="modal-dialog" role="document">
                                <div class="modal-content">
                                    <div class="modal-header">
                                        <h4 class="modal-title" id="addModalLabel">Add New Auction</h4>
                                    </div>
                                    <div class="modal-body">
                                        <form action="Back-end/Manage_auction.php" method="post" role="form" enctype="multipart/form-data">
                                            <input type="hidden" name="type" value="add" class="form-control">
                                            <input type="hidden" name="user_id" value="<?php echo $_SESSION['User']['user_id'] ?>" class="form-control">

                                            <p>Auction type:
                                            <div>
                                                <input type="radio" name="auction_type" style="margin-right: 5px" value="English auction" checked="checked">English auction
                                                <input type="radio" name="auction_type" style="margin-right: 5px" value="Dutch auction" >Dutch auction
                                                <input type="radio" name="auction_type" style="margin-right: 5px" value="Repeated second-bid auction" >Repeated second-bid auction
                                            </div></p>
                                            <div style="float:left; width:48%;margin-right: 4%">
                                                <p>Start time: <input type="datetime-local" name="add_auction_starttime" class="form-control" required=""></p>
                                            </div>
                                            <div style="float:left; width:48%">
                                                <p>End time: <input type="datetime-local" name="add_auction_endtime" class="form-control" required=""></p>
                                            </div>
                                            <div style="float:left; width:52%">
                                                <p>Product name:</p><input type="text" style="width:90%;" name="add_auction_name" class="form-control" required="">
                                            </div>
                                            <div style="float:left; width:48%">
                                                <label style="margin-right: 50px" >Product type:</label>
                                                <select style="height: 36px;margin-top: 10px" name="add_product_type">
                                                    <option value="All Categories">All Categories</option>
                                                    <option value="Electronics">Electronics</option>
                                                    <option value="Appliances">Appliances</option>
                                                    <option value="Fashion">Fashion</option>
                                                    <option value="Sports">Sports</option>
                                                    <option value="Beauty">Beauty</option>
                                                    <option value="Health">Health</option>
                                                    <option value="Kids">Kids</option>
                                                    <option value="Accessories">Accessories</option>
                                                </select>
                                            </div>
                                            <div class="email-w3ls">
                                                <p>Auction starting price: <input type="text" name="add_auction_price" class="form-control" required=""></p>
                                            </div>
                                            <div class="email-w3ls">
                                                <p>Product description: <input type="text" name="add_auction_description" class="form-control" required=""></p>
                                            </div>
                                            <div class="email-w3ls">
                                                <p>Product prcture: <input type="file" class="form-control" id="add_auction_picture" name="addFimage" required="">
                                                <div id="addimage" style="height:100px;width:100px;"><img height="90px" src="" ></div></p>
                                            </div>
                                            <div>
                                                <p><input type="button" class="btn btn-danger" data-dismiss="modal" value="Cancel">
                                                    <input type="submit" name="addDataBtn" class="btn btn-success" value="Submit" /></p>
                                            </div>
                                        </form>
                                    </div>
                                </div>
                            </div>
                        </div>
                        <!-- add auction end -->
                    </div>
                </div>
            </div>
        </section>
    </div>
</div>
<script>
    // Show edited product picture.
    document.getElementById('editpicture').onchange = function() {
        var imgFile = this.files[0];
        var fr = new FileReader();
        fr.onload = function() {
            document.getElementById('image').getElementsByTagName('img')[0].src = fr.result;
        };
        fr.readAsDataURL(imgFile);
    };
</script>
<script>
    // Show added product picture.
    document.getElementById('add_auction_picture').onchange = function() {
        var imgFile = this.files[0];
        var fr = new FileReader();
        fr.onload = function() {
            document.getElementById('addimage').getElementsByTagName('img')[0].src = fr.result;
        };
        fr.readAsDataURL(imgFile);
    };
</script>
<script>
    var web = {
        init: function () {
            this.getAll();
            this.eleBind();
        },
        eleBind: function () {

            $('#tbody').click(function (e) {
                let type = $(e.target).attr("data-type")
                let id = $(e.target).attr("data-id")
                if (type === 'del' && id) {
                    var gnl=confirm("Confirm to delete this user?");
                    if (gnl==true){
                        web.delDate(id);
                    }else{
                        return false;
                    }
                }else if(type === 'edit' && id){
                    $('#editId').val(id);
                }
            })
            $('#get').click(function(){
                var name=$('#searchInput').val();
                data={
                    name:name,
                }
                web.getData(data);
            })
            // Edit auction information
            $('#editDataBtn').click(function() {
                var editid = $("#editId").val();
                var edittype = $("#edittype").val();
                var editstarttime=$("#editstarttime").val();
                var editendtime = $("#editendtime").val();
                var editproductname = $("#editproductname").val();
                var editdescription = $("#editdescription").val();
                var file = document.getElementById('editpicture').files[0];
                var formData = new FormData();
                formData.append('editid',editid);
                formData.append('edittype',edittype);
                formData.append('editstarttime',editstarttime);
                formData.append('editendtime',editendtime);
                formData.append('editproductname',editproductname);
                formData.append('editdescription',editdescription);
                formData.append('file',file);
                formData.append('type','edit');
                $.ajax({
                    url: "Back-end/Manage_auction.php",
                    data:formData,
                    type: "post",
                    processData: false,
                    contentType: false,
                    datatype: "json",
                    success: function(data) {
                        alert("Success edit auction information!");
                        $('#editModal').modal('hide');
                        window.location.reload();
                    }
                });

            })
        },
        // Get all auctions.
        getAll: function () {
            $.ajax({
                url: "Back-end/Manage_auction.php",
                type: "post",
                data: {
                    type:'get'
                },
                datatype: 'json',
                success: function (data) {
                    web.setData(data);
                },
            })
        },
        // Search auction information.
        getData: function (data) {
            $.ajax({
                url: "Back-end/Manage_auction.php",
                type: "post",
                data: {
                    name:data.name,
                    type:'get'
                },
                datatype: 'json',
                success: function (data) {
                    web.setData(data);
                },
                error: function(){
                }
            })
        },
        // Delete auction by id
        delDate: function(id) {
            $.ajax({
                url: "Back-end/Manage_auction.php",
                type: "post",
                data: {
                    auction_id: id,
                    type: 'del'
                },
                datatype: "json",
                success: function(data) {
                    alert('Delete successfully!');
                    web.getAll();
                }
            })
        },
        // Show auction information.
        setData: function (data) {
            var html = "";
            data.forEach(function (data, index, array) {
                html += `
                        <tr>
                            <td scope="row"> ${data.product_name}</td>
                            <td><img height="100vw" width="100vw" src=${data.picture}></td>
                            <td>${data.start_time} To ${data.end_time}</td>
                            <td>${data.auction_type}</td>
                            <td>${data.description}</td>
                            <td type="edit">
                                <button data-type='edit' data-id='${data.auction_id}'  class="btn btn-primary" data-toggle="modal" data-target="#editModal">Edit</button>
                                <button data-type='del' data-id='${data.auction_id}' class="btn btn-danger" >Delete</button>
                            </td>
                        </tr>`
            })
            $('#tbody').html(html);
        }
    }

    $(document).ready(function () {
        web.init()
    })

</script>