<!DOCTYPE html>
<html>
  <body>
  <head>
      <meta charset="utf-8">
      <meta http-equiv="X-UA-Compatible" content="IE=edge">
      <title>Home</title>
      <meta name="description" content="">
      <meta name="viewport" content="width=device-width, initial-scale=1">
      <meta name="robots" content="all,follow">
      <!-- Bootstrap CSS-->
      <link rel="stylesheet" href="css/bootstrap.min.css">
      <!-- Font Awesome CSS-->
      <link rel="stylesheet" href="https://use.fontawesome.com/releases/v5.3.1/css/all.css" integrity="sha384-mzrmE5qonljUremFsqc01SB46JvROS7bZs3IO2EmfFsd15uHvIt+Y8vEf7N7fWAU" crossorigin="anonymous">
      <!-- Google fonts - Popppins for copy-->
      <link rel="stylesheet" href="css/orionicons.css">
      <!-- theme stylesheet-->
      <link rel="stylesheet" href="css/style.default.css" id="theme-stylesheet">
  </head>

  <script src="../js/vendor/jquery-1.11.3.min.js"></script>
  <script src="../js/bootstrap.min.js"></script>
  <script src="js/Chart.min.js"></script>
  <script src="js/front.js"></script>
  <?php
  session_start();
  ?>
  <header class="header">
      <nav class="navbar navbar-expand-lg px-4 py-2 bg-white shadow"><a href="#" class="sidebar-toggler text-gray-500 mr-4 mr-lg-5 lead"><i class="fas fa-align-left"></i></a><a href="index.html" class="navbar-brand font-weight-bold text-uppercase text-base">E-auction | Management</a>
          <ul class="ml-auto d-flex align-items-center list-unstyled mb-0">
              <?php
              if (!empty($_SESSION['User'])) {
                  echo "<li class=\"nav-item dropdown ml-auto\">" ."<a data-toggle='collapse' aria-expanded='false' class='dropdown-toggle'>"."Hi,". $_SESSION['User']['firstname'] ."</a>". "</li>";
              }
              ?>
              <li class="nav-item dropdown ml-auto"><a id="userInfo" href="http://example.com" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false" class="nav-link dropdown-toggle"></a>
              </li>
          </ul>
      </nav>
  </header>
  <div class="d-flex align-items-stretch">
      <div id="sidebar" class="sidebar py-3">
          <div class="text-gray-400 text-uppercase px-3 px-lg-4 py-4 font-weight-bold small headings-font-family">E-auction</div>
          <ul class="sidebar-menu list-unstyled">
              <li class="sidebar-list-item"><a href="index.html" class="sidebar-link text-muted active"><i class="o-home-1 mr-3 text-gray"></i><span>Home</span></a></li>
              <li class="sidebar-list-item"><a href="charts.html" class="sidebar-link text-muted"><i class="o-sales-up-1 mr-3 text-gray"></i><span>Manage User</span></a></li>
              <li class="sidebar-list-item"><a href="tables.html" class="sidebar-link text-muted"><i class="o-table-content-1 mr-3 text-gray"></i><span>Manage Auction</span></a></li>
              <li class="sidebar-list-item"><a href="forms.html" class="sidebar-link text-muted"><i class="o-survey-1 mr-3 text-gray"></i><span>Forms</span></a></li>
              <li class="sidebar-list-item"><a href="Back-end/Log_out.php" class="sidebar-link text-muted"><i class="o-exit-1 mr-3 text-gray"></i><span>Log out</span></a></li>
          </ul>
      </div>

      <div class="page-holder d-flex align-items-center">
      <div class="container">
        <div class="row align-items-center py-5">
          <div class="col-5 col-lg-7 mx-auto mb-5 mb-lg-0">
          </div>
          <div class="col-lg-5 px-lg-4">
            <h2 class="mb-4">Welcome back!</h2>
            <p class="text-muted">This Management System is for administrators of E-auction to manage data. Please login with your admin account. </p>
            <form id="loginForm" action="Back-end/Login_verify.php" method="post" class="mt-4">
              <div class="form-group mb-4">
                <input type="text" name="email" placeholder="Email" class="form-control border-0 shadow form-control-lg">
              </div>
              <div class="form-group mb-4">
                <input type="password" name="password" placeholder="Password" class="form-control border-0 shadow form-control-lg text-violet">
              </div>
              <button type="submit" class="btn btn-primary shadow px-5">Log in</button>
            </form>
          </div>
        </div>
      </div>
    </div>
  </body>
</html>