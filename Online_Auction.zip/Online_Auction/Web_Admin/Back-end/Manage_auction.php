<?php
require_once '../../Database/database.php';
$type = addslashes(htmlspecialchars(@$_POST['type']));
if ($type=='get') {
    get();
}else if($type=='del'){
    del();
}else if($type=='edit'){
    edit();
}else{
    add();
}

function get(){
    header("content-type:application/json;charset=utf-8");
    $name=@$_POST['name'];
    if($name){
        $dbh = connectDBPDO();
        $statement = $dbh->query("SELECT auction_id,product_name,picture,start_time,end_time,auction_type,description FROM Product a, Auction b WHERE a.product_id=b.product_id AND (auction_id LIKE'%$name%' OR a.product_name LIKE'%$name%')");
    }else {
        $dbh = connectDBPDO();
        $statement = $dbh->query("SELECT auction_id,product_name,picture,start_time,end_time,auction_type,description FROM Product a, Auction b WHERE a.product_id=b.product_id");
    }
    $senddata = array();

    while ($row = $statement->fetch(PDO::FETCH_ASSOC)) {
        array_push($senddata, array(
            'auction_id'=>$row['auction_id'],
            'product_name' =>$row['product_name'],
            'picture' => "../img/product/" .$row['picture'],
            'start_time' => $row['start_time'],
            'end_time' => $row['end_time'],
            'auction_type' => $row['auction_type'],
            'description' => $row['description'],
        ));
    }
    echo json_encode($senddata);
    $conn = null;
}

function del(){
    $auction_id = $_POST['auction_id'];
    $dbh=connectDBPDO();
    $statement=$dbh->query("SELECT product_id From Auction WHere auction_id='$auction_id'");
    $row=$statement->fetch(PDO::FETCH_ASSOC);

    $statement1=$dbh->query("SELECT picture FROM Product WHERE product_id='".$row['product_id']."'");
    $row1=$statement1->fetch(PDO::FETCH_ASSOC);
    $picture=$row1['picture'];

    $statement2=$dbh->query("DELETE FROM Auction WHERE auction_id='$auction_id'");
    $statement3=$dbh->query("DELETE FROM Product WHERE product_id='".$row['product_id']."'");
    unlink('../../img/product/'.$picture);

    echo json_encode($statement3);
    $conn = null;
}

function edit(){
    $dbh=connectDBPDO();
    $editid=$_POST['editid'];
    $edittype=$_POST['edittype'];
    $editstarttime=$_POST['editstarttime'];
    $editendtime=$_POST['editendtime'];
    $editproductname=$_POST['editproductname'];
    $editdescription=$_POST['editdescription'];
    $imgFile = $_FILES['file']['name'];
    $tmp_dir = $_FILES['file']['tmp_name'];
    $imgSize = $_FILES['file']['size'];
    if (empty($edittype)) {
        die("Please Enter Auction Type.");
    } else if (empty($editstarttime)) {
        die("Please Enter Start Time.");
    } else if (empty($editendtime)) {
        die("Please Enter End Time.");
    } else if (empty($editproductname)) {
        die("Please Enter Product Name.");
    } else if (empty($editdescription)) {
        die("Please Enter Product Description.");
    } else if (empty($imgFile)) {
        die("Please Select Image File.");
    } else {
        $statement = $dbh->query("SELECT product_id From Auction WHERE auction_id='$editid'");
        $row = $statement->fetch(PDO::FETCH_ASSOC);
        $statement3 = $dbh->query("SELECT picture FROM Product WHERE product_id='" . $row['product_id'] . "'");
        $picture = $row['picture'];
        unlink('../../img/product/' . $picture);
        $statement1 = $dbh->query("UPDATE Auction SET auction_type='$edittype',start_time='$editstarttime',end_time='$editendtime' WHERE auction_id='$editid'");
        $statement2 = $dbh->query("UPDATE Product SET product_name='$editproductname',description='$editdescription',picture='$imgFile' WHERE product_id='" . $row['product_id'] . "'");
        $upload_dir = '../../img/product/' . basename($_FILES['file']['name']); // upload directory
        $imgExt = strtolower(pathinfo($imgFile, PATHINFO_EXTENSION)); // get image extension
        // valid image extensions
        $valid_extensions = array('jpeg', 'jpg', 'png', 'gif'); // valid extensions

        // allow valid image file formats
        if (in_array($imgExt, $valid_extensions)) {
            // Check file size '5MB'
            if ($imgSize < 5000000) {
                move_uploaded_file($tmp_dir, $upload_dir);
            } else {
                die("Sorry, your file is too large.");
            }
        } else {
            die("Sorry, only JPG, JPEG, PNG & GIF files are allowed.");
        }
        echo json_encode($statement2);
        $conn = null;
    }
}

function add()
{
    if (isset($_POST['addDataBtn'])) {
        $user_id = $_POST['user_id'];
        $auction_type = $_POST['auction_type'];
        $start_time = $_POST['add_auction_starttime'];
        $end_time = $_POST['add_auction_endtime'];
        $product_name = $_POST['add_auction_name'];
        $description = $_POST['add_auction_description'];
        $current_price = $_POST['add_auction_price'];
        $product_type = $_POST['add_product_type'];
        $imgFile = $_FILES['addFimage']['name'];
        $tmp_dir = $_FILES['addFimage']['tmp_name'];
        $imgSize = $_FILES['addFimage']['size'];

        if (empty($auction_type)) {
            echo "<script>alert('Please Enter Auction Type.');location.href='../Manage_auction.php';</script>";
        } else if (empty($start_time)) {
            echo "<script>alert('Please Enter Start Time.');location.href='../Manage_auction.php';</script>";
        } else if (empty($end_time)) {
            echo "<script>alert('Please Enter End Time.');location.href='../Manage_auction.php';</script>";
        } else if (empty($product_name)) {
            echo "<script>alert('Please Enter Product Name.');location.href='../Manage_auction.php';</script>";
        } else if (empty($description)) {
            echo "<script>alert('Please Enter Description.');location.href='../Manage_auction.php';</script>";
        } else if (empty($current_price)) {
            echo "<script>alert('Please Enter Starting Price.');location.href='../Manage_auction.php';</script>";
        } else if (empty($product_type)) {
            echo "<script>alert('Please Enter Product Type.');location.href='../Manage_auction.php';</script>";
        } else if (empty($imgFile)) {
            echo "<script>alert('Please Choose Picture.');location.href='../Manage_auction.php';</script>";
        } else {
            $upload_dir = '../../img/product/' . basename($_FILES['addFimage']['name']); // upload directory

            $imgExt = strtolower(pathinfo($imgFile, PATHINFO_EXTENSION)); // get image extension

            // valid image extensions
            $valid_extensions = array('jpeg', 'jpg', 'png', 'gif'); // valid extensions

            // allow valid image file formats
            if (in_array($imgExt, $valid_extensions)) {
                // Check file size '5MB'
                if ($imgSize < 5000000) {
                    move_uploaded_file($tmp_dir, $upload_dir);
                } else {
                    die("Sorry, your file is too large.");
                }
            } else {
                die("Sorry, only JPG, JPEG, PNG & GIF files are allowed.");
            }
            // if no error occured, continue ....
            $statement = AddAuction($user_id, $auction_type, $start_time, $end_time, $product_name, $description, $current_price, $product_type, $imgFile);
            if ($statement) {
                echo "<script>alert('Add auction success!');location.href='../Manage_auction.php';</script>";
            } else {
                echo "<script>alert('Add auction Fail! Please try again');location.href='../Manage_auction.php';</script>";
            }
        }
    }
}