<?php
require_once '../../Database/database.php';
$type = addslashes(htmlspecialchars(@$_POST['type']));
if ($type=='get') {
    get();
}else if($type=='del'){
    del();
}else if($type=='edit'){
    edit();
}else if($type=='authentication'){
    authentication();
}else if($type=='activate'){
    activate();
} else{
    add();
}

function get(){
    header("content-type:application/json;charset=utf-8");
    $name=@$_POST['name'];
    if($name){
        $dbh = connectDBPDO();
        $statement = $dbh->query("SELECT user_id,firstname,lastname,username,password,phone FROM User WHERE user_id LIKE'%$name%' OR firstname LIKE'%$name%' OR lastname LIKE'%$name%' OR username LIKE'%$name%'");
    }else {
        $dbh = connectDBPDO();
        $statement = $dbh->query("SELECT user_id,firstname,lastname,username,password,phone FROM User");
    }
    $senddata = array();

    while ($row = $statement->fetch(PDO::FETCH_ASSOC)) {
        array_push($senddata, array(
            'user_id'=>$row['user_id'],
            'firstname' =>$row['firstname'],
            'lastname' => $row['lastname'],
            'username' => $row['username'],
            'password' => $row['password'],
            'phone' => $row['phone'],
        ));
    }
    echo json_encode($senddata);
    $conn = null;
}

function del(){
    $user_id = $_POST['user_id'];
    $dbh=connectDBPDO();
    $statement=$dbh->query("DELETE FROM User WHERE user_id='$user_id'");

    echo json_encode($statement);
    $conn = null;
}

function edit()
{
    $dbh = connectDBPDO();
    $user_id = $_POST['user_id'];
    $firstname = $_POST['firstname'];
    $lastname = $_POST['lastname'];
    $username = $_POST['username'];
    $phone = $_POST['phone'];
    if (empty($firstname)) {
        echo "<script>alert('Please Enter First name.');location.href='../Manage_user.php';</script>";//Register fail
    } else if (empty($lastname)) {
        echo "<script>alert('Please Enter Last name.');location.href='../Manage_user.php';</script>";//Register fail
    } else if (empty($username)) {
        echo "<script>alert('Please Enter Email.');location.href='../Manage_user.php';</script>";//Register fail

    } else if (empty($phone)) {
        echo "<script>alert('Please Enter Phone.');location.href='../Manage_user.php';</script>";//Register fail
    } else {
        $statement = $dbh->query("UPDATE User SET firstname='$firstname',lastname='$lastname',username='$username',phone='$phone' WHERE user_id='$user_id'");
        echo json_encode($statement);
        $conn = null;
    }
}

function add(){
    $dbh = connectDBPDO();
    $username=$_POST['addemail'];
    $firstname=$_POST['addfirstname'];
    $lastname=$_POST['addlastname'];
    $role="customer";
    $password=$_POST['addpassword'];
    $phone=$_POST['addphone'];
    $salt = "62";
    $password_hash = $password . $username . $salt;
    $password_hash = hash('sha256', $password_hash);
    $statement = $dbh->query(
        "SELECT * FROM User WHERE username ='$username';" );
    $row = $statement->fetch(PDO::FETCH_ASSOC);
    if($row){
        header("refresh:3; url=../Manage_user.php");
        echo ("This email has been used.Please try again after 3s.");
    }else if($username==""||$firstname==""||$lastname==""||$password==""||$phone==""){
        header("refresh:3; url=../Manage_user.php");
        echo ("Please fill required information");
    }else {
        $statement = AddUser($firstname,$lastname,$username,$password_hash,$phone,"","",$role);
        if (!$statement) {
            echo "<script>alert('Add fail!');location.href='../Manage_user.php';</script>";//Register fail
        } else {

            echo "<script>alert('Add successfully!');location.href='../Manage_user.php';</script>";//Register successful
        }
    }
}

function authentication(){
    header("content-type:application/json;charset=utf-8");
    $dbh = connectDBPDO();
    $statement=$dbh->query("SELECT username,user_id,firstname,lastname,id_card FROM User WHERE authentication=0 AND id_card !=''");

    $senddata = array();

    while ($row = $statement->fetch(PDO::FETCH_ASSOC)) {
        array_push($senddata, array(
            'firstname'=>$row['firstname'],
            'lastname' =>$row['lastname'],
            'id_card' => "../img/id_card/".$row['id_card'],
            'user_id' => $row['user_id'],
            'username' => $row['username'],

        ));
    }
    echo json_encode($senddata);
    $conn = null;
}

function activate(){
    $dbh = connectDBPDO();
    $user_id=$_POST['id'];
    $statement=$dbh->query("UPDATE User SET authentication=1 WHERE user_id='$user_id'");
    echo json_encode($statement);
    $conn = null;
}
