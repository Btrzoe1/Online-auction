<?php
require_once '../../Database/database.php';
$dbh = connectDBPDO();

header("Content-Type: text/html; charset=utf8");


if (!isset($_POST['email'])) {
    echo "<script>alert('Email not define.');location.href='../Admin_login.php';</script>";
}

if (!isset($_POST['password'])) {
    echo "<script>alert('Password not define.');location.href='../Admin_login.php';</script>";
}

$username = filter_input(INPUT_POST, 'email', FILTER_SANITIZE_STRING);
$password = filter_input(INPUT_POST, 'password', FILTER_SANITIZE_STRING);



$salt = "62";
$password_hash = $password . $username . $salt;
$password_hash = hash('sha256', $password_hash);
try {
    $dbh = connectDBPDO();
    $statement = $dbh->query(
        "SELECT * FROM User WHERE username ='$username' AND password = '$password_hash' AND role='admin';" );
    $User = $statement->fetch(PDO::FETCH_ASSOC);
    if ($User) {
        header("refresh:0;url=../index.php");
        session_start();
        $_SESSION['User'] = $User;
    } else {
        echo "<script>alert('Username or password invalid');location.href='../Admin_login.php';</script>";
    }
} catch (PDOException $e) {
    die ("Error!: " . $e->getMessage() . "<br/>");
}