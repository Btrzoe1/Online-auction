
<!DOCTYPE html>
<html>
<body>
<!-- navbar-->
<?php require_once "header.php";
?>
<div class="page-holder w-100 d-flex flex-wrap">
        <div class="container-fluid px-xl-5">
          <section class="py-5">
            <div class="row">
                <div class="col-lg-12 mb-5">
                    <div class="card">
                        <div class="card-header">
                            <div class="card-tools">
                                <div class="input-group input-group-sm" >
                                    <input type="text" style="width: 40%;float: right" id="searchInput" placeholder="Member id/email/firstname/lastname">
                                    <span class="input-group-append"><button type="button" id="get"  class="btn btn-primary">Search</button>
                                        <button type="button" class="btn btn-success btn-sm" data-toggle="modal" data-target="#addModal">Add new member</button></span>
                                </div>
                            </div>
                        </div>
                        <div class="card-body">
                            <table class="table card-text">
                                <thead>
                                <tr>
                                    <th>First Name</th>
                                    <th>Last Name</th>
                                    <th>Email</th>
                                    <th>Phone</th>
                                    <th>Operation</th>
                                </tr>
                                </thead>
                                <tbody id="tbody">
                                </tbody>
                            </table>
                        </div>
                        <!-- edit auction start -->
                        <div class="modal fade" id="editModal" tabindex="-1" role="dialog" aria-labelledby="editModalLabel">
                            <div class="modal-dialog" role="document">
                                <div class="modal-content">
                                    <div class="modal-header">
                                        <h4 class="modal-title" id="editModalLabel">Edit User</h4>
                                    </div>
                                    <div class="modal-body">
                                        <form role="form">
                                            <input type="hidden" id="editId" class="form-control">
                                            <p>First Name: <input type="text" id="editfirstname" class="form-control"></p>
                                            <div class="email-w3ls">
                                                <p>Last Name: <input type="text" id="editlastname" class="form-control"></p>
                                            </div>
                                            <div class="email-w3ls">
                                                <p>Email: <input type="text" id="editusername" class="form-control"></p>
                                            </div>
                                            <div class="w3ls-password">
                                                <p>Phone: <input type="text" onkeyup="value=value.replace(/[^\d]/g,'')" id="editphone" class="form-control" /></p>
                                            </div>
                                            <div>
                                                <p><input type="button" class="btn btn-danger" data-dismiss="modal" value="Cancel">
                                                    <input type="button" id="editDataBtn" class="btn btn-success" value="Submit" /></p>
                                            </div>
                                        </form>
                                    </div>
                                </div>
                            </div>
                        </div>
                        <!-- edit auction end -->
                        <!-- add auction start -->
                        <div class="modal fade" id="addModal" tabindex="-1" role="dialog" aria-labelledby="addModalLabel">
                            <div class="modal-dialog" role="document">
                                <div class="modal-content">
                                    <div class="modal-header">
                                        <h4 class="modal-title" id="addModalLabel">Add New User</h4>
                                    </div>
                                    <div class="modal-body">
                                        <form action="Back-end/Manage_user.php" method="post" role="form">
                                            <input type="hidden" name="type" value="add" class="form-control">
                                            <p>Email: <input type="text" name="addemail" class="form-control" required=""></p>
                                            <div class="email-w3ls">
                                                <p>First Name: <input type="text" name="addfirstname" class="form-control" required=""></p>
                                            </div>
                                            <div class="email-w3ls">
                                                <p>Last Name: <input type="text" name="addlastname" class="form-control" required=""></p>
                                            </div>
                                            <div class="w3ls-password">
                                                <p>Password: <input type="password" name="addpassword" class="form-control" required="" /></p>
                                            </div>
                                            <div class="w3ls-password">
                                                <p>Phone: <input type="text" onkeyup="value=value.replace(/[^\d]/g,'')" name="addphone" class="form-control" required="" /></p>
                                            </div>
                                            <div>
                                                <p><input type="button" class="btn btn-danger" data-dismiss="modal" value="Cancel">
                                                    <input type="submit" name="addDataBtn" class="btn btn-success" value="Submit" /></p>
                                            </div>
                                        </form>
                                    </div>
                                </div>
                            </div>
                        </div>
                        <!-- add auction end -->
                    </div>
                </div>
            </div>
          </section>
        </div>
</div>

<script>
    var web = {
        init: function () {
            this.getAll();
            this.eleBind();
        },
        eleBind: function () {

            $('#tbody').click(function (e) {
                let type = $(e.target).attr("data-type");
                let id = $(e.target).attr("data-id");
                if (type === 'del' && id) {
                    var gnl=confirm("Confirm to delete this user?");
                    if (gnl==true){
                        web.delDate(id);
                    }else{
                        return false;
                    }
                }else if(type === 'edit' && id){
                    $('#editId').val(id);
                }
            })
            $('#get').click(function(){
                var name=$('#searchInput').val();
                data={
                    name:name,
                }
                web.getData(data);
            })
            $('#editDataBtn').click(function() {
                var user_id = $("#editId").val();
                var firstname = $("#editfirstname").val();
                var lastname = $("#editlastname").val();
                var username = $("#editusername").val();
                var phone = $("#editphone").val();
                var data = {
                    user_id: user_id,
                    firstname: firstname,
                    lastname: lastname,
                    username: username,
                    phone:phone
                }
                web.editData(data);
            })
        },
        // Get all users information
        getAll: function () {
            $.ajax({
                url: "Back-end/Manage_user.php",
                type: "post",
                data: {
                    type:'get'
                },
                datatype: 'json',
                success: function (data) {
                    web.setData(data);
                },
            })
        },
        // Search user information.
        getData: function (data) {
            $.ajax({
                url: "Back-end/Manage_user.php",
                type: "post",
                data: {
                    name:data.name,
                    type:'get'
                },
                datatype: 'json',
                success: function (data) {
                    web.setData(data);
                },
                error: function(){
                }
            })
        },
        // Delete user information
        delDate: function(id) {
            $.ajax({
                url: "Back-end/Manage_user.php",
                type: "post",
                data: {
                    user_id: id,
                    type: 'del'
                },
                datatype: "json",
                success: function(data) {
                    alert('Delete successfully!');
                    web.getAll();
                }
            })
        },
        // Edit user information.
        editData: function(data) {
            console.log(data)
            $.ajax({
                url: "Back-end/Manage_user.php",
                data: {
                    user_id: data.user_id,
                    firstname: data.firstname,
                    lastname: data.lastname,
                    username: data.username,
                    phone:data.phone,
                    type: 'edit'
                },
                type: "post",
                datatype: "json",
                success: function(data) {
                    console.log(data)
                        $('#editModal').modal('hide')
                        web.getAll();
                }
            })
        },
        // Show user information.
        setData: function (data) {
            var html = "";
            data.forEach(function (data, index, array) {
                html += `
                        <tr>
                            <td scope="row"> ${data.firstname}</td>
                            <td>${data.lastname}</td>
                            <td>${data.username}</td>
                            <td>${data.phone}</td>
                            <td type="edit">
                                <button data-type='edit' data-id='${data.user_id}'  class="btn btn-primary" data-toggle="modal" data-target="#editModal">Edit</button>
                                <button data-type='del' data-id='${data.user_id}' class="btn btn-danger" >Delete</button>
                            </td>
                        </tr>`
            })
            $('#tbody').html(html);
        }
    }

    $(document).ready(function () {
        web.init()
    })
</script>
