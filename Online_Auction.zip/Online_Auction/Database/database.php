<?php
/**
 * Created by PhpStorm.
 * User: Tingran Bian
 * Date: 2019-07-02
 * Time: 17:31
 */

/**
 * Connect to database
 * @return PDO
 */
function connectDBPDO()
{
    $dbms = 'mysql';     //Data base type
    $dbName = 'web_auction';
    $host = 'db4free.net';
    $user = 'zoe_admin';
    $pass = 'aaaaaaaa';
    $dsn = "$dbms:host=$host;dbname=$dbName";
    $dbh = new PDO($dsn, $user, $pass, array(PDO::ATTR_PERSISTENT => true));
    return $dbh;
}


/**
 * register
 * @param $firstname
 * @param $lastname
 * @param $username
 * @param $password_hash
 * @param $phone
 * @param $address
 * @param $post_code
 * @param $role
 * @return false|PDOStatement
 */
function AddUser($firstname,$lastname,$username,$password_hash,$phone,$address,$post_code,$role){
    $dbh = connectDBPDO();
    $authentication='0';
    $sql = "INSERT INTO User(firstname,lastname,username,password,phone,address,post_code,role,authentication) 
            VALUES ('$firstname','$lastname','$username','$password_hash','$phone','$address','$post_code','$role','$authentication')";
    $statement = $dbh->query($sql);
    $dbh = null;
    return $statement;
}

/**
 * Reset password
 * @param $username
 * @param $password_hash
 * @return false|PDOStatement
 */
function ResetPassword($username,$password_hash){
    $dbh = connectDBPDO();
    $sql="UPDATE User SET password='$password_hash' WHERE username='$username'";
    $statement = $dbh->query($sql);
    $dbh = null;
    return $statement;
}

/**
 * Select a user from database
 * @param $username
 * @return mixed
 */
function SelectAuser($username){
    $dbh = connectDBPDO();
    $sql = "SELECT * FROM User WHERE username='$username'";
    $statement = $dbh->query($sql);
    $rows = $statement->fetch(PDO::FETCH_ASSOC);
    $dbh = null;
    return $rows;
}

/**
 * Edit the username or password of a user
 * @param $username
 * @param $password_hash
 * @return false|PDOStatement
 */
function EditPassword($username,$password_hash){
    $dbh=connectDBPDO();
    $sql="UPDATE User SET password = '$password_hash' WHERE username='$username' ";
    $statement = $dbh->query($sql);
    $dbh = null;
    return $statement;
}


/**
 * Edit the personal detail of a user
 * @param $username
 * @param $firstname
 * @param $lastname
 * @param $phone
 * @param $address
 * @param $post_code
 * @return false|PDOStatement
 */
function EditInformation($username,$firstname,$lastname,$phone,$address,$post_code){
    $dbh=connectDBPDO();
    $sql="UPDATE User SET firstname='$firstname',lastname='$lastname',phone='$phone',address='$address',post_code='$post_code' WHERE username='$username'";
    echo $sql;
    $statement = $dbh->query($sql);
    $dbh = null;
    return $statement;
}

/**
 * Add a new auction
 * @param $user_id
 * @param $auction_type
 * @param $start_time
 * @param $end_time
 * @param $product_name
 * @param $description
 * @param $current_price
 * @param $product_type
 * @param $imgFile
 * @return false|PDOStatement
 */
function AddAuction($user_id,$auction_type,$start_time,$end_time,$product_name,$description,$current_price,$product_type,$imgFile){
    $now=gmdate("Y-m-d H:i:s",strtotime("+1 hour")); // Current time
    $time = strtotime($now);
    $time_s=strtotime($start_time);
    if($time_s<$time){
        $auction_status='available';
    }else{
        $auction_status='unavailable';
    }
    $dbh = connectDBPDO();
    $sql1 = "INSERT INTO Product (product_name,picture,description,product_type) VALUES('$product_name','$imgFile','$description','$product_type')";
    $statement1 = $dbh->query($sql1);

    $sql2="SELECT product_id FROM Product WHERE product_name='$product_name'";
    $statement2 = $dbh->query($sql2);
    $row1 = $statement2->fetch(PDO::FETCH_ASSOC);
    $result1=$row1['product_id'];
    if($auction_type=="Repeated second-bid auction"){
        $sql3="INSERT INTO Auction (product_id,user_id,start_time,end_time,auction_type,current_price,highest_price,auction_status) VALUES ('$result1','$user_id','$start_time','$end_time','$auction_type','$current_price','$current_price','$auction_status')";
        $statement3= $dbh->query($sql3);
    }else if($auction_type=="Dutch auction"){
        $sql3="INSERT INTO Auction (product_id,user_id,start_time,end_time,auction_type,current_price,highest_price,auction_status) VALUES ('$result1','$user_id','$start_time','$end_time','$auction_type','$current_price','$current_price','$auction_status')";
        $statement3 = $dbh->query($sql3);
    }else {
        $sql3 = "INSERT INTO Auction (product_id,user_id,start_time,end_time,auction_type,current_price,auction_status) VALUES ('$result1','$user_id','$start_time','$end_time','$auction_type','$current_price','$auction_status')";
        $statement3 = $dbh->query($sql3);
    }
    $dbh = null;
    return $statement3;
}

/**
 * Bid in English auction
 * @param $user_id
 * @param $auction_id
 * @param $bidding_price
 * @param $bidding_time
 * @return false|PDOStatement
 */
function AddEnglishBid($user_id,$auction_id,$bidding_price,$bidding_time){
    $dbh=connectDBPDO();
    $sql1="INSERT INTO Bidding(user_id,auction_id,bidding_price,bidding_time) VALUES ('$user_id','$auction_id','$bidding_price','$bidding_time')";
    $statement1 = $dbh->query($sql1);
    $sql2="UPDATE Auction SET current_price='$bidding_price',highest_price='$bidding_price',bid_times=bid_times+1 WHERE auction_id='$auction_id'";
    $statement2 = $dbh->query($sql2);
    $dbh = null;
    return $statement2;
}

/**
 * Bid in Repeated second-bid auction
 * @param $highest_price
 * @param $current_price
 * @param $user_id
 * @param $auction_id
 * @param $bidding_price
 * @param $bidding_time
 * @return false|PDOStatement
 */
function AddRepeatBid($highest_price,$current_price,$user_id,$auction_id,$bidding_price,$bidding_time){
    $dbh=connectDBPDO();
    $user=$dbh->query("SELECT user_id FROM Bidding WHERE auction_id='$auction_id' ORDER BY bid_id DESC");
    $result=$user->fetch(PDO::FETCH_ASSOC);
    $select_price=$dbh->query("SELECT bidding_price FROM Bidding WHERE user_id='$user_id' AND auction_id='$auction_id' ORDER BY bidding_price DESC");
    $bid_price=$select_price->fetch(PDO::FETCH_ASSOC);
    $sql1 = "INSERT INTO Bidding(user_id,auction_id,bidding_price,bidding_time) VALUES ('$user_id','$auction_id','$bidding_price','$bidding_time')";
    $statement1 = $dbh->query($sql1);
    if($highest_price<$bidding_price){
        if($user_id==$result['user_id']){
            if($highest_price==$bid_price['bidding_price']){
                $sql2="UPDATE Auction SET highest_price='$bidding_price',bid_times=bid_times+1 WHERE auction_id='$auction_id'";
                $statement2=$dbh->query($sql2);
                $dbh = null;
                return $statement2;
            }else{
                $sql2 ="UPDATE Auction SET current_price='$highest_price',highest_price='$bidding_price',bid_times=bid_times+1 WHERE auction_id='$auction_id'";
                $statement2 = $dbh->query($sql2);
                $dbh = null;
                return $statement2;
            }
        }else {
            $sql2 ="UPDATE Auction SET current_price='$highest_price',highest_price='$bidding_price',bid_times=bid_times+1 WHERE auction_id='$auction_id'";
            $statement2 = $dbh->query($sql2);
            $dbh = null;
            return $statement2;
        }
    }else if($current_price<$bidding_price&& $bidding_price<=$highest_price){
        if($bidding_price<$bid_price['bidding_price']||$bidding_price==$bid_price['bidding_price']){
            $sql2 = "UPDATE Auction SET bid_times=bid_times+1 WHERE auction_id='$auction_id'";
            $statement2 = $dbh->query($sql2);
            $dbh = null;
            return $statement2;
        }else {
            $sql2 = "UPDATE Auction SET current_price='$bidding_price',bid_times=bid_times+1 WHERE auction_id='$auction_id'";
            $statement2 = $dbh->query($sql2);
            $dbh = null;
            return $statement2;
        }
    }else{
        $sql2 = "UPDATE Auction SET bid_times=bid_times+1 WHERE auction_id='$auction_id'";
        $statement2 = $dbh->query($sql2);
        $dbh = null;
        return $statement2;
    }
}

/**
 * Bid in Dutch auction
 * @param $user_id
 * @param $auction_id
 * @param $current_price
 * @param $bidding_time
 * @return false|PDOStatement
 */
function AddDutchBid($user_id,$auction_id,$current_price,$bidding_time){
    $dbh=connectDBPDO();
    $sql1="INSERT INTO Bidding(user_id,auction_id,bidding_price,bidding_time) VALUES ('$user_id','$auction_id','$current_price','$bidding_time')";
    $statement1=$dbh->query($sql1);
    $sql2="UPDATE Auction SET winner_id='$user_id', auction_status='expired',end_time='$bidding_time' WHERE auction_id='$auction_id'";
    $statement2=$dbh->query($sql2);
    $dbh = null;
    return $statement2;
}

/**
 * Add a comment
 * @param $user_id
 * @param $subject
 * @param $comment
 * @return false|PDOStatement
 */
function AddComment($user_id,$subject,$comment){
    $dbh=connectDBPDO();
    $sql="INSERT INTO Comment(user_id,subject,comment)VALUE('$user_id','$subject','$comment')";
    $statement=$dbh->query($sql);
    $dbh = null;
    return $statement;
}