/*
 Navicat Premium Data Transfer

 Source Server         : online-auction
 Source Server Type    : MySQL
 Source Server Version : 80017
 Source Host           : db4free.net:3306
 Source Schema         : web_auction

 Target Server Type    : MySQL
 Target Server Version : 80017
 File Encoding         : 65001

 Date: 06/09/2019 05:06:28
*/

SET NAMES utf8mb4;
SET FOREIGN_KEY_CHECKS = 0;

-- ----------------------------
-- Table structure for Auction
-- ----------------------------
DROP TABLE IF EXISTS `Auction`;
CREATE TABLE `Auction` (
  `auction_id` int(11) NOT NULL AUTO_INCREMENT,
  `product_id` int(11) NOT NULL,
  `user_id` int(11) NOT NULL,
  `start_time` datetime NOT NULL,
  `end_time` datetime NOT NULL,
  `auction_type` text NOT NULL,
  `current_price` double NOT NULL,
  `bid_times` int(3) unsigned zerofill DEFAULT '000',
  `auction_status` text,
  `highest_price` double DEFAULT '0',
  `winner_id` int(11) DEFAULT NULL,
  PRIMARY KEY (`auction_id`)
) ENGINE=InnoDB AUTO_INCREMENT=53 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

-- ----------------------------
-- Records of Auction
-- ----------------------------
BEGIN;
INSERT INTO `Auction` VALUES (1, 1, 9, '2019-09-03 21:00:00', '2019-09-20 13:37:00', 'English auction', 32.1, 003, 'available', 32.1, NULL);
INSERT INTO `Auction` VALUES (2, 2, 10, '2019-08-04 17:53:40', '2019-09-14 17:53:45', 'English auction', 51, 005, 'available', 51, NULL);
INSERT INTO `Auction` VALUES (7, 19, 4, '2019-09-04 12:00:23', '2019-10-11 16:18:29', 'Repeated second-bid auction', 25.9, 000, 'available', 25.9, NULL);
INSERT INTO `Auction` VALUES (8, 20, 9, '2019-08-10 16:27:00', '2019-09-30 16:27:07', 'English auction', 31, 013, 'available', 31, NULL);
INSERT INTO `Auction` VALUES (9, 21, 10, '2019-08-11 16:55:54', '2019-09-30 16:56:01', 'Repeated second-bid auction', 12, 002, 'available', 14, NULL);
INSERT INTO `Auction` VALUES (10, 22, 9, '2019-09-04 01:13:00', '2019-10-30 13:02:13', 'Dutch auction', 10, 000, 'available', 500, NULL);
INSERT INTO `Auction` VALUES (12, 26, 9, '2019-08-08 03:32:00', '2019-09-19 15:02:00', 'Repeated second-bid auction', 16, 004, 'available', 17, NULL);
INSERT INTO `Auction` VALUES (15, 29, 10, '2019-09-03 02:31:00', '2019-09-27 03:21:00', 'Dutch auction', 90, 000, 'available', 300, NULL);
INSERT INTO `Auction` VALUES (16, 31, 4, '2019-08-12 03:21:00', '2019-10-05 15:21:00', 'Repeated second-bid auction', 24, 025, 'available', 25, NULL);
INSERT INTO `Auction` VALUES (31, 51, 10, '2019-08-12 12:01:00', '2019-10-31 14:01:00', 'English auction', 33.6, 010, 'available', 33.6, NULL);
COMMIT;

-- ----------------------------
-- Table structure for Bidding
-- ----------------------------
DROP TABLE IF EXISTS `Bidding`;
CREATE TABLE `Bidding` (
  `bid_id` int(11) NOT NULL AUTO_INCREMENT,
  `user_id` int(11) NOT NULL,
  `auction_id` int(11) NOT NULL,
  `bidding_price` double NOT NULL,
  `bidding_time` datetime NOT NULL,
  PRIMARY KEY (`bid_id`)
) ENGINE=InnoDB AUTO_INCREMENT=93 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

-- ----------------------------
-- Records of Bidding
-- ----------------------------
BEGIN;
INSERT INTO `Bidding` VALUES (1, 9, 8, 20, '2019-08-07 20:00:00');
INSERT INTO `Bidding` VALUES (2, 9, 8, 22, '2019-08-07 20:45:33');
INSERT INTO `Bidding` VALUES (3, 9, 8, 23, '2019-08-07 20:53:39');
INSERT INTO `Bidding` VALUES (4, 9, 8, 24, '2019-08-07 20:54:17');
INSERT INTO `Bidding` VALUES (5, 9, 8, 25, '2019-08-07 20:57:26');
INSERT INTO `Bidding` VALUES (12, 9, 8, 26, '2019-08-07 22:28:02');
INSERT INTO `Bidding` VALUES (13, 9, 8, 27, '2019-08-07 22:34:19');
INSERT INTO `Bidding` VALUES (14, 9, 8, 28, '2019-08-07 23:01:24');
INSERT INTO `Bidding` VALUES (15, 9, 8, 29, '2019-08-07 23:02:59');
INSERT INTO `Bidding` VALUES (16, 9, 2, 37, '2019-08-07 23:08:22');
INSERT INTO `Bidding` VALUES (17, 9, 2, 38, '2019-08-07 23:10:38');
INSERT INTO `Bidding` VALUES (18, 4, 2, 39, '2019-08-09 00:42:43');
INSERT INTO `Bidding` VALUES (42, 10, 8, 30, '2019-08-11 22:44:40');
INSERT INTO `Bidding` VALUES (43, 10, 8, 31, '2019-08-11 22:45:54');
INSERT INTO `Bidding` VALUES (44, 9, 13, 50, '2019-08-12 01:44:04');
INSERT INTO `Bidding` VALUES (47, 10, 12, 16, '2019-08-13 03:31:26');
INSERT INTO `Bidding` VALUES (48, 10, 12, 17, '2019-08-13 03:32:20');
INSERT INTO `Bidding` VALUES (49, 10, 9, 12, '2019-08-13 13:01:39');
INSERT INTO `Bidding` VALUES (50, 10, 9, 14, '2019-08-13 13:01:50');
INSERT INTO `Bidding` VALUES (51, 10, 10, 10, '2019-08-13 13:02:13');
INSERT INTO `Bidding` VALUES (52, 11, 31, 12, '2019-08-13 14:41:01');
INSERT INTO `Bidding` VALUES (53, 11, 32, 271, '2019-08-13 14:41:38');
INSERT INTO `Bidding` VALUES (54, 11, 16, 16, '2019-08-13 14:42:26');
INSERT INTO `Bidding` VALUES (55, 11, 16, 20, '2019-08-13 14:42:41');
INSERT INTO `Bidding` VALUES (56, 11, 16, 22, '2019-08-13 14:43:02');
INSERT INTO `Bidding` VALUES (57, 9, 16, 21, '2019-08-18 21:37:26');
INSERT INTO `Bidding` VALUES (58, 9, 16, 22, '2019-08-18 21:39:02');
INSERT INTO `Bidding` VALUES (59, 9, 16, 23, '2019-08-18 21:40:36');
INSERT INTO `Bidding` VALUES (60, 4, 31, 32, '2019-08-29 15:19:28');
INSERT INTO `Bidding` VALUES (61, 4, 31, 33, '2019-08-29 15:20:14');
INSERT INTO `Bidding` VALUES (65, 4, 31, 33, '2019-08-29 15:47:44');
INSERT INTO `Bidding` VALUES (66, 4, 31, 33.2, '2019-08-29 15:48:54');
INSERT INTO `Bidding` VALUES (67, 4, 31, 33.3, '2019-08-29 15:49:31');
INSERT INTO `Bidding` VALUES (68, 4, 31, 33.5, '2019-08-29 15:52:42');
INSERT INTO `Bidding` VALUES (69, 9, 1, 31, '2019-08-31 17:36:59');
INSERT INTO `Bidding` VALUES (70, 9, 1, 32, '2019-08-31 17:46:18');
INSERT INTO `Bidding` VALUES (71, 9, 1, 32.1, '2019-08-31 18:09:08');
INSERT INTO `Bidding` VALUES (72, 9, 31, 33.6, '2019-09-01 13:35:55');
INSERT INTO `Bidding` VALUES (82, 9, 16, 22.5, '2019-09-01 14:49:57');
INSERT INTO `Bidding` VALUES (83, 9, 16, 24, '2019-09-01 14:51:25');
INSERT INTO `Bidding` VALUES (84, 9, 16, 23.5, '2019-09-01 14:52:56');
INSERT INTO `Bidding` VALUES (85, 9, 16, 23.8, '2019-09-01 14:54:34');
INSERT INTO `Bidding` VALUES (86, 9, 16, 23.9, '2019-09-01 14:56:07');
INSERT INTO `Bidding` VALUES (87, 9, 16, 24, '2019-09-01 15:09:52');
INSERT INTO `Bidding` VALUES (88, 10, 16, 23.9, '2019-09-01 15:12:41');
INSERT INTO `Bidding` VALUES (89, 10, 16, 25, '2019-09-01 15:13:40');
INSERT INTO `Bidding` VALUES (90, 10, 16, 24.5, '2019-09-01 15:16:01');
INSERT INTO `Bidding` VALUES (91, 9, 2, 40, '2019-09-03 23:11:05');
INSERT INTO `Bidding` VALUES (92, 9, 2, 51, '2019-09-03 23:11:19');
COMMIT;

-- ----------------------------
-- Table structure for Comment
-- ----------------------------
DROP TABLE IF EXISTS `Comment`;
CREATE TABLE `Comment` (
  `comment_id` int(11) NOT NULL AUTO_INCREMENT,
  `user_id` int(11) NOT NULL,
  `subject` text NOT NULL,
  `comment` text NOT NULL,
  `auction_id` int(11) DEFAULT NULL,
  PRIMARY KEY (`comment_id`)
) ENGINE=InnoDB AUTO_INCREMENT=20 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

-- ----------------------------
-- Records of Comment
-- ----------------------------
BEGIN;
INSERT INTO `Comment` VALUES (1, 10, 'problem', 'dassa', NULL);
INSERT INTO `Comment` VALUES (2, 11, 'this is test', 'test message', NULL);
INSERT INTO `Comment` VALUES (3, 4, '', '', NULL);
INSERT INTO `Comment` VALUES (4, 4, '', '', NULL);
INSERT INTO `Comment` VALUES (5, 4, 'wq', 'ew', NULL);
INSERT INTO `Comment` VALUES (6, 9, 'review', 'A gorgeous little camera in bright lapis blue! I was expecting it to come with 10 shots of film, but I actually received 20 shots, spare rechargeable batteries and charger, a cleaning cloth, and a bag! I ordered on Friday and it was delivered Sunday morning. Couldn\'t have had a better experience!', 2);
COMMIT;

-- ----------------------------
-- Table structure for Pageview
-- ----------------------------
DROP TABLE IF EXISTS `Pageview`;
CREATE TABLE `Pageview` (
  `pageview_id` int(11) NOT NULL AUTO_INCREMENT,
  `date` date NOT NULL,
  `times` int(11) NOT NULL DEFAULT '0',
  PRIMARY KEY (`pageview_id`)
) ENGINE=InnoDB AUTO_INCREMENT=26 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

-- ----------------------------
-- Records of Pageview
-- ----------------------------
BEGIN;
INSERT INTO `Pageview` VALUES (2, '2019-08-12', 4);
INSERT INTO `Pageview` VALUES (3, '2019-08-13', 13);
INSERT INTO `Pageview` VALUES (4, '2019-08-14', 6);
INSERT INTO `Pageview` VALUES (5, '2019-08-15', 9);
INSERT INTO `Pageview` VALUES (6, '2019-08-16', 21);
INSERT INTO `Pageview` VALUES (7, '2019-08-17', 5);
INSERT INTO `Pageview` VALUES (8, '2019-08-18', 10);
INSERT INTO `Pageview` VALUES (9, '2019-08-19', 6);
INSERT INTO `Pageview` VALUES (10, '2019-08-20', 24);
INSERT INTO `Pageview` VALUES (11, '2019-08-23', 1);
INSERT INTO `Pageview` VALUES (15, '2019-08-26', 25);
INSERT INTO `Pageview` VALUES (16, '2019-08-27', 11);
INSERT INTO `Pageview` VALUES (17, '2019-08-28', 12);
INSERT INTO `Pageview` VALUES (18, '2019-08-29', 14);
INSERT INTO `Pageview` VALUES (19, '2019-08-30', 8);
INSERT INTO `Pageview` VALUES (20, '2019-08-31', 10);
INSERT INTO `Pageview` VALUES (21, '2019-09-01', 12);
INSERT INTO `Pageview` VALUES (22, '2019-09-03', 5);
INSERT INTO `Pageview` VALUES (23, '2019-09-04', 4);
INSERT INTO `Pageview` VALUES (24, '2019-09-05', 66);
INSERT INTO `Pageview` VALUES (25, '2019-09-06', 1);
COMMIT;

-- ----------------------------
-- Table structure for Product
-- ----------------------------
DROP TABLE IF EXISTS `Product`;
CREATE TABLE `Product` (
  `product_id` int(11) NOT NULL AUTO_INCREMENT,
  `product_name` text NOT NULL,
  `picture` varchar(200) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci NOT NULL,
  `description` text NOT NULL,
  `product_type` text CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci NOT NULL,
  PRIMARY KEY (`product_id`)
) ENGINE=InnoDB AUTO_INCREMENT=77 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

-- ----------------------------
-- Records of Product
-- ----------------------------
BEGIN;
INSERT INTO `Product` VALUES (1, 'Apple watch', 'Apple_watch.jpg', 'Apple Watch relies on a wireless connection to an iPhone to perform many of its default functions such as calling and texting. However, Wi-Fi chips in all Apple Watch models allow the smartwatch to have limited connectivity features away from the phone anywhere a Wi-Fi network is available. Series 3 LTE Apple Watches are able to be used without needing to be consistently connected to an iPhone, though an iPhone is still required to set up the device. First generation and Series 1 and 2 Apple Watches require an iPhone 5s or later with iOS 11; the Series 3 and later LTE models require an iPhone 6 or later with iOS 11 or later.', 'Accessories');
INSERT INTO `Product` VALUES (2, 'Fuji camera', 'Fuji.jpg', 'Designed with the younger generation in mind, the X-A3 is perfectly suited to taking self-portraits thanks to an LCD screen that is not blocked by the camera when tilted by 180 degrees, thus helping to maintain 100% visibility.', 'Electronics');
INSERT INTO `Product` VALUES (19, 'Ring', 'ring.jpg', 'Women\'s ring from Swarovski made of metal is a piece of jewellery of a very special kind.\nMaterial: metal, surface finish: rhodium-plated.Swarovski crystals,We deliver this item in elegant product packaging, so as to complete the perfect overall impression.', 'Accessories');
INSERT INTO `Product` VALUES (20, 'Men\'s coat', 'coat.jpg', 'Details + Highlights: Hood with drawstring and teddy fur and detachable fur collar, High closeable collar, two flap pockets, two breast pockets and a sleeve pocket (push button), an inner pocket, concealed zipper, adjustable drawstring, Elastic cuffs, contrasting color lining, Badge of synthetic suede at the seam, Outer fabric is water repellent', 'Fashion');
INSERT INTO `Product` VALUES (21, 'Buzz Lightyear', 'buzz.jpg', '​This special Buzz Lightyear comes to life with lights, sounds and signature action moves. Lead exciting, Toy Story 4 adventures to infinity and beyond with this walking, talking Buzz. Kids will love his animated effects as he walks forward and back and speaks lines like \"Buzz Lightyear to the rescue\" and \"We\'re on a mission to find our friends\" Press the button under Buzz\'s arm to switch him ON with sound effects. Press the big red button on his left side to deploy his wings and hear him say a series of phrases as he moves forward and sometimes backward, and swivels his hips in true character style. Other authentic sounds include a big jet, wing deployment and three blasters. Unlock the surprise to make Buzz do extra special steps from the movie. With multiple animatronic features, Buzz Lightyear is ready to recreate favorite scenes and bring his Toy Story 4 fun to you. colours and decorations may vary. For ages 3 years old and up.', 'Kids');
INSERT INTO `Product` VALUES (22, 'Lacome', 'lancome.jpg', 'An illuminating eye serum that targets signs of ageing and fatigue around the delicate eye contour to help restore youthful radiance. With a unique massaging 360° Light Pearl™ applicator, the multi-tasking serum delivers multiple benefits, including smoothing the appearance of fine lines and wrinkles, minimising the appearance of dark circles and reducing the look of under eye bags to reveal a brighter-looking, refreshed and well-rested eye contour.', 'Beauty');
INSERT INTO `Product` VALUES (26, 'Vacuum Cleaner', 'vacuum_cleaner.jpg', '15kPa Powerful Suction: deep cleaning, effectively absorb allergens, powerful suction, unlike wireless vacuum cleaners, don\'t worry about battery, cleaning work and extra cost battery. Plug and Play is more Simple: ONEDAY vacuum cleaner line is 10inch long, usage area of 200 square meters, without frequent replacement of the socket. Pro Cyclone Patent separation technology: effectively separates the dirt in the air and solves the different needs of your house, floor, sofa, and car. Easily absorb surfaces and hidden dust, biscuit crumbs and hair for a long-term high-quality cleaning experience.', 'Appliances');
INSERT INTO `Product` VALUES (29, 'Massage Chair', 'Massage_chair.jpeg', 'With a simple push of a button, you can indulge in a luxurious, soothing heated massage with the super comfy Salisbury Electric Recliner Chair. Ideal for people who suffer from back issues and need extra support - or stressful souls who simply struggle to relax. Eight inbuilt pads are placed at strategic points, producing a vibrational massage of varying intensity - simply choose your setting. The heated base will warm and soothe aching or tight back muscles. With a handy pocket for storing the attached controller, this multi-purpose, smooth bonded leather recliner will be a huge hit with every family member. Available in black, brown and cream.', 'Health');
INSERT INTO `Product` VALUES (31, 'Stussy T-shirt', 'stussy.jpg', 'STUSSY: embroidered logo T-shirt. White cotton embroidered logo T-shirt from Stussy featuring a crew neck, short sleeves, a logo to the chest, a straight hem and a relaxed fit.Regular fit short sleeve t-shirt with ribbed crew neck and printed logo.100% Cotton,Imported', 'Fashion');
INSERT INTO `Product` VALUES (51, 'Fjällräven Bag', 'bag.jpg', 'Material: Made of durable, lightweight,water resistant oxford fabric. Dimensions: 38 x 29 x 13 cm /15 x 11 x 5 inch. This is a basic multipurpose daypack for most of your needs,easy to match your cloths,suitable for travel,work,shopping,university,school,etc. Spacious:Large opening of the main compartments for laptop and daily necessities.Two flat elasticized side pockets for bottles, an umbrella or other objects. Easy-access front pocket like keys, headphones or mobile phone.', 'Accessories');
COMMIT;

-- ----------------------------
-- Table structure for User
-- ----------------------------
DROP TABLE IF EXISTS `User`;
CREATE TABLE `User` (
  `user_id` int(11) NOT NULL AUTO_INCREMENT,
  `firstname` text CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci NOT NULL,
  `lastname` text NOT NULL,
  `username` text CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci NOT NULL COMMENT 'User name should be email address',
  `password` text NOT NULL,
  `phone` text NOT NULL,
  `address` text CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci,
  `post_code` text,
  `role` text NOT NULL,
  `authentication` int(11) NOT NULL,
  `id_card` varchar(200) DEFAULT NULL,
  PRIMARY KEY (`user_id`)
) ENGINE=InnoDB AUTO_INCREMENT=23 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

-- ----------------------------
-- Records of User
-- ----------------------------
BEGIN;
INSERT INTO `User` VALUES (4, 'Zoe', 'Bian', 'btrzoe@163.com', 'def2147425c3f5c2e07f11b4f2bbee3c65f5d246c0baf93476416b2d1e584e35', '23456789', 'Ernest Place 108F', 'DH12GY', 'customer', 0, '111.jpg');
INSERT INTO `User` VALUES (9, 'Tingran', 'Bian', '710749165@qq.com', '949773f719f0b093562de57f27c5434316a6315cc7da7d17162dce1aaba47c15', '1323', 'Ernest', 'DH1 2GY', 'admin', 1, NULL);
INSERT INTO `User` VALUES (10, 'Emet', 'Xu', '869150933@qq.com', '96cec73ffeb5b64f502100efd4b5315f038f57df8f502e2899966d7aa4126802', '654738163', '', '', 'customer', 1, '');
INSERT INTO `User` VALUES (11, 'geo', 'per', 'gperipatitis@gmail.com', '4c946b973bb228253475ade87031ca287b2bae405e786ae945fcb800f3fcdc64', '123', '', '', 'customer', 1, NULL);
INSERT INTO `User` VALUES (12, 'koa1a', 'exit', 'IBfPig', '849c1dfc3471ec5e10cfdd81ef5eb68be1df883eb6c6927bd97fe851181e26fb', '7422951161', '', '', 'customer', 1, NULL);
COMMIT;

SET FOREIGN_KEY_CHECKS = 1;
