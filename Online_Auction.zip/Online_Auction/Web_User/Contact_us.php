<!doctype html>
<!--[if IE 9]> <html class="no-js ie9" lang="en"> <![endif]-->
<!--[if gt IE 9]><!--> <html class="no-js " lang="en"> <!--<![endif]-->
<head>
    <meta charset="utf-8">
    <meta http-equiv="x-ua-compatible" content="ie=edge">
    <title>Online Auction | E-auction</title>
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <link rel="stylesheet" href="css/jquery.fancybox.css">
    <link rel="stylesheet" href="css/nivo-slider.css">
    <link rel="stylesheet" href="css/owl.carousel.css">
    <link rel="stylesheet" href="css/font-awesome.min.css">
    <link rel="stylesheet" href="css/bootstrap.min.css">
    <link rel="stylesheet" href="css/style.css">
    <link rel="stylesheet" href="css/responsive.css">
    <script src="../js/vendor/html5shiv.min.js"></script>
    <script src="../js/vendor/respond.min.js"></script>
    <script src="../js/script.js"></script>
</head>
<body>
<header class="header-area">
<?php
require_once "header.php";
?>
    <!-- header-bottom start -->
    <div class="header-bottom">
        <div class="container">
            <div class="header-bottom-bg">
                <div class="row">
                    <!-- mainmenu start -->
                    <div class="col-xs-12 col-md-9">
                        <div class="mainmenu">
                            <nav>
                                <ul>
                                    <li class="active"><a href="index.php">Home</a><i class="fa fa-angle-down"></i></li>
                                    <li><a href="Shop_list.php?auction_type=English auction">English Auction</a></li>
                                    <li><a href="Shop_list.php?auction_type=Dutch auction">Dutch Auction</a></li>
                                    <li><a href="Shop_list.php?auction_type=Repeated second-bid auction">Repeated second-bid Auction</a></li>
                                    <li><a href="Contact_us.php">Contact Us</a></li>
                                </ul>
                            </nav>
                        </div>
                    </div>
                    <!-- mainmenu end -->
                </div>
                <!-- mobile menu start -->
                <div class="row">
                    <div class="col-sm-12 mobile-menu-area">
                        <div class="mobile-menu hidden-md hidden-lg" id="mob-menu">
                            <span class="mobile-menu-title">Menu</span>
                            <nav>
                                <ul>
                                    <li><a href="index.php">Home</a></li>
                                    <li><a href="#">Home Appliances</a>
                                        <ul>
                                            <li><a href="#">Kitchen Appliance</a></li>
                                            <li><a href="#">Bath fixtures</a></li>
                                            <li><a href="#">Accessories</a></li>
                                        </ul>
                                    </li>
                                    <li><a href="#">Electronics</a>
                                        <ul>
                                            <li><a href="#">Computer</a></li>
                                            <li><a href="#">Car Electronics</a></li>
                                            <li><a href="#">Accessories</a></li>
                                        </ul>
                                    </li>
                                    <li><a href="#">About Us</a></li>
                                    <li><a href="#">Contact Us</a></li>
                                </ul>
                            </nav>
                        </div>
                    </div>
                </div>
                <!-- mobile menu end -->
            </div>
        </div>
        <!-- header-bottom end -->
</header>
<center>
    <iframe src="http://www.google.cn/maps/embed?pb=!1m18!1m12!1m3!1d2301.6743714723398!2d-1.5755567487511595!3d54.76811177487046!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x487e8764188916ed%3A0xeb75787140159610!2sBill+Bryson+Library!5e0!3m2!1szh-CN!2scn!4v1565629975812!5m2!1szh-CN!2scn" width="80%" height="320" frameborder="0" style="text-align: center; border:0" allowfullscreen></iframe>
    <div class="contact-us-form">
        <div class="sec-heading-area">
            <h2>Contact US</h2>
        </div>
        <div class="contact-form" >
            <span class="legend">Contact Information</span>
            <form method="post">
                <div class="form-top">
                    <div class="contact-input">
                        <label>Subject <sup>*</sup></label><input name="subject" class="contact-box" type="text"  required=""/>
                    </div>
                    <div class="contact-comment">
                        <label style="float: left">Comment <sup>*</sup></label>
                        <input  name="comment" class="yourmessage" required="">
                    </div>
                    <label><sup>*</sup> Required Fields</label> <input type="submit" name="btn-comment" class="add-tag-btn" value="Submit">
                </div>
            </form>
        </div>
    </div>
</center>
<?php
require_once '../Database/database.php';
if(isset($_POST['btn-comment'])) {
    $subject = $_POST['subject'];
    $comment = $_POST['comment'];
    $user_id = $_SESSION['User']['user_id'];
    $statement = AddComment($user_id, $subject, $comment);
    if ($statement) {
        echo "<script>alert('We will reply you soon!');location.href='Contact_us.php';</script>";
    } else {
        echo "<script>alert('Sorry, there is something wrong! Please try again.');location.href='Contact_us.php';</script>";
    }
}
require_once "footer.php";
?>
<script src="../js/vendor/jquery-1.11.3.min.js"></script>
<script src="../js/jqueryui.js"></script>
<script src="../js/jquery.meanmenu.js"></script>
<script src="../js/jquery.fancybox.js"></script>
<script src="../js/jquery.elevatezoom.js"></script>
<script src="../js/bootstrap.min.js"></script>
<script src="../js/owl.carousel.min.js"></script>
<script src="../js/jquery.nivo.slider.pack.js"></script>
<script src="../js/main.js"></script>
<script src="../js/main.js"></script>

</body>
</html>