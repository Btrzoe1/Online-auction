<!doctype html>
<head>
    <meta charset="utf-8">
    <meta http-equiv="x-ua-compatible" content="ie=edge">
    <title>Online Auction | E-auction</title>
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <link rel="stylesheet" href="css/jquery.fancybox.css">
    <link rel="stylesheet" href="css/nivo-slider.css">
    <link rel="stylesheet" href="css/owl.carousel.css">
    <link rel="stylesheet" href="css/font-awesome.min.css">
    <link rel="stylesheet" href="css/bootstrap.min.css">
    <link rel="stylesheet" href="css/style.css">
    <link rel="stylesheet" href="css/responsive.css">
    <script src="../js/vendor/html5shiv.min.js"></script>
    <script src="../js/vendor/respond.min.js"></script>
    <script src="../js/script.js"></script>
</head>
<body>

<header class="header-area">
    <?php
    require_once "header.php";
    require_once '../Database/database.php';
    $dbh = connectDBPDO();
    $product=$_GET['product'];
    $statement = $dbh->query(
        "SELECT user_id,auction_id,product_name,picture,current_price,auction_type,description,start_time,end_time,auction_status
                       FROM Auction a,Product b
                       WHERE b.product_id='$product'  AND a.product_id=b.product_id;");
    $row = $statement->fetch(PDO::FETCH_ASSOC);
    $auction_id=$row['auction_id'];
    $auction_type=$row['auction_type'];
    $auction_status=$row['auction_status'];
    $product_name=$row['product_name'];
    $picture=$row['picture'];
    $current_price=$row['current_price'];
    $description=$row['description'];
    $start_time=$row['start_time'];
    $end_time=$row['end_time'];
    $user_id=$row['user_id'];
    ?>
    <div class="header-bottom">
        <div class="container">
            <div class="header-bottom-bg">
                <div class="row">
                    <!-- mainmenu start -->
                    <div class="col-xs-12 col-md-9">
                        <div class="mainmenu">
                            <input type="hidden" id="end_time" name="end_time" value="<?php echo $end_time ?>">
                            <nav>
                                <ul>
                                    <li><a href="index.php">Home</a><i class="fa fa-angle-down"></i></li>
                                    <li><a href="Shop_list.php?auction_type=English auction">English Auction</a></li>
                                    <li><a href="Shop_list.php?auction_type=Dutch auction">Dutch Auction</a></li>
                                    <li><a href="Shop_list.php?auction_type=Repeated second-bid auction">Repeated second-bid Auction</a></li>
                                    <li><a href="Contact_us.php">Contact Us</a></li>
                                </ul>
                            </nav>
                        </div>
                    </div>
                    <!-- mainmenu end -->
                </div>
                <!-- mobile menu start -->
                <div class="row">
                    <div class="col-sm-12 mobile-menu-area">
                        <div class="mobile-menu hidden-md hidden-lg" id="mob-menu">
                            <span class="mobile-menu-title">Menu</span>
                            <nav>
                                <ul>
                                    <li><a href="index.php">Home</a></li>
                                    <li><a href="#">Home Appliances</a>
                                        <ul>
                                            <li><a href="#">Kitchen Appliance</a></li>
                                            <li><a href="#">Bath fixtures</a></li>
                                            <li><a href="#">Accessories</a></li>
                                        </ul>
                                    </li>
                                    <li><a href="#">Electronics</a>
                                        <ul>
                                            <li><a href="#">Computer</a></li>
                                            <li><a href="#">Car Electronics</a></li>
                                            <li><a href="#">Accessories</a></li>
                                        </ul>
                                    </li>
                                    <li><a href="#">About Us</a></li>
                                    <li><a href="#">Contact Us</a></li>
                                </ul>
                            </nav>
                        </div>
                    </div>
                </div>
                <!-- mobile menu end -->
            </div>
        </div>
    </div>
    <!-- header-bottom end -->
</header>
<!-- header-area end -->
<!-- main content area start  -->
<section class="main-content-area">
    <div class="container">
        <!-- bradcame start -->
        <div class="row">
            <div class="col-xs-12 col-sm-12 col-md-12 col-lg-12">
                <div class="greentect_bradcame">
                    <ul>
                        <li><a href="index.php">home</a></li>
                    </ul>
                </div>
            </div>
        </div>
        <div class="single-product-page-area">
            <div class="row">
                <div class="col-xs-12 col-sm-5 col-md-5 col-lg-5">
                    <div class="single-product-image">
                        <div class="single-pro-main-image">
                            <img height="418px" width="445px" src="../img/product/<?php echo $picture?>"  alt="optima"/>
                        </div>
                    </div>
                </div>
                <div class="col-xs-12 col-sm-7 col-md-7 col-lg-7">
                    <div class="single-product-description">
                        <?php if($auction_type=="Dutch auction"){
                            ?>
                            <div class="product-variation">
                                    <form action="Back-end/Bid_single_product.php"  onsubmit="return info();" method="post">
                                        <div class="pro-desc">
                                            <h2><?php echo $product_name ?></h2>
                                            <div class="pro-availability">
                                                <p class="availability">Auction time: From<span> <?php echo $start_time?></span> To <span><?php echo $end_time?></span></p>
                                            </div>
                                            <p>Auction type: <?php echo $auction_type ?></p>
                                            <table>
                                                <tbody id='tbody'>
                                                </tbody>
                                            </table>
                                                 <div class="product-content">
                                                    <p><div id="CloseTime"></div></p>
                                                 </div>
                                            <div class="pro-add-to-cart" style="padding-top: 10px;">
                                                <p>Please note: The price is reduced by 3 pounds per hour.
                                                    <input type="hidden" name="auction_id" value="<?php echo $auction_id ?>">
                                                    <input type="hidden" name="bidding_price" value="">
                                                    <input type="hidden" name="user_id" value="<?php echo $_SESSION['User']['user_id']?>">
                                                    <input type="hidden" name="product" value="<?php echo $product ?>">
                                                    <input type="hidden" name="product_name" value="<?php echo $product_name ?>">
                                                    <input type="hidden" name="current_price" value="<?php echo $current_price ?>">
                                                    <input type="hidden" name="username" value="<?php echo $_SESSION['User']['username'] ?>"></p>
                                                    <button type="submit" style="margin-top: 10px; padding: 5px" onsubmit="checkauthentication()" class="btn btn-default">Place bid now</button>
                                            </div>
                                    </form>
                            </div>
                            <?php
                        }else {?>
                        <div class="pro-desc">
                            <h2><?php echo $product_name ?></h2>
                            <div class="pro-availability">
                                <p class="availability">Auction time: From<span> <?php echo $start_time?></span> To <span><?php echo $end_time?></span></p>
                            </div>
                            <p>Auction type: <?php echo $auction_type ?></p>
                            <p>Current bid:<span class="regular-price">￡<?php echo $current_price?></span></p>
                            <div class="product-content">
                                <p><div id="CloseTime"></div></p>
                            </div>
                        </div>
                        <div class="product-variation">
                            <div class="pro-add-to-cart">
                                <form action="Back-end/Bid_single_product.php" onsubmit="return foo();" method="post">
                                <p><label>Bid:  </label>
                                    <input type="hidden" name="auction_id" value="<?php echo $auction_id ?>">
                                    <input type="hidden" name="user_id" value="<?php echo $_SESSION['User']['user_id']?>">
                                    <input type="hidden" name="product" value="<?php echo $product ?>">
                                    <input type="hidden" name="product_name" value="<?php echo $product_name ?>">
                                    <input type="hidden" name="current_price" value="<?php echo $current_price ?>">
                                    <input type="hidden" name="username" value="<?php echo $_SESSION['User']['username'] ?>">
                                    ￡ <input class="cart-plus-minus-box" type="text" onkeyup="value=value.replace(/[^\d^\.]+/g,'')"  id="bidding_price" name="bidding_price">
                                    <button type="submit" style=" margin-left:10px;"  class="btn btn-default">Place bid</button></p>
                                </form>
                                    <p>Enter ￡<?php echo $current_price+0.1?> or more </p>
                            </div>
                            <?php
                            $record=$dbh->query("SELECT bidding_price FROM Bidding WHERE auction_id='$auction_id' ORDER BY bid_id DESC limit 5");
                            $record_price=$record->fetchAll(PDO::FETCH_ASSOC);
                            $i=0;
                            $price=['','','','',''];
                            foreach ($record_price as $get_price)
                                if($get_price){
                                    $price[$i]=$get_price['bidding_price'];
                                    $i=$i+1;
                                }else{
                                    $price[$i]=0;
                                    $i=$i+1;
                                }
                            ?>
                            <div id="container" style="height: 200px; width: 500px"></div>
                        </div>
                        <?php } ?>
                    </div>
                </div>
                <?php
                $result=$dbh->query("SELECT username FROM User WHERE user_id='$user_id'");
                $username=$result->fetch(PDO::FETCH_ASSOC);
                ?>
                <p style="padding-top: 5%">You have any question about this item?  <a style="color: #c77405" href="mailto:<?php echo $username['username']?>?subject=Auction item: <?php echo $product_name ?> From E-auction">Send email to the seller.</a></p>

            </div>
            <!-- product description tab start -->
            <div class="row">
                <div class="col-xs-12 col-sm-12 col-md-12 col-lg-12">
                    <div class="product-more-info-tab">
                        <!-- Nav tabs -->
                        <ul class="more-info-tab nav nav-tabs">
                            <li class="active"><a href="#proDescription" data-toggle="tab">Product description</a></li>
                            <li><a href="#proReview" data-toggle="tab">Seller's comments from other buyers</a></li>
                        </ul>
                        <!-- Tab panes -->
                        <div class="product-tab-content tab-content">
                            <div class="tab-pane active" id="proDescription">
                                <div class="tab-description">
                                    <p><?php echo $description ?></p>
                                </div>
                            </div>
                            <div class="tab-pane" id="proReview">
                            <?php
                            $select_information=$dbh->query("SELECT product_name,picture,comment,firstname From Comment a,Auction b,Product c,User d WHERE a.auction_id=b.auction_id AND a.user_id=d.user_id AND b.user_id='$user_id' AND b.product_id=c.product_id");
                            $select_auction=$select_information->fetchAll(PDO::FETCH_ASSOC);
                            foreach ($select_auction as $select_auction_id) {
                                $find_product_picture=$select_auction_id['picture'];
                                $find_product_name=$select_auction_id['product_name'];
                                $comment_user=$select_auction_id['firstname'];
                                $get_comment=$select_auction_id['comment'];
                                ?>
                                    <div class="tab-review-info">
                                        <div class="review-author">
                                            <img height="100px" width="100px" src="../img/product/<?php echo $find_product_picture ?>">
                                            <p><a href="http://bootexperts.com/"><?php echo $find_product_name ?> </a><label> Review by </label> <span> <?php echo $comment_user ?></span></p>
                                            <p>comment: <?php echo $get_comment ?></p>
                                        </div>
                                    </div>
                            <?php }
                            ?>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
            <!-- product description tab end -->
        </div>
    </div>
</section>

<!-- main content area end  -->
<?php
require_once "footer.php";
?>

<script src="../js/vendor/jquery-1.11.3.min.js"></script>
<script src="../js/jqueryui.js"></script>
<script src="../js/jquery.meanmenu.js"></script>
<script src="../js/jquery.fancybox.js"></script>
<script src="../js/jquery.elevatezoom.js"></script>
<script src="../js/bootstrap.min.js"></script>
<script src="../js/owl.carousel.min.js"></script>
<script src="../js/jquery.nivo.slider.pack.js"></script>
<script src="../js/main.js"></script>
<script src="../js/main.js"></script>
<script>
    // Set auction time left.
    var sa = $("#end_time").val();
    var EndTime=new Date(sa);
    EndTime = new Date(EndTime);
    var nMS,nD,nH,nM,nS;
    function ShowCloseTime(){
        var oDate = new Date();
        nMS=EndTime-oDate ;
        nD=Math.floor(nMS/(1000*60*60*24));
        nH=Math.floor(nMS/(1000*60*60)) % 24 ;
        nM=Math.floor(nMS/(1000*60)) % 60;
        nS=Math.floor(nMS/1000) % 60;
        document.getElementById("CloseTime").innerHTML = ("Time left: " + nD + "d " + nH + "h " + nM + "m " + nS + "s");
        if (nS<0 || nM<0 || nH<0 || nD<0)
        {
            document.getElementById("CloseTime").innerHTML = "Sorry, this auction has been Expired!"
            clearInterval(CloseTimer);
        }
    }
    var CloseTimer = window.setInterval("ShowCloseTime()",1000)
</script>
<script type="text/javascript" src="http://echarts.baidu.com/gallery/vendors/echarts/echarts.min.js"></script>
<script type="text/javascript">
    // Show last five bids by line chart.
    var dom = document.getElementById("container");
    var myChart = echarts.init(dom);
    price1='<?php echo $price[0] ?>';
    price2='<?php echo $price[1] ?>';
    price3='<?php echo $price[2] ?>';
    price4='<?php echo  $price[3] ?>';
    price5='<?php echo $price[4] ?>';
    var app = {};
    option = null;
    option = {
        tooltip: {
            trigger: 'axis',
            formatter:function(params) {
                var result = params[0].name + '<br />';
                params.forEach(function (item) {
                    result += '<span style="display:inline-block;margin-right:5px;border-radius:10px;width:9px;height:9px;background-color:' + item.color + '"></span>￡' + item.data + '<br />';
                });

                return result;
            }
        },
        legend: {
            data:['Last 5 bids']
        },
        toolbox: {
            show: true,
            feature: {
                dataZoom: {
                    yAxisIndex: 'none'
                },
                dataView: {readOnly: false},
                magicType: {type: ['line', 'bar']},
                restore: {},
                saveAsImage: {}
            }
        },
        xAxis:  {
            type: 'category',
            boundaryGap: false,
            data: ['Bidder1','Bidder2','Bidder3','Bidder4','Bidder5']
        },
        yAxis: {
            type: 'value',
            axisLabel: {
                formatter: '￡{value}'
            }
        },
        series: [
            {
                name: 'Last 5 bids',
                type:'line',
                data:[price5, price4, price3, price2, price1],
                lineStyle: {
                    normal: {
                        width: 3,
                    }
                },
            }
        ]
    };
    if (option && typeof option === "object") {
        myChart.setOption(option, true);
    }
</script>
<script>

    function foo(){
        var bidding_price=$('#bidding_price').val();
        <?php $select_authentication=$dbh->query("SELECT authentication FROM User WHERE user_id='".$_SESSION['User']['user_id']."'");
        $get_authentication=$select_authentication->fetch(PDO::FETCH_ASSOC);?>
        if("<?php echo $_SESSION['User']['user_id']?>"=="<?php echo $user_id?>"){  // Judge whether this auction is belong to this user.
            alert("You cannot bid your own items!!");
            return false;
        }else {
            if ("<?php echo $auction_status ?>" == "expired") { // Judge auction status.
                alert("This auction has been expired!");
                return false;
            } else {
                if (bidding_price <= <?php echo $current_price?>) {
                    alert("Please enter at least ￡<?php echo $current_price + 0.1?> !");
                    return false;
                } else {
                    if (confirm("Your bid amount: ￡" + bidding_price)) {
                        if ("<?php echo $get_authentication['authentication']?>" == "0") {  //Judge user authentication.
                            alert("In order to ensure the authenticity of your bidding, you must pass the identity authentication. " +
                                "Please go to your account and upload document!");
                            return false;
                        } else {
                            return true;
                        }
                    } else {
                        return false;
                    }
                }
            }
        }
    }


</script>
<script>
    function info(){
        var bidding_price=$('#bidding_price').val();
        if("<?php echo $auction_status ?>" == "expired")  // Judge auction status.
        {
            alert("This auction has been expired!");
            return false;
        }else{

            var gnl=confirm("Confirm your bidding?");
            if (gnl==true){
                return true;
            }else{
                return false;
            }
        }
    }
</script>
<script>
    if("<?php echo $auction_type?>"=="Dutch auction")  // Show the information of item in Dutch auction.
    {
        window.onload = function () {
                $.ajax({
                    url: 'Back-end/Dutch_auction_price.php',
                    type: 'post',
                    data: {
                        auction_id:'<?php echo $auction_id?>',
                    },
                    dataType: 'json',
                    success: function (data) {
                        var span = document.createElement('span');
                        span.value = data;

                        var html = "";
                        html += `
                        <p>Current price:<span class="regular-price">￡${data}</span></p>`
                        $('#tbody').html(html);
                    }
                })
        }
    }

</script>
</body>
</html>
