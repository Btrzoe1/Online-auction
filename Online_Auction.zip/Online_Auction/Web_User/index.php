<!doctype html>
<head>
    <meta charset="utf-8">
    <meta http-equiv="x-ua-compatible" content="ie=edge">
    <title>Online Auction | E-auction</title>
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <link rel="stylesheet" href="css/jquery.fancybox.css">
    <link rel="stylesheet" href="css/nivo-slider.css">
    <link rel="stylesheet" href="css/owl.carousel.css">
    <link rel="stylesheet" href="css/font-awesome.min.css">
    <link rel="stylesheet" href="css/bootstrap.min.css">
    <link rel="stylesheet" href="css/style.css">
    <link rel="stylesheet" href="css/responsive.css">
    <script src="../js/vendor/html5shiv.min.js"></script>
    <script src="../js/vendor/respond.min.js"></script>
    <script src="../js/script.js"></script>
</head>
<body>

<header class="header-area">
    <?php
    require_once "header.php";
    require_once '../Database/database.php';
    $dbh = connectDBPDO();
    $statement=$dbh->query("SELECT b.product_id,picture,product_name,current_price FROM Auction a,Product b WHERE a.product_id=b.product_id AND a.auction_status='available' ORDER BY a.auction_id DESC");
    $statement1=$dbh->query("SELECT b.product_id,picture,product_name,current_price FROM Auction a,Product b WHERE a.product_id=b.product_id AND a.auction_status='available' ORDER BY a.bid_times DESC");

    ?>
    <!-- header-bottom start -->
    <div class="header-bottom">
        <div class="container">
            <div class="header-bottom-bg">
                <div class="row">
                    <!-- mainmenu start -->
                    <div class="col-xs-12 col-md-9">
                        <div class="mainmenu">
                            <nav>
                                <ul>
                                    <li class="active"><a href="index.php">Home</a><i class="fa fa-angle-down"></i></li>
                                    <li><a href="Shop_list.php?auction_type=English auction">English Auction</a></li>
                                    <li><a href="Shop_list.php?auction_type=Dutch auction">Dutch Auction</a></li>
                                    <li><a href="Shop_list.php?auction_type=Repeated second-bid auction">Repeated second-bid Auction</a></li>
                                    <li><a href="Contact_us.php">Contact Us</a></li>
                                </ul>
                            </nav>
                        </div>
                    </div>
                    <!-- mainmenu end -->
                </div>
            </div>
        </div>
        <!-- header-bottom end -->
</header>
<!-- header-area end -->
<!-- slider-area start -->
<div class="slider-area">
    <div class="container">
        <div class="row">
            <!-- block-img-add start -->
            <div class="col-xs-12 col-sm-12 col-md-4">
                <div class="block-img-add-2">
                    <div class="single-image-add">
                        <a href="English_auction.php"><img src="../img/home/English_auction.jpg"/></a>
                    </div>
                    <div class="single-image-add">
                        <a href="Dutch_auction.php"><img src="../img/home/Dutch_auction.jpg" /></a>
                    </div>
                    <div class="single-image-add">
                        <a href="Repeated_second-bid_auction.php"><img src="../img/home/Repeat_second-bid_auction.jpg"/></a>
                    </div>
                </div>
            </div>
            <!-- block-img-add end -->
            <!-- slider start -->
            <div class="col-xs-12 col-sm-12 col-md-8">
                <div id="mainSlider" class="nivoSlider">
                    <a><img src="../img/home/slider1.jpg"/></a>
                    <a href="Single_product.php?product=1"><img src="../img/home/slider2.jpg"/></a>
                </div>
                <div id="htmlcaption1" class="nivo-html-caption progress-cap">
                    <div class="slider-progress"></div>
                </div>
                <div id="htmlcaption2" class="nivo-html-caption progress-cap">
                    <div class="slider-progress"></div>
                </div>

            </div>
            <!-- slider end -->
        </div>
    </div>
</div>
<!-- slider-area end -->

<!-- Popular auctions area start -->
<section class="tab-carousel-product">
    <div class="container">
        <div class="row">
            <div class="tab-product-area">
                <div class="Mostview-sec-heading section-heading">
                    <h2><span>Quick</span>View</h2>
                    <div class="tab-carousel-menu">
                        <ul class="nav nav-tabs product-nav">
                            <li class="active"><p><a href="#newest" data-toggle="tab">Newest auction</a></p></li>
                            <li><p><a href="#popular" data-toggle="tab">Popular auction</a></p></li>
                        </ul>
                    </div>
                    <!-- tabs menu end -->
                </div>
                <!-- tab content start -->
                <div class="tab-content">
                    <!-- tabs one start -->
                    <div role="tabpanel" class="tab-pane active" id="newest">
                        <div class="tab-content-area tab-carousel-1">
                            <div class="product-carousel-1">
                                <!-- single-item start -->
                                <div class="item">
                                    <!-- single-product-item start -->
                                    <div class="single-product-item">
                                        <div class="product-image">
                                            <?php $row=$statement->fetch(PDO::FETCH_ASSOC);?>
                                            <img style="height: 211px" src="../img/product/<?php echo $row['picture']?>" alt="product image" />
                                        </div>
                                        <div class="single-product-text">
                                            <h2><a class="product-title"><?php echo $row['product_name']?></a></h2>
                                            <div class="product-price">
                                                <span class="regular-price">￡<?php echo $row['current_price']?></span>
                                            </div>
                                            <div class="quick-view">
                                                <p><a href="Single_product.php?product=<?php echo $row['product_id']?>" title="Quick view">Quick view</a></p>
                                            </div>
                                        </div>
                                    </div>
                                    <!-- single-product-item end -->
                                    <!-- single-product-item start -->
                                    <div class="single-product-item">
                                        <div class="product-image">
                                            <?php $row=$statement->fetch(PDO::FETCH_ASSOC);?>
                                            <img style="height: 211px" src="../img/product/<?php echo $row['picture']?>" alt="product image" />
                                        </div>
                                        <div class="single-product-text">
                                            <h2><a class="product-title"><?php echo $row['product_name']?></a></h2>
                                            <div class="product-price">
                                                <span class="regular-price">￡<?php echo $row['current_price']?></span>
                                            </div>
                                            <div class="quick-view">
                                                <p><a href="Single_product.php?product=<?php echo $row['product_id']?>" title="Quick view">Quick view</a></p>
                                            </div>
                                        </div>
                                    </div>
                                    <!-- single-product-item end -->
                                </div>
                                <!-- single-item end -->
                                <!-- single-item start -->
                                <div class="item">
                                    <!-- single-product-item start -->
                                    <div class="single-product-item">
                                        <div class="product-image">
                                            <?php $row=$statement->fetch(PDO::FETCH_ASSOC);?>
                                            <img style="height: 211px" src="../img/product/<?php echo $row['picture']?>" alt="product image" />
                                        </div>
                                        <div class="single-product-text">
                                            <h2><a class="product-title"><?php echo $row['product_name']?></a></h2>
                                            <div class="product-price">
                                                <span class="regular-price">￡<?php echo $row['current_price']?></span>
                                            </div>
                                            <div class="quick-view">
                                                <p><a href="Single_product.php?product=<?php echo $row['product_id']?>" title="Quick view">Quick view</a></p>
                                            </div>
                                        </div>
                                    </div>
                                    <!-- single-product-item end -->
                                    <!-- single-product-item start -->
                                    <div class="single-product-item">
                                        <div class="product-image">
                                            <?php $row=$statement->fetch(PDO::FETCH_ASSOC);?>
                                            <img style="height: 211px" src="../img/product/<?php echo $row['picture']?>" alt="product image" />
                                        </div>
                                        <div class="single-product-text">
                                            <h2><a class="product-title"><?php echo $row['product_name']?></a></h2>
                                            <div class="product-price">
                                                <span class="regular-price">￡<?php echo $row['current_price']?></span>
                                            </div>
                                            <div class="quick-view">
                                                <p><a href="Single_product.php?product=<?php echo $row['product_id']?>" title="Quick view">Quick view</a></p>
                                            </div>
                                        </div>
                                    </div>
                                    <!-- single-product-item end -->
                                </div>
                                <!-- single-item end -->
                                <!-- single-item start -->
                                <div class="item">
                                    <!-- single-product-item start -->
                                    <div class="single-product-item">
                                        <div class="product-image">
                                            <?php $row=$statement->fetch(PDO::FETCH_ASSOC);?>
                                            <img style="height: 211px" src="../img/product/<?php echo $row['picture']?>" alt="product image" />
                                        </div>
                                        <div class="single-product-text">
                                            <h2><a class="product-title"><?php echo $row['product_name']?></a></h2>
                                            <div class="product-price">
                                                <span class="regular-price">￡<?php echo $row['current_price']?></span>
                                            </div>
                                            <div class="quick-view">
                                                <p><a href="Single_product.php?product=<?php echo $row['product_id']?>" title="Quick view">Quick view</a></p>
                                            </div>
                                        </div>
                                    </div>
                                    <!-- single-product-item end -->
                                    <!-- single-product-item start -->
                                    <div class="single-product-item">
                                        <div class="product-image">
                                            <?php $row=$statement->fetch(PDO::FETCH_ASSOC);?>
                                            <img style="height: 211px" src="../img/product/<?php echo $row['picture']?>" alt="product image" />
                                        </div>
                                        <div class="single-product-text">
                                            <h2><a class="product-title"><?php echo $row['product_name']?></a></h2>
                                            <div class="product-price">
                                                <span class="regular-price">￡<?php echo $row['current_price']?></span>
                                            </div>
                                            <div class="quick-view">
                                                <p><a href="Single_product.php?product=<?php echo $row['product_id']?>" title="Quick view">Quick view</a></p>
                                            </div>
                                        </div>
                                    </div>
                                    <!-- single-product-item end -->
                                </div>
                                <!-- single-item end -->
                                <!-- single-item start -->
                                <div class="item">
                                    <!-- single-product-item start -->
                                    <div class="single-product-item">
                                        <div class="product-image">
                                            <?php $row=$statement->fetch(PDO::FETCH_ASSOC);?>
                                            <img style="height: 211px" src="../img/product/<?php echo $row['picture']?>" alt="product image" />
                                        </div>
                                        <div class="single-product-text">
                                            <h2><a class="product-title"><?php echo $row['product_name']?></a></h2>
                                            <div class="product-price">
                                                <span class="regular-price">￡<?php echo $row['current_price']?></span>
                                            </div>
                                            <div class="quick-view">
                                                <p><a href="Single_product.php?product=<?php echo $row['product_id']?>" title="Quick view">Quick view</a></p>
                                            </div>
                                        </div>
                                    </div>
                                    <!-- single-product-item end -->
                                    <!-- single-product-item start -->
                                    <div class="single-product-item">
                                        <div class="product-image">
                                            <?php $row=$statement->fetch(PDO::FETCH_ASSOC);?>
                                            <img style="height: 211px" src="../img/product/<?php echo $row['picture']?>" alt="product image" />
                                        </div>
                                        <div class="single-product-text">
                                            <h2><a class="product-title"><?php echo $row['product_name']?></a></h2>
                                            <div class="product-price">
                                                <span class="regular-price">￡<?php echo $row['current_price']?></span>
                                            </div>
                                            <div class="quick-view">
                                                <p><a href="Single_product.php?product=<?php echo $row['product_id']?>" title="Quick view">Quick view</a></p>
                                            </div>
                                        </div>
                                    </div>
                                    <!-- single-product-item end -->
                                </div>
                                <!-- single-item end -->
                                <!-- single-item start -->
                                <div class="item">
                                    <!-- single-product-item start -->
                                    <div class="single-product-item">
                                        <div class="product-image">
                                            <?php $row=$statement->fetch(PDO::FETCH_ASSOC);?>
                                            <img style="height: 211px" src="../img/product/<?php echo $row['picture']?>" alt="product image" />
                                        </div>
                                        <div class="single-product-text">
                                            <h2><a class="product-title"><?php echo $row['product_name']?></a></h2>
                                            <div class="product-price">
                                                <span class="regular-price">￡<?php echo $row['current_price']?></span>
                                            </div>
                                            <div class="quick-view">
                                                <p><a href="Single_product.php?product=<?php echo $row['product_id']?>" title="Quick view">Quick view</a></p>
                                            </div>
                                        </div>
                                    </div>
                                    <!-- single-product-item end -->
                                    <!-- single-product-item start -->
                                    <div class="single-product-item">
                                        <div class="product-image">
                                            <?php $row=$statement->fetch(PDO::FETCH_ASSOC);?>
                                            <img style="height: 211px" src="../img/product/<?php echo $row['picture']?>" alt="product image" />
                                        </div>
                                        <div class="single-product-text">
                                            <h2><a class="product-title"><?php echo $row['product_name']?></a></h2>
                                            <div class="product-price">
                                                <span class="regular-price">￡<?php echo $row['current_price']?></span>
                                            </div>
                                            <div class="quick-view">
                                                <p><a href="Single_product.php?product=<?php echo $row['product_id']?>" title="Quick view">Quick view</a></p>
                                            </div>
                                        </div>
                                    </div>
                                    <!-- single-product-item end -->
                                </div>
                                <!-- single-item end -->
                            </div>
                        </div>
                    </div>
                    <!-- tabs one end -->
                    <div role="tabpanel" class="tab-pane" id="popular">
                        <div class="tab-content-area tab-carousel-1">
                            <div class="product-carousel-1">
                                <!-- single-item start -->
                                <div class="item">
                                    <!-- single-product-item start -->
                                    <div class="single-product-item">
                                        <div class="product-image">
                                            <?php $row1=$statement1->fetch(PDO::FETCH_ASSOC);?>
                                            <img style="height: 211px" src="../img/product/<?php echo $row1['picture']?>" alt="product image" />
                                        </div>
                                        <div class="single-product-text">
                                            <h2><a class="product-title"><?php echo $row1['product_name']?></a></h2>
                                            <div class="product-price">
                                                <span class="regular-price">￡<?php echo $row1['current_price']?></span>
                                            </div>
                                            <div class="quick-view">
                                                <p><a href="Single_product.php?product=<?php echo $row1['product_id']?>" title="Quick view">Quick view</a></p>
                                            </div>
                                        </div>
                                    </div>
                                    <!-- single-product-item end -->
                                    <!-- single-product-item start -->
                                    <div class="single-product-item">
                                        <div class="product-image">
                                            <?php $row1=$statement1->fetch(PDO::FETCH_ASSOC);?>
                                            <img style="height: 211px" src="../img/product/<?php echo $row1['picture']?>" alt="product image" />
                                        </div>
                                        <div class="single-product-text">
                                            <h2><a class="product-title"><?php echo $row1['product_name']?></a></h2>
                                            <div class="product-price">
                                                <span class="regular-price">￡<?php echo $row1['current_price']?></span>
                                            </div>
                                            <div class="quick-view">
                                                <p><a href="Single_product.php?product=<?php echo $row1['product_id']?>" title="Quick view">Quick view</a></p>
                                            </div>
                                        </div>
                                    </div>
                                    <!-- single-product-item end -->
                                </div>
                                <!-- single-item end -->
                                <!-- single-item start -->
                                <div class="item">
                                    <!-- single-product-item start -->
                                    <div class="single-product-item">
                                        <div class="product-image">
                                            <?php $row1=$statement1->fetch(PDO::FETCH_ASSOC);?>
                                            <img style="height: 211px" src="../img/product/<?php echo $row1['picture']?>" alt="product image" />
                                        </div>
                                        <div class="single-product-text">
                                            <h2><a class="product-title"><?php echo $row1['product_name']?></a></h2>
                                            <div class="product-price">
                                                <span class="regular-price">￡<?php echo $row1['current_price']?></span>
                                            </div>
                                            <div class="quick-view">
                                                <p><a href="Single_product.php?product=<?php echo $row1['product_id']?>" title="Quick view">Quick view</a></p>
                                            </div>
                                        </div>
                                    </div>
                                    <!-- single-product-item end -->
                                    <!-- single-product-item start -->
                                    <div class="single-product-item">
                                        <div class="product-image">
                                            <?php $row1=$statement1->fetch(PDO::FETCH_ASSOC);?>
                                            <img style="height: 211px" src="../img/product/<?php echo $row1['picture']?>" alt="product image" />
                                        </div>
                                        <div class="single-product-text">
                                            <h2><a class="product-title"><?php echo $row1['product_name']?></a></h2>
                                            <div class="product-price">
                                                <span class="regular-price">￡<?php echo $row1['current_price']?></span>
                                            </div>
                                            <div class="quick-view">
                                                <p><a href="Single_product.php?product=<?php echo $row1['product_id']?>" title="Quick view">Quick view</a></p>
                                            </div>
                                        </div>
                                    </div>
                                    <!-- single-product-item end -->
                                </div>
                                <!-- single-item end -->
                                <!-- single-item start -->
                                <div class="item">
                                    <!-- single-product-item start -->
                                    <div class="single-product-item">
                                        <div class="product-image">
                                            <?php $row1=$statement1->fetch(PDO::FETCH_ASSOC);?>
                                            <img style="height: 211px" src="../img/product/<?php echo $row1['picture']?>" alt="product image" />
                                        </div>
                                        <div class="single-product-text">
                                            <h2><a class="product-title"><?php echo $row1['product_name']?></a></h2>
                                            <div class="product-price">
                                                <span class="regular-price">￡<?php echo $row1['current_price']?></span>
                                            </div>
                                            <div class="quick-view">
                                                <p><a href="Single_product.php?product=<?php echo $row1['product_id']?>" title="Quick view">Quick view</a></p>
                                            </div>
                                        </div>
                                    </div>
                                    <!-- single-product-item end -->
                                    <!-- single-product-item start -->
                                    <div class="single-product-item">
                                        <div class="product-image">
                                            <?php $row1=$statement1->fetch(PDO::FETCH_ASSOC);?>
                                            <img style="height: 211px" src="../img/product/<?php echo $row1['picture']?>" alt="product image" />
                                        </div>
                                        <div class="single-product-text">
                                            <h2><a class="product-title"><?php echo $row1['product_name']?></a></h2>
                                            <div class="product-price">
                                                <span class="regular-price">￡<?php echo $row1['current_price']?></span>
                                            </div>
                                            <div class="quick-view">
                                                <p><a href="Single_product.php?product=<?php echo $row1['product_id']?>" title="Quick view">Quick view</a></p>
                                            </div>
                                        </div>
                                    </div>
                                    <!-- single-product-item end -->
                                </div>
                                <!-- single-item end -->
                                <!-- single-item start -->
                                <div class="item">
                                    <!-- single-product-item start -->
                                    <div class="single-product-item">
                                        <div class="product-image">
                                            <?php $row1=$statement1->fetch(PDO::FETCH_ASSOC);?>
                                            <img style="height: 211px" src="../img/product/<?php echo $row1['picture']?>" alt="product image" />
                                        </div>
                                        <div class="single-product-text">
                                            <h2><a class="product-title"><?php echo $row1['product_name']?></a></h2>
                                            <div class="product-price">
                                                <span class="regular-price">￡<?php echo $row1['current_price']?></span>
                                            </div>
                                            <div class="quick-view">
                                                <p><a href="Single_product.php?product=<?php echo $row1['product_id']?>" title="Quick view">Quick view</a></p>
                                            </div>
                                        </div>
                                    </div>
                                    <!-- single-product-item end -->
                                    <!-- single-product-item start -->
                                    <div class="single-product-item">
                                        <div class="product-image">
                                            <?php $row1=$statement1->fetch(PDO::FETCH_ASSOC);?>
                                            <img style="height: 211px" src="../img/product/<?php echo $row1['picture']?>" alt="product image" />
                                        </div>
                                        <div class="single-product-text">
                                            <h2><a class="product-title"><?php echo $row1['product_name']?></a></h2>
                                            <div class="product-price">
                                                <span class="regular-price">￡<?php echo $row1['current_price']?></span>
                                            </div>
                                            <div class="quick-view">
                                                <p><a href="Single_product.php?product=<?php echo $row1['product_id']?>" title="Quick view">Quick view</a></p>
                                            </div>
                                        </div>
                                    </div>
                                    <!-- single-product-item end -->
                                </div>
                                <!-- single-item end -->
                                <!-- single-item start -->
                                <div class="item">
                                    <!-- single-product-item start -->
                                    <div class="single-product-item">
                                        <div class="product-image">
                                            <?php $row1=$statement1->fetch(PDO::FETCH_ASSOC);?>
                                            <img style="height: 211px" src="../img/product/<?php echo $row1['picture']?>" alt="product image" />
                                        </div>
                                        <div class="single-product-text">
                                            <h2><a class="product-title"><?php echo $row1['product_name']?></a></h2>
                                            <div class="product-price">
                                                <span class="regular-price">￡<?php echo $row1['current_price']?></span>
                                            </div>
                                            <div class="quick-view">
                                                <p><a href="Single_product.php?product=<?php echo $row1['product_id']?>" title="Quick view">Quick view</a></p>
                                            </div>
                                        </div>
                                    </div>
                                    <!-- single-product-item end -->
                                    <!-- single-product-item start -->
                                    <div class="single-product-item">
                                        <div class="product-image">
                                            <?php $row1=$statement1->fetch(PDO::FETCH_ASSOC);?>
                                            <img style="height: 211px" src="../img/product/<?php echo $row1['picture']?>" alt="product image" />
                                        </div>
                                        <div class="single-product-text">
                                            <h2><a class="product-title"><?php echo $row1['product_name']?></a></h2>
                                            <div class="product-price">
                                                <span class="regular-price">￡<?php echo $row1['current_price']?></span>
                                            </div>
                                            <div class="quick-view">
                                                <p><a href="Single_product.php?product=<?php echo $row1['product_id']?>" title="Quick view">Quick view</a></p>
                                            </div>
                                        </div>
                                    </div>
                                    <!-- single-product-item end -->
                                </div>
                                <!-- single-item end -->
                            </div>
                        </div>
                    </div>
                </div>
                <!-- tab content end -->
            </div>
        </div>
    </div>
</section>
<!-- Popular auctions area end -->
<?php
require_once "footer.php";
?>

<script src="../js/vendor/jquery-1.11.3.min.js"></script>
<script src="../js/jqueryui.js"></script>
<script src="../js/jquery.meanmenu.js"></script>
<script src="../js/jquery.fancybox.js"></script>
<script src="../js/jquery.elevatezoom.js"></script>
<script src="../js/bootstrap.min.js"></script>
<script src="../js/owl.carousel.min.js"></script>
<script src="../js/jquery.nivo.slider.pack.js"></script>
<script src="../js/main.js"></script>
<script src="../js/main.js"></script>
<script>
    // Record the amount of visitors.
    window.onload = function () {
        $.ajax({
            url: 'Back-end/Pageview.php',
            data:{},
            type: "post",
            dataType: 'json',
            success: function (data) {
            }
        })
    }
</script>

</body>
</html>
