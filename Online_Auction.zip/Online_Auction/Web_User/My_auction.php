<!doctype html>
<!--[if IE 9]> <html class="no-js ie9" lang="en"> <![endif]-->
<!--[if gt IE 9]><!--> <html class="no-js " lang="en"> <!--<![endif]-->
<head>
    <meta charset="utf-8">
    <meta http-equiv="x-ua-compatible" content="ie=edge">
    <title>Online Auction | E-auction</title>
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <link rel="stylesheet" href="css/bootstrap.min.css">
    <link rel="stylesheet" href="css/style.css">
    <link rel="stylesheet" href="css/font-awesome.min.css">
    <link rel="stylesheet" href="css/responsive.css">
    <script src="../js/script.js"></script>
</head>
<body>
<header class="header-area">
    <?php
    require_once '../Database/database.php';
    require_once "header.php";
    ?>
</header>
<section class="main-content-area">
    <div class="container">
        <div class="row">
            <div class="col-xs-12 col-sm-12 col-md-3 col-lg-3">
                <div class="single-sidebar myaccount-info-area">
                    <h2>My Account</h2>
                    <div class="myaccount-info">
                        <ul>
                            <li><a href="My_account.php">My Details</a></li>
                            <li class="active"><a href="My_account.php">My Auctions</a></li>
                            <li><a href="Bidding_history.php">Bidding History</a></li>
                            <li><a href="Win_auction.php">Win Auction</a></li>
                        </ul>
                    </div>
                </div>
            </div>
            <div class="col-xs-12 col-sm-12 col-md-9 col-lg-9">
                <div class="myaccount-dashboard-area cart-page-main-area">
                    <div class="sec-heading-area">
                        <input type="hidden" id="user_id" name="user_id" value="<?php echo $_SESSION['User']['user_id']?>">
                        <h2>My Auctions</h2>
                    </div>
                    <div class="myaccount-dashboard">
                        <p>You can track and manage your auction, but you can't change the information.</p>
                        <div class="acc-information">
                            <div class="card-header">
                                <button type="button" id="getAll" class="btn btn-success">All my Auction</button>
                                <div class="card-tools">
                                    <div class="input-group input-group-sm">
                                        <input type="text" class="form-control" id="searchInput" placeholder="Product name">
                                        <span class="input-group-append"><button type="button" id="get" class="search-btn">Search</button>
                                        <button type="button" style="margin-left:3px;margin-bottom: 15px;" onclick="checkid()" class="search-btn">Add new auction</button></span>
                                    </div>
                                </div>
                            </div>
                            <div class="modal fade" id="addModal" tabindex="-1" role="dialog" aria-labelledby="addModalLabel">
                                <div class="modal-dialog" role="document">
                                    <div class="modal-content">
                                        <div class="addmodal-header">
                                            <h4 class="addmodal-title" id="addModalLabel">Add new auction</h4>
                                        </div>
                                        <div class="addmodal-body">
                                            <form id="addform" onsubmit="return checktime()" action="Back-end/Add_auction.php" method="post" role="form"  enctype="multipart/form-data">
                                                <label style="width:100%">Auction type:</label><input type="hidden" id="id" name="id" value="<?php echo $_SESSION['User']['user_id']?>">
                                                <div>
                                                    <input id="add_auction_type" type="radio" name="auction_type" style="margin-right: 5px" value="English auction" checked="checked">English auction
                                                    <input id="add_auction_type" type="radio" name="auction_type" style="margin-right: 5px" value="Dutch auction" >Dutch auction
                                                    <input id="add_auction_type" type="radio" name="auction_type" style="margin-right: 5px" value="Repeated second-bid auction" >Repeated second-bid auction
                                                </div>
                                                <div style="float:left; width:52%">
                                                    <label>Auction start time:</label><input id="add_auction_starttime" type="datetime-local" style="width:90%" name="add_auction_starttime" class="form-control" required="">
                                                </div>
                                                <div style="float:left; width:48%">
                                                    <label>Auction end time:</label><input id="add_auction_endtime" type="datetime-local" style="width:100%" name="add_auction_endtime" class="form-control" required="">
                                                </div>
                                                <div style="float:left; width:52%">
                                                    <label>Product name:</label><input id="add_auction_name" type="text" style="width:90%;" name="add_auction_name" class="form-control" required="">
                                                </div>
                                                <div style="float:left; width:45%">
                                                    <label style="margin-right: 20px" >Product type:</label>
                                                    <select  style="width: 50%;margin-right: 20%" name="add_product_type">
                                                        <option value="All Categories">All Categories</option>
                                                        <option value="Electronics">Electronics</option>
                                                        <option value="Appliances">Appliances</option>
                                                        <option value="Fashion">Fashion</option>
                                                        <option value="Sports">Sports</option>
                                                        <option value="Beauty">Beauty</option>
                                                        <option value="Health">Health</option>
                                                        <option value="Kids">Kids</option>
                                                        <option value="Accessories">Accessories</option>
                                                    </select>
                                                </div>
                                                <div style="width: 50%">
                                                <label>Product description:</label><input id="add_auction_description" type="text" style="width:100%" name="add_auction_description" class="form-control" required="">
                                                </div>
                                                <label>Auction starting price: ￡</label><input id="add_auction_price" onkeyup="value=value.replace(/[^\d^\.]+/g,'')" type="text" style="width:100%" name="add_auction_price" class="form-control" required="">
                                                <label for="Picturebox">Product prcture: </label><input type="file" class="form-control" id="add_auction_picture" name="Fimage" required="">
                                                <div id="image" style="height:100px;width:100px;"><img height="90px" src="" ></div>
                                                <div>
                                                    <input type="button" class="btn btn-default" data-dismiss="modal" value="Cancel">
                                                    <input type="submit" name="add-auction" class="btn btn-success" value="Add auction">
                                                </div>
                                            </form>
                                        </div>
                                    </div>
                                </div>
                            </div>
                            <div class="card-body">
                                <table class="table card-text">
                                    <tr>
                                        <th scope="row">Product Name</th>
                                        <th>Picture</th>
                                        <th>Time</th>
                                        <th>Current Price</th>
                                        <th>Auction Type</th>
                                        <th>Operation</th>
                                    </tr>
                                    <tbody id='tbody'>
                                    </tbody>
                                </table>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</section>
<?php
require_once "footer.php";
?>
<script src="../js/vendor/jquery-1.11.3.min.js"></script>
<script src="../js/bootstrap.min.js"></script>
<script>
    document.getElementById('add_auction_picture').onchange = function() {
        var imgFile = this.files[0];
        var fr = new FileReader();
        fr.onload = function() {
            document.getElementById('image').getElementsByTagName('img')[0].src = fr.result;
        };
        fr.readAsDataURL(imgFile);
    };

    function checktime(){
        var auction_starttime = $('#add_auction_starttime').val();
        var start = new Date(auction_starttime);
        var start_time = start.getTime();

        var auction_endtime = $('#add_auction_endtime').val();
        var end = new Date(auction_endtime);
        var end_time = end.getTime();

        var timestamp = Date.parse(new Date());
        if(start_time<=timestamp){
            alert("Start time should be later than the current time！");
            return false;
        }else if(end_time<=start_time) {
            alert("End time should be later than start time！");
            return false;
        }
        return true;
    }

    function checkid(){
        <?php
        $dbh=connectDBPDO();
        $select_authentication=$dbh->query("SELECT authentication FROM User WHERE user_id='".$_SESSION['User']['user_id']."'");
        $get_authentication=$select_authentication->fetch(PDO::FETCH_ASSOC);?>
        console.log('<?php echo $get_authentication['authentication']?>');
        if("<?php echo $get_authentication['authentication']?>"== "0"){
            alert("In order to ensure the authenticity of your auction, you must pass the identity authentication. " +
                "Please go to your account and upload document!");
        }else{
            $('#addModal').modal('show');
        }
    }
</script>
<script>
    var web = {
        init: function () {
            var user_id =$("#user_id").val();
            var data = {
                user_id:user_id,
            }
            this.getAll(data);
            this.eleBind();
        },
        eleBind: function () {
            // Search all auction.
            $('#getAll').click(function () {
                var user_id =$("#user_id").val();
                var data = {
                    user_id:user_id,
                }
                web.getAll(data);
            })
            // Search single auction
            $('#get').click(function () {
                var product_name = $("#searchInput").val();
                var user_id =$("#user_id").val();
                var data = {
                    user_id:user_id,
                    product_name: product_name
                }
                web.getData(data);
            })
            // Delete auction or check whether the auction starts or not.
            $('#tbody').click(function (e) {
                    let type = $(e.target).attr("data-type");
                    let id = $(e.target).attr("data-id");
                    var date='<?php echo $now=gmdate("Y-m-d H:i:s",strtotime("+1 hour")); ?>';
                    var current=new Date(date);
                    var current_time=current.getTime();
                    var start = new Date(id);
                    var start_time=start.getTime();
                    if(type === 'notify' && id){
                        if(start_time>current_time){
                            alert("The auction hasn't started yet!");
                            return false;
                        }
                    }
                    if (type === 'del' && id) {
                        var gnl=confirm("Confirm to delete your bidding?");
                        if (gnl==true){
                        web.delDate(id);
                    }else{
                            return false;
                        }
                }
            })
        },
        getAll: function (data) {
            $.ajax({
                url: "Back-end/Manage_auction.php",
                type: "post",
                data: {
                    user_id: data.user_id,
                    type: 'get',
                    product_name: 'null'
                },
                datatype: 'json',
                success: function (data) {
                    web.setData(data);
                },
            });
        },
        getData: function (data) {
            $.ajax({
                url: "Back-end/Manage_auction.php",
                type: "post",
                data: {
                    user_id: data.user_id,
                    product_name: data.product_name,
                    type: 'get'
                },
                datatype: 'json',
                success: function (data) {
                    web.setData(data);
                },
                error: function(){
                }
            })
        },
        delDate: function(id) {
            $.ajax({
                url: "Back-end/Manage_auction.php",
                type: "post",
                data: {
                    auction_id: id,
                    type: 'del'
                },
                datatype: "json",
                success: function(data) {
                    alert('Delete successfully!');
                    var user_id =$("#user_id").val();
                    var id = {
                        user_id:user_id,
                    }
                    web.getAll(id);
                }
            })
        },
        // Show all my auctions.
        setData: function (data) {
            var html = "";
            data.forEach(function (data, index, array) {
                html += `
                        <tr>
                            <td scope="row"><a data-type='notify' data-id='${data.start_time}' href="Single_product.php?product=${data.product_id}">${data.product_name}</a></td>
                            <td><img src= "${data.picture}" height="100vw" width="100vw" alt=""></td>
                            <td>${data.start_time} To ${data.end_time} </td>
                            <td class="auction-price">￡${data.current_price}</td>
                            <td >${data.auction_type} </td>
                            <td><button data-type='del' data-id='${data.start_time}' class="btn btn-danger" >Delete</button>
                        </tr>`
            })
            $('#tbody').html(html);
        }
    }

    $(document).ready(function () {
        web.init()
    })

</script>
</body>
</html>