<?php
require_once '../../Database/database.php';

$dbh = connectDBPDO();
$auction_id=$_POST['auction_id'];
$statement=$dbh->query("SELECT start_time,highest_price FROM Auction WHERE auction_id='$auction_id'");
$row=$statement->fetch(PDO::FETCH_ASSOC);
$start_time=$row['start_time'];
$highest_price=$row['highest_price'];
define("price_d", 3);
define("price_end", 10);

$time_s = strtotime($start_time);
$time_t = time();
$time = date('Y-m-d H:i:s', time());

$price = $highest_price-intval((intval($time_t)-intval($time_s))/3600)*price_d;

if ($price<=price_end){
    $price =price_end;
}
$statement1=$dbh->query("UPDATE Auction SET current_price='$price' WHERE auction_id='$auction_id'");
echo json_encode($price);
$conn = null;
?>