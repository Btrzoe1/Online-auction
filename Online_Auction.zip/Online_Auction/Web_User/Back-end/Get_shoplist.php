<?php
header("content-type:application/json;charset=utf-8");
require_once '../../Database/database.php';
$dbh = connectDBPDO();
$auction_type=$_POST['auction_type'];
$product_type=$_POST['product_type'];
$sortby=$_POST['sortby'];
if ($product_type==""||$product_type=="null"||$product_type=="All_category"){
    if($sortby==""||$sortby=="null"||$sortby=="newest") {
            $statement = $dbh->query(
                "SELECT b.product_id,product_name,picture,current_price,auction_type,description
                       FROM Auction a,Product b
                       WHERE a.auction_type='$auction_type' AND a.auction_status='available' AND a.product_id=b.product_id ORDER BY a.auction_id DESC;");
    }else if($sortby=="lowprice"){
            $statement = $dbh->query(
                "SELECT b.product_id,product_name,picture,current_price,auction_type,description
                       FROM Auction a,Product b
                       WHERE a.auction_type='$auction_type' AND a.auction_status='available' AND a.product_id=b.product_id ORDER BY a.current_price ;");
    }else{
            $statement = $dbh->query(
                "SELECT b.product_id,product_name,picture,current_price,auction_type,description
                       FROM Auction a,Product b
                       WHERE a.auction_type='$auction_type' AND a.auction_status='available' AND a.product_id=b.product_id ORDER BY a.current_price DESC;");
    }
}
else{
    if($sortby=="null"||$sortby=="newest"){
        $statement = $dbh->query(
            "SELECT b.product_id,product_name,picture,current_price,auction_type,description
                       FROM Auction a,Product b
                       WHERE a.auction_type='$auction_type' AND a.auction_status='available' AND b.product_type='$product_type' AND a.product_id=b.product_id ORDER BY a.auction_id DESC;");
    }else if($sortby=="lowprice"){
        $statement = $dbh->query(
            "SELECT b.product_id,product_name,picture,current_price,auction_type,description
                       FROM Auction a,Product b
                       WHERE a.auction_type='$auction_type' AND a.auction_status='available' AND a.product_id=b.product_id AND b.product_type='$product_type' ORDER BY a.current_price ;");
    }else {
        $statement = $dbh->query(
            "SELECT b.product_id,product_name,picture,current_price,auction_type,description
                       FROM Auction a,Product b
                       WHERE a.auction_type='$auction_type' AND a.auction_status='available' AND b.product_id=a.product_id AND b.product_type='$product_type' ORDER BY a.current_price DESC;");
    }
}

$sendData = array();


while ($row = $statement->fetch(PDO::FETCH_ASSOC)) {
    array_push($sendData, array(
        'product_id'=>$row['product_id'],
        'product_name' => $row['product_name'],
        'picture' => "../img/product/" .$row['picture'],
        'picture_name' => $row['picture'],
        'current_price' => $row['current_price'],
        'auction_type' => $row['auction_type'],
        'description'=> $row['description'],
    ));
}

echo json_encode($sendData);
$conn = null;
