<?php
require_once('Email.class.php');
use PHPMailer\PHPMailer\PHPMailer;
use PHPMailer\PHPMailer\Exception;
require_once '../../Database/database.php';
$dbh = connectDBPDO();
require '../../PHPMailer-master/src/Exception.php';
require '../../PHPMailer-master/src/PHPMailer.php';
require '../../PHPMailer-master/src/SMTP.php';
$username=$_POST['username'];
$resource = $dbh->query("select auction_id,auction_type,start_time,end_time,auction_id,product_name from Auction AS a, Product AS b WHERE a.product_id=b.product_id AND a.auction_status='available' OR a.auction_status='unavailable'");
$result = $resource->fetchAll(PDO::FETCH_ASSOC);
$time=gmdate("Y-m-d H:i:s",strtotime("+1 hour"));
foreach ($result as $t){
    if($t['start_time'] <=$time && $time<=$t['end_time']){
        $statement=$dbh->query("UPDATE Auction SET auction_status='available' WHERE auction_id='".$t['auction_id']."'");
    }else if($time<$t['start_time']){
        $statement=$dbh->query("UPDATE Auction SET auction_status='unavailable' WHERE auction_id='".$t['auction_id']."'");
    } else{
        $statement=$dbh->query("UPDATE Auction SET auction_status='expired' WHERE auction_id='".$t['auction_id']."'");
        if($t['auction_type']=="English auction"||$t['auction_type']=="Repeat second-bid auction") {
            $statement1 = $dbh->query("SELECT a.user_id,a.bidding_price FROM Bidding AS a , Auction AS b WHERE a.auction_id = b.auction_id AND a.bidding_price=b.highest_price AND a.auction_id='".$t['auction_id']."' ORDER BY a.bid_id");
            $row=$statement1->fetch(PDO::FETCH_ASSOC);
            if($row) {
                $statement2 = $dbh->query("UPDATE Auction SET winner_id='".$row['user_id']."' WHERE auction_id='".$t['auction_id']."'");
                $statement3 = $dbh->query("SELECT username FROM User WHERE user_id='".$row['user_id']."'");
                $row1=$statement3->fetch(PDO::FETCH_ASSOC);
                $username=$row1['username'];
                $mail = new PHPMailer(true);                              // Passing `true` enables exceptions
                try {
                    //Server configure
                    $mail->CharSet = "UTF-8";                     //Set Email compile code

                    $mail->isSMTP();
                    $mail->SMTPDebug = 0; // debugging: 1 = errors and messages, 2 = messages only
                    $mail->SMTPAuth = true; // authentication enabled
                    $mail->SMTPSecure = 'ssl'; // secure transfer enabled REQUIRED for Gmail
                    $mail->Host = "ssl://smtp.163.com";
                    $mail->Port = 465;
                    $mail->IsHTML(true);
                    $mail->Username = "btrzoe@163.com";
                    $mail->Password = "ao15378113114";

                    $mail->setFrom('btrzoe@163.com', 'E-auction');  //Who send Email
                    $mail->addAddress("$username", 'Customer');  //  Add address
                    $mail->addReplyTo("$username", 'info'); // who repley to
                    //Content
                    $mail->isHTML(true);
                    $mail->Subject = 'Win notification' . time();
                    $mail->Body = "<h1>You win the auction!</h1><p>You became the winner of auction '".$t['product_name']."'  with £ ".$row['bidding_price'].", thank you for bidding on our website</p><p>Pay now : http://dingding.ibfpig.com/Web_User/</p>";
                    $mail->AltBody ="<h1>Win auction</h1><p>You became the winner of auction '".$t['product_name']."'  with £$bidding_price, thank you for bidding on our website</p><p>Pay now : http://dingding.ibfpig.com/Web_User/</p>";

                    $mail->send();
                } catch (Exception $e) {
                    echo 'Sent email fail: ', $mail->ErrorInfo;
                }

            }else{
                return;
            }
        }else{
            return;
        }
    }
}

if ($result) {

    print_r(json_encode(array('code'=>'200','success'=>'success','info'=>'success')));

    exit();

}
print_r(json_encode(array('code'=>'400','success'=>'fail','info'=>'')));

exit();