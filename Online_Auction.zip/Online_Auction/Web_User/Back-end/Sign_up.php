<?php

require_once '../../Database/database.php';
$dbh = connectDBPDO();
header("Content-Type: text/html; charset=utf8");
if(!isset($_POST['signUp'])){
exit("Something wrong");
}//Submit operation
$username=$_POST['signup_username'];
$firstname=$_POST['signup_firstname'];
$lastname=$_POST['signup_lastname'];
$role="customer";
$password=$_POST['signup_password'];
$password1=$_POST['signup_confirmpassword'];
$phone=$_POST['signup_phone'];

$salt = "62";
$password_hash = $password . $username . $salt;
$password_hash = hash('sha256', $password_hash);

$statement = $dbh->query(
"SELECT * FROM User WHERE username ='$username';" );
$row = $statement->fetch(PDO::FETCH_ASSOC);
if($row){
header("refresh:3; url=index.php");
echo ("This email has been used.Please try again after 3s.");
}else if($username==""||$firstname==""||$lastname==""||$password==""||$password1==""||$phone==""){
header("refresh:3; url=../index.php");
echo ("Please fill required information");
}else {
    $statement = AddUser($firstname,$lastname,$username,$password_hash,$phone,'','',$role);
if (!$statement) {

header("refresh:3; url=../index.php");
echo "<script>alert('You did`t register successfully!');location.href='../index.php';</script>";//Register fail
exit;
} else {

header("refresh:3; url=../index.php");
echo "<script>alert('Welcome！Please sign in!');location.href='../index.php';</script>";//Register successful
exit;
}
}
