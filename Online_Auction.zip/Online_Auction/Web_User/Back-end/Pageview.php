<?php
require_once '../../Database/database.php';
$now=gmdate("Y-m-d");
echo $now;
$dbh=connectDBPDO();
$statement=$dbh->query("SELECT * FROM Pageview WHERE date='$now'");
$row=$statement->fetch(PDO::FETCH_ASSOC);
if($row){
    $statement1=$dbh->query("UPDATE Pageview SET times=times+1 WHERE date='$now'");
}else{
    $statement1=$dbh->query("INSERT INTO Pageview (date,times) VALUES ('$now','1')");
}

echo json_encode($statement1);
$conn = null;