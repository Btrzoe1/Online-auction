<?php
require_once '../../Database/database.php';
if (isset($_POST['add-auction'])) {
    $user_id=$_POST['id'];
    $auction_type= $_POST['auction_type'];
    $start_time = $_POST['add_auction_starttime'];
    $end_time = $_POST['add_auction_endtime'];
    $product_name = $_POST['add_auction_name'];
    $description = $_POST['add_auction_description'];
    $current_price = $_POST['add_auction_price'];
    $product_type = $_POST['add_product_type'];
    $imgFile = $_FILES['Fimage']['name'];
    $tmp_dir = $_FILES['Fimage']['tmp_name'];
    $imgSize = $_FILES['Fimage']['size'];

    if (empty($auction_type)) {
        echo "<script>alert('Please Enter Auction Type.');location.href='../My_auction.php';</script>";//Register fail
    } else if (empty($start_time)) {
        echo "<script>alert('Please Enter Start Time.');location.href='../My_auction.php';</script>";//Register fail
    } else if (empty($end_time)) {
        echo "<script>alert('Please Enter End Time.');location.href='../My_auction.php';</script>";//Register fail
    } else if (empty($product_name)) {
        echo "<script>alert('Please Enter Product Name.');location.href='../My_auction.php';</script>";//Register fail
    } else if (empty($description)) {
        echo "<script>alert('Please Enter Description.');location.href='../My_auction.php';</script>";//Register fail
    } else if (empty($current_price)) {
        echo "<script>alert('Please Enter Starting Price.');location.href='../My_auction.php';</script>";//Register fail
    } else if (empty($product_type)) {
        echo "<script>alert('Please Enter Product Type.');location.href='../My_auction.php';</script>";//Register fail
    } else if (empty($imgFile)) {
        echo "<script>alert('Please Choose Picture.');location.href='../My_auction.php';</script>";//Register fail
    } else {
        $upload_dir = '../../img/product/'.basename($_FILES['Fimage']['name']); // upload directory

        $imgExt = strtolower(pathinfo($imgFile, PATHINFO_EXTENSION)); // get image extension

        // valid image extensions
        $valid_extensions = array('jpeg', 'jpg', 'png', 'gif'); // valid extensions

        // allow valid image file formats
        if (in_array($imgExt, $valid_extensions)) {
            // Check file size '5MB'
            if ($imgSize < 5000000) {
                move_uploaded_file($tmp_dir, $upload_dir);
            } else {
                die("Sorry, your file is too large.");
            }
        } else {
            die("Sorry, only JPG, JPEG, PNG & GIF files are allowed.");
        }
    }
    // if no error occured, continue ....
    $statement= AddAuction($user_id,$auction_type,$start_time,$end_time,$product_name,$description,$current_price,$product_type,$imgFile);
    if($statement){
        echo "<script>alert('Add auction success!');location.href='../My_auction.php';</script>";
    }else{
        echo "<script>alert('Add auction Fail! Please try again');location.href='../My_auction.php';</script>";
    }
}
?>