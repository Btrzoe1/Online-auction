<?php
require_once '../../Database/database.php';
$dbh = connectDBPDO();

header("Content-Type: text/html; charset=utf8");


if (!isset($_POST['login_username'])) {
    die("User name not define.");
}

if (!isset($_POST['login_password'])) {
    die("Password not define.");
}

$username = filter_input(INPUT_POST, 'login_username', FILTER_SANITIZE_STRING);
$password = filter_input(INPUT_POST, 'login_password', FILTER_SANITIZE_STRING);



$salt = "62";
$password_hash = $password . $username . $salt;
$password_hash = hash('sha256', $password_hash);
try {
    $dbh = connectDBPDO();
    $statement = $dbh->query(
        "SELECT * FROM User WHERE username ='$username' and password = '$password_hash';" );
    $User = $statement->fetch(PDO::FETCH_ASSOC);
    if ($User) {
        session_start();
        $_SESSION['User'] = $User;
        echo "<script>location.href='".$_SERVER["HTTP_REFERER"]."';</script>";
    } else {
        echo "<script>alert('Username or password invalid');location.href='".$_SERVER["HTTP_REFERER"]."';</script>";
    }
} catch (PDOException $e) {
    die ("Error!: " . $e->getMessage() . "<br/>");
}