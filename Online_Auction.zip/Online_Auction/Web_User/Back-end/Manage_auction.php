<?php
header("content-type:application/json;charset=utf-8");
require_once '../../Database/database.php';
$type = addslashes(htmlspecialchars(@$_POST['type']));
if ($type === 'get') {
    get();
}else if($type === 'del'){
    del();
}else if($type==='win'){
    win();
}else if($type==='review'){
    review();
}else if($type==='verify'){
    verify();
}else{
    bidding();
}

function get()
{
    $dbh = connectDBPDO();
    $user_id=$_POST['user_id'];
    $product_name=$_POST['product_name'];
    if ($product_name=="null"){
        $statement = $dbh->query(
            "SELECT auction_id,product_name,picture,start_time,end_time,current_price,auction_type,b.product_id
                       FROM Auction a,Product b,User c 
                       WHERE c.user_id='$user_id' AND c.user_id=a.user_id AND a.product_id=b.product_id;");
    }
    else{
        $statement = $dbh->query(
            "SELECT auction_id,product_name,picture,start_time,end_time,current_price,auction_type,b.product_id
                       FROM Auction a,Product b,User c 
                       WHERE c.user_id='$user_id' AND c.user_id=a.user_id AND a.product_id=b.product_id AND b.product_name LIKE'%$product_name%';");
    }

    $sendData = array();


    while ($row = $statement->fetch(PDO::FETCH_ASSOC)) {
            array_push($sendData, array(
                'auction_id' =>$row['auction_id'],
                'product_name' => $row['product_name'],
                'picture' => "../img/product/" .$row['picture'],
                'start_time' => $row['start_time'],
                'end_time' => $row['end_time'],
                'current_price' => $row['current_price'],
                'auction_type' => $row['auction_type'],
                'product_id'=>$row['product_id']
            ));
    }

    echo json_encode($sendData);
    $conn = null;
}

function del()
{
    $dbh = connectDBPDO();
    $auction_id=$_POST['auction_id'];
    $statement=$dbh->query("SELECT product_id FROM Auction WHERE auction_id='$auction_id'");
    $row=$statement->fetch(PDO::FETCH_ASSOC);
    $product_id=$row['product_id'];

    $statement1=$dbh->query("SELECT picture FROM Product WHERE product_id='$product_id'");
    $row1=$statement1->fetch(PDO::FETCH_ASSOC);
    $picture=$row1['picture'];
    unlink('../../img/product/'.$picture);

    $statement2=$dbh->query("DELETE FROM Auction WHERE auction_id='$auction_id'");
    $statement3=$dbh->query("DELETE FROM Product WHERE product_id='$product_id'");

    echo json_encode($statement3);
    $conn = null;
}
function bidding(){
    $dbh = connectDBPDO();
    $user_id=$_POST['user_id'];
    $statement=$dbh->query("SELECT a.product_id,auction_type,winner_id,product_name,picture,bidding_price,bidding_time FROM Product a,Auction b,Bidding c WHERE c.user_id='$user_id' AND b.auction_id=c.auction_id AND b.product_id=a.product_id ORDER BY bid_id DESC");
    $sendData = array();


    while ($row = $statement->fetch(PDO::FETCH_ASSOC)) {
        if($row['winner_id']==null){
            $result="continue";
        }else if($row['winner_id']==$user_id){
            $result="You win";
        }else{
            $result="You lose";
        };
        array_push($sendData, array(

            'bidding_price' =>$row['bidding_price'],
            'product_name' => $row['product_name'],
            'picture' => "../img/product/" .$row['picture'],
            'bidding_time' => $row['bidding_time'],
            'auction_type' => $row['auction_type'],
            'result'=>$result,
            'product_id'=>$row['product_id'],
        ));
    }

    echo json_encode($sendData);
    $conn = null;
}

function win(){
    $dbh = connectDBPDO();
    $user_id=$_POST['user_id'];
    $statement=$dbh->query("SELECT b.product_id,auction_id,auction_type,product_name,picture,current_price,highest_price FROM Auction a,Product b WHERE a.product_id=b.product_id AND winner_id='$user_id'");
    $sendData = array();


    while ($row = $statement->fetch(PDO::FETCH_ASSOC)) {
        $select=$dbh->query("SELECT * FROM Comment WHERE auction_id='".$row['auction_id']."'");
        $get=$select->fetch(PDO::FETCH_ASSOC);
        if($row['auction_type']=='English auction'){
            if($get) {
                array_push($sendData, array(
                    'product_id' => $row['product_id'],
                    'auction_id' => $row['auction_id'],
                    'comment_status'=>"Commented",
                    'bidding_price' => $row['highest_price'],
                    'product_name' => $row['product_name'],
                    'picture' => "../img/product/" . $row['picture'],
                    'auction_type' => $row['auction_type'],
                ));
            }else{
                array_push($sendData, array(
                    'product_id' => $row['product_id'],
                    'auction_id' => $row['auction_id'],
                    'comment_status'=>"Review",
                    'bidding_price' => $row['highest_price'],
                    'product_name' => $row['product_name'],
                    'picture' => "../img/product/" . $row['picture'],
                    'auction_type' => $row['auction_type'],
                ));
            }
        }else {
            if($get) {
                array_push($sendData, array(
                    'product_id' => $row['product_id'],
                    'comment_status'=>"Commented",
                    'auction_id' => $row['auction_id'],
                    'bidding_price' => $row['current_price'],
                    'product_name' => $row['product_name'],
                    'picture' => "../img/product/" . $row['picture'],
                    'auction_type' => $row['auction_type'],
                ));
            }else{
                array_push($sendData, array(
                    'product_id' => $row['product_id'],
                    'comment_status'=>"Review",
                    'auction_id' => $row['auction_id'],
                    'bidding_price' => $row['current_price'],
                    'product_name' => $row['product_name'],
                    'picture' => "../img/product/" . $row['picture'],
                    'auction_type' => $row['auction_type'],
                ));
            }
        }
    }

    echo json_encode($sendData);
    $conn = null;
}

function review(){
    $dbh = connectDBPDO();
    $user_id=$_POST['user_id'];
    $auction_id=$_POST['auction_id'];
    $comment=$_POST['comment'];
    $subject='review';
    $statement=$dbh->query("INSERT INTO Comment(user_id,subject,comment,auction_id) VALUES('$user_id','$subject','$comment','$auction_id')");


    echo json_encode($auction_id);
    $conn = null;
}

function verify(){
    $dbh=connectDBPDO();
    $user_id=$_POST['user_id'];
    $imgFile = $_FILES['file']['name'];
    $tmp_dir = $_FILES['file']['tmp_name'];
    $imgSize = $_FILES['file']['size'];
    if (empty($imgFile)) {
        die("Please Select Image File.");
    } else {
        $add_idname=$dbh->query("UPDATE User SET id_card='$imgFile' WHERE user_id='$user_id'");
        $upload_dir = '../../img/id_card/' . $imgFile; // upload directory
        $imgExt = strtolower(pathinfo($imgFile, PATHINFO_EXTENSION)); // get image extension
        // valid image extensions
        $valid_extensions = array('jpeg', 'jpg', 'png', 'gif'); // valid extensions

        // allow valid image file formats
        if (in_array($imgExt, $valid_extensions)) {
            // Check file size '5MB'
            if ($imgSize < 5000000) {
                move_uploaded_file($tmp_dir, $upload_dir);
            } else {
                die("Sorry, your file is too large.");
            }
        } else {
            die("Sorry, only JPG, JPEG, PNG & GIF files are allowed.");
        }
        echo json_encode($add_idname);
        $conn = null;
    }

}?>