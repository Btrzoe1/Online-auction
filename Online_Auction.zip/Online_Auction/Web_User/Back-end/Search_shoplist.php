<?php
header("content-type:application/json;charset=utf-8");
require_once '../../Database/database.php';
$product_type=$_POST['product_type'];

if ($product_type!="") {
    file_type();
}else{
    search();
}
function search()
{
    $dbh = connectDBPDO();
    $product=$_POST['product'];
    $category=$_POST['category'];
    $sortby=$_POST['sortby'];
    if ($category == "All categories") {
        if ($product == "") {
            if ($sortby == "null" || $sortby == "newest") {
                $statement = $dbh->query(
                    "SELECT b.product_id,product_name,picture,current_price,auction_type,description
                       FROM Auction a,Product b
                       WHERE a.product_id=b.product_id AND a.auction_status='available' ORDER BY a.auction_id DESC;");
            } else if ($sortby == "lowprice") {
                $statement = $dbh->query(
                    "SELECT b.product_id,product_name,picture,current_price,auction_type,description
                       FROM Auction a,Product b
                       WHERE a.product_id=b.product_id AND a.auction_status='available' ORDER BY a.current_price ;");

            } else {
                $statement = $dbh->query(
                    "SELECT b.product_id,product_name,picture,current_price,auction_type,description
                       FROM Auction a,Product b
                       WHERE a.product_id=b.product_id AND a.auction_status='available' ORDER BY a.current_price DESC;");
            }

        } else {
            $statement = $dbh->query(
                "SELECT b.product_id,product_name,picture,current_price,auction_type,description
                       FROM Auction a,Product b
                       WHERE b.product_name LIKE '%$product%' AND a.product_id=b.product_id AND a.auction_status='available' ORDER BY a.auction_id DESC;");
        }
    } else {
        if ($product == "") {
            if ($sortby == "null" || $sortby == "newest") {
                $statement = $dbh->query(
                    "SELECT b.product_id,product_name,picture,current_price,auction_type,description
                       FROM Auction a,Product b
                       WHERE b.product_type='$category'  AND a.product_id=b.product_id AND a.auction_status='available' ORDER BY a.auction_id DESC;");
            } else if ($sortby == "lowprice") {
                $statement = $dbh->query(
                    "SELECT b.product_id,product_name,picture,current_price,auction_type,description
                       FROM Auction a,Product b
                       WHERE b.product_type='$category' AND a.product_id=b.product_id AND a.auction_status='available' ORDER BY a.current_price ;");
            } else {
                $statement = $dbh->query(
                    "SELECT b.product_id,product_name,picture,current_price,auction_type,description
                       FROM Auction a,Product b
                       WHERE b.product_type='$category' AND a.product_id=b.product_id AND a.auction_status='available' ORDER BY a.current_price DESC;");
            }
        } else {
            if ($sortby == "null" || $sortby == "newest") {
                $statement = $dbh->query(
                    "SELECT b.product_id,product_name,picture,current_price,auction_type,description
                       FROM Auction a,Product b
                       WHERE b.product_type='$category' AND b.product_name LIKE '%$product%' AND a.product_id=b.product_id AND a.auction_status='available' ORDER BY a.auction_id DESC;");
            } else if ($sortby == "lowprice") {
                $statement = $dbh->query(
                    "SELECT b.product_id,product_name,picture,current_price,auction_type,description
                       FROM Auction a,Product b
                       WHERE b.product_type='$category' AND b.product_name LIKE '%$product%'  AND a.product_id=b.product_id AND a.auction_status='available' ORDER BY a.current_price ;");
            } else {
                $statement = $dbh->query(
                    "SELECT b.product_id,product_name,picture,current_price,auction_type,description
                       FROM Auction a,Product b
                       WHERE b.product_type='$category' AND b.product_name LIKE '%$product%'  AND a.product_id=b.product_id AND a.auction_status='available' ORDER BY a.current_price DESC;");
            }
        }

    }
    $sendData = array();


    while ($row = $statement->fetch(PDO::FETCH_ASSOC)) {
        array_push($sendData, array(
            'product_id'=>$row['product_id'],
            'product_name' => $row['product_name'],
            'picture' => "../img/product/" . $row['picture'],
            'picture_name' => $row['picture'],
            'current_price' => $row['current_price'],
            'auction_type' => $row['auction_type'],
            'description' => $row['description'],
        ));
    }

    echo json_encode($sendData);
    $conn = null;
}

function file_type(){

    $product_type=$_POST['product_type'];
    $sortby=$_POST['sortby'];
    $dbh = connectDBPDO();
    if ($product_type=="All_category"){
        if ($sortby == "null" || $sortby == "newest") {
            $statement = $dbh->query(
                "SELECT b.product_id,product_name,picture,current_price,auction_type,description
                       FROM Auction a,Product b
                       WHERE a.product_id=b.product_id AND a.auction_status='available' ORDER BY a.auction_id DESC;");
        }else if ($sortby == "lowprice"){
            $statement = $dbh->query(
                "SELECT b.product_id,product_name,picture,current_price,auction_type,description
                       FROM Auction a,Product b
                       WHERE a.product_id=b.product_id AND a.auction_status='available' ORDER BY a.current_price ;");
        }else {
            $statement = $dbh->query(
                "SELECT b.product_id,product_name,picture,current_price,auction_type,description
                       FROM Auction a,Product b
                       WHERE a.product_id=b.product_id AND a.auction_status='available' ORDER BY a.current_price DESC;");
        }
    }else{
        if ($sortby == "null" || $sortby == "newest") {
            $statement = $dbh->query(
                "SELECT b.product_id,product_name,picture,current_price,auction_type,description
                       FROM Auction a,Product b
                       WHERE a.product_id=b.product_id AND a.auction_status='available' AND b.product_type='$product_type' ORDER BY a.auction_id DESC;");
        }else if ($sortby == "lowprice"){
            $statement = $dbh->query(
                "SELECT b.product_id,product_name,picture,current_price,auction_type,description
                       FROM Auction a,Product b
                       WHERE a.product_id=b.product_id AND a.auction_status='available' AND b.product_type='$product_type' ORDER BY a.current_price ;");
        }else {
            $statement = $dbh->query(
                "SELECT b.product_id,product_name,picture,current_price,auction_type,description
                       FROM Auction a,Product b
                       WHERE a.product_id=b.product_id AND a.auction_status='available' AND b.product_type='$product_type' ORDER BY a.current_price DESC;");
        }
    }
    $sendData = array();


    while ($row = $statement->fetch(PDO::FETCH_ASSOC)) {
        array_push($sendData, array(
            'product_id'=>$row['product_id'],
            'product_name' => $row['product_name'],
            'picture' => "../img/product/" . $row['picture'],
            'picture_name' => $row['picture'],
            'current_price' => $row['current_price'],
            'auction_type' => $row['auction_type'],
            'description' => $row['description'],
        ));
    }

    echo json_encode($sendData);
    $conn = null;
}

