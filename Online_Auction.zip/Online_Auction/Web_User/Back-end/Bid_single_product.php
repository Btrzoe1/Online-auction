<?php
session_start();
//header("content-type:application/json;charset=utf-8");
require_once '../../Database/database.php';
use PHPMailer\PHPMailer\PHPMailer;
use PHPMailer\PHPMailer\Exception;

require '../../PHPMailer-master/src/Exception.php';
require '../../PHPMailer-master/src/PHPMailer.php';
require '../../PHPMailer-master/src/SMTP.php';
$dbh = connectDBPDO();
$user_id=@$_SESSION['User']['user_id'];
$auction_id=$_POST["auction_id"];
$bidding_price=$_POST['bidding_price'];
$bidding_time=gmdate("Y-m-d H:i:s",strtotime("+1 hour"));
$product=$_POST['product'];
$current_price=$_POST['current_price'];
$product_name=$_POST['product_name'];
$username=$_POST['username'];
$statement=$dbh->query(
    "SELECT auction_type FROM Auction WHERE auction_id='$auction_id';");
$row=$statement->fetch(PDO::FETCH_ASSOC);
$auction_type=$row['auction_type'];
$email="0";
if ($user_id) {
    if($auction_type=="English auction"){
        $result=AddEnglishBid($user_id,$auction_id,$bidding_price,$bidding_time);
        $email="1";
    }



    if($auction_type=="Repeated second-bid auction"){
        $searchprice=$dbh->query("SELECT highest_price FROM Auction WHERE auction_id='$auction_id'");
        $row1=$searchprice->fetch(PDO::FETCH_ASSOC);
        $highest_price=$row1['highest_price'];
        $result=AddRepeatBid($highest_price,$current_price,$user_id,$auction_id,$bidding_price,$bidding_time);
        $email="1";
    }

    if($auction_type=="Dutch auction"){
        $result=AddDutchBid($user_id,$auction_id,$current_price,$bidding_time);
        $email="1";
    }

    if($email=="1"){
        $mail = new PHPMailer(true);                              // Passing `true` enables exceptions
        try {
            //Server configure
            $mail->CharSet = "UTF-8";                     //Set Email compile code

            $mail->isSMTP();
            $mail->SMTPDebug = 0; // debugging: 1 = errors and messages, 2 = messages only
            $mail->SMTPAuth = true; // authentication enabled
            $mail->SMTPSecure = 'ssl'; // secure transfer enabled REQUIRED for Gmail
            $mail->Host = "ssl://smtp.163.com";
            $mail->Port = 465;
            $mail->IsHTML(true);
            $mail->Username = "btrzoe@163.com";
            $mail->Password = "ao15378113114";

            $mail->setFrom('btrzoe@163.com', 'E-auction');  //Who send Email
            $mail->addAddress("$username", 'Customer');  //  Add address
            $mail->addReplyTo("$username", 'info'); // who repley to
            //Content
            $mail->isHTML(true);
            $mail->Subject = 'Bid Confirm' . time();
            if($auction_type=="Dutch auction"){
                $mail->Body = "<h1>You win the auction!</h1><p>You became the winner of auction $product_name, thank you for bidding on our website.</p><p>Your bidding time is $bidding_time </p><p>For More detail http://dingding.ibfpig.com/Web_User/</p>";
                $mail->AltBody = "<h1>You win the auction!</h1><p>Your bidding time is $bidding_time </p><p>For More detail http://dingding.ibfpig.com/Web_User/</p>" . date('Y-m-d H:i:s');
            }else {
                $mail->Body = "<h1>Bid Success</h1><p>You have bid the $product_name with £$bidding_price, thank you for visiting our website.</p><p>Your bidding time is $bidding_time </p><p>For More detail http://dingding.ibfpig.com/Web_User/</p>";
                $mail->AltBody = "<h1>Bid Success</h1><p>Your bidding time is $bidding_time </p><p>For More detail http://dingding.ibfpig.com/Web_User/</p>" . date('Y-m-d H:i:s');
            }
            $mail->send();
            ?>
            <script type="text/javascript">
                alert('You bid successfully, we have sent you an confirm email!');
                window.location.href="../Single_product.php?product=<?php echo $product ?>";
            </script>
            <?php
        } catch (Exception $e) {
            echo 'Sent email fail: ', $mail->ErrorInfo;
        }
        ?>
        <script type="text/javascript">
            alert('You bid successfully, we have sent you an confirm email!');
            window.location.href="../Single_product.php?product=<?php echo $product ?>";
        </script>
        <?php
    } else {
        ?>
        <script> alert('Bid fail, please try again!');
            window.location.href="../Single_product.php?product=<?php echo $product ?>";</script>
        <?php
    }
}else{
    ?>
    <script>

        alert('You are not logged in yet! please log in first.');

        window.location.href="../Single_product.php?product=<?php echo $product ?>";
    </script>
    <?php


}