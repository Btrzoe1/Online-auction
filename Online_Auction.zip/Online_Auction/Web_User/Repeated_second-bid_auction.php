<!doctype html>
<!--[if IE 9]> <html class="no-js ie9" lang="en"> <![endif]-->
<!--[if gt IE 9]><!--> <html class="no-js " lang="en"> <!--<![endif]-->
<head>
    <meta charset="utf-8">
    <meta http-equiv="x-ua-compatible" content="ie=edge">
    <title>Online Auction | E-auction</title>
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <link rel="stylesheet" href="css/bootstrap.min.css">
    <link rel="stylesheet" href="css/style.css">
    <link rel="stylesheet" href="css/font-awesome.min.css">
    <link rel="stylesheet" href="css/responsive.css">
    <script src="../js/script.js"></script>
</head>
<body>
<header class="header-area">
    <?php
    require_once "header.php";
    ?>
</header>
<div style="height:60px;background:#f9e87c;text-align:center" >
</div>
<div style="height:70px;background:#f9e87c;text-align:center" >
    <font size="8" color="#00008b" ><b>How Repeat Second-bid Auction works</b></font>
</div>
<div style="height:90px;background:#f9e87c;text-align:center">
    <div><font size="3" color="#00008b">Starting Bidding at E-auctions is a good choice to get what you want.</font></div>
    <div><font size="3" color="#00008b">Publish your own auction to sale items with the best price.</font></div>
</div>
<div class="english_auction_information" style="padding-top:20px;">
    <font style="font-size:18px"><b>For auctioneer</b></font>
    <p style="font-size:15px">In Repeat Second-bid Auction, you name set a lower starting price and specify the duration of the auction. You can view the whole bidding process in your account. When the auction is over, the highest bidder gets your product and you are paid the second highest bidding price.</p>
    <div class="tips">
        <p style="font-size:18px;padding:10px"><b>Tip</b></p>
        <p class="tips-text">As seller contract, once you publish an auction, it means that the item must be sold unless there is no bidder at the end of the auction.</p>
    </div>
</div>
<div class="english_auction_information"">
<p style="font-size:18px"><b>For Bidder</b></p>
<p style="font-size:15px">In Repeat Second-bid Auction, sellers give a initial price and you bid against other bidders. You can check the current price on website which is also the second highest price currently. When the listing ends, the highest bidder wins the item and completes the purchase by paying second highest bidding price.</p>
<div class="tips">
    <p style="font-size:18px;padding:10px"><b>Tip</b></p>
    <p class="tips-text">Remember, a bid is considered a binding contract. That means that when you bid on an item, you're committing to buy it if you win.</p>
</div>
</div>
<?php
require_once "footer.php";
?>
<script src="../js/vendor/jquery-1.11.3.min.js"></script>
<script src="../js/bootstrap.min.js"></script>
</body>
</html>