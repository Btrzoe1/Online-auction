<!doctype html>
<!--[if IE 9]> <html class="no-js ie9" lang="en"> <![endif]-->
<!--[if gt IE 9]><!--> <html class="no-js " lang="en"> <!--<![endif]-->
<head>
    <meta charset="utf-8">
    <meta http-equiv="x-ua-compatible" content="ie=edge">
    <title>Online Auction | E-auction</title>
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <link rel="stylesheet" href="css/bootstrap.min.css">
    <link rel="stylesheet" href="css/style.css">
    <link rel="stylesheet" href="css/font-awesome.min.css">
    <link rel="stylesheet" href="css/responsive.css">
    <script src="../js/script.js"></script>
</head>
<body>
<header class="header-area">
    <?php
    require_once '../Database/database.php';
    require_once "header.php";
    ?>
</header>
<section class="main-content-area">
    <div class="container">
        <div class="row">
            <div class="col-xs-12 col-sm-12 col-md-3 col-lg-3">
                <div class="single-sidebar myaccount-info-area">
                    <h2>My Account</h2>
                    <div class="myaccount-info">
                        <ul>
                            <li class="active"><a href="My_account.php">My Details</a></li>
                            <li><a href="My_auction.php">My Auctions</a></li>
                            <li><a href="Bidding_history.php">Bidding History</a></li>
                            <li><a href="Win_auction.php">Win Auction</a></li>
                        </ul>
                    </div>
                </div>
            </div>
            <div class="col-xs-12 col-sm-12 col-md-9 col-lg-9">
                <div class="myaccount-dashboard-area cart-page-main-area">
                    <div class="sec-heading-area">
                        <h2>My Details</h2>
                    </div>
                    <div class="myaccount-dashboard">
                        <label>Hello!</label>
                        <p>You have the ability to view all your details and update your account information. Select a link below to view or edit information.</p>
                        <div class="acc-information">
                            <div class="acc-box-1">
                                <div class="left-info col-sm-6">
                                    <p>Account Information <a href="#" data-dismiss="modal" data-target="#editpassword" aria-hidden="true" data-toggle="modal"> Edit</a></p>
                                    <span><?php echo $_SESSION['User']['username'] ?></span>
                                    <span>**********</span>
                                </div>
                                <div class="right-info col-sm-6">
                                    <p>Personal Information <a href="#" data-dismiss="modal" data-target="#edit_personal_information" aria-hidden="true" data-toggle="modal"> Edit</a></p>
                                    <span><?php echo $_SESSION['User']['firstname']."&nbsp;".$_SESSION['User']['lastname'] ?></span>
                                    <span>Phone: +<?php echo $_SESSION['User']['phone'] ?></span>
                                    <span>Post code: <?php echo $_SESSION['User']['post_code'] ?></span>
                                    <span>Address:<?php echo $_SESSION['User']['address'] ?></span>
                                </div>
                                <?php $dbh=connectDBPDO();
                                $id_card=$dbh->query("SELECT authentication FROM User WHERE user_id='".$_SESSION['User']['user_id']."'");
                                $get_id_card=$id_card->fetch(PDO::FETCH_ASSOC);
                                $get=$get_id_card['authentication'];
                                if($get=="0"){
                                ?>
                                <div>
                                    <form role="form" id="authentication" method="post">
                                    <p>If you want to add new auctions or bid online, we need you to upload your ID card photo to verify the authenticity of the information, and we guarantee that your personal information will not be disclosed. We will confirm your information within two hours.</p>
                                        <input type="file" class="form-control" id="authentication_request" name="Fimage" required="">
                                        <div id="image" style="height:200px;width:200px;"><img height="200px" src="" ></div>
                                        <input type="button" id="btn-authentication"  class="btn btn-success" value="Submit">
                                    </form>
                                </div>
                                <?php } ?>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
            <div class="modal fade" id="editpassword" role="dialog">
                <div class="modal-dialog">
                    <!-- Modal content-->
                    <div class="modal-content">
                        <div class="modal-header">
                            <div class="panel-heading">
                                <div class="panel-title pull-left"><font size="6" color="white">Edit password</font></div>
                                <button aria-hidden="true" data-dismiss="modal" class="close btn btn-xs " type="button"> <i class="fa fa-times"></i> </button>
                            </div>
                        </div>
                        <div class="modal-body">
                            <form id="editform" class="form-horizontal"  method="post">
                                <label class="control-label">New password: 　　
                                </label>
                                <input id="edit_password" type="password" style="width:100%" name="edit_password" class="form-control" onblur="checkeditpassword()" required="">
                                <i id="edit_password_i"></i>

                                <label class="control-label">Confirm password: 　　　　　　　　　　　　　　　　　　　　　　　　　　　　　
                                </label>
                                <input id="edit_confirmpassword" type="password" style="width:100%" name="edit_confirmpassword"  class="form-control" onblur="checkeditconfirmpassword(edit_password,edit_confirmpassword)" required="">
                                <i id="edit_confirmpassword_i"></i>
                                <div class="form-group">
                                    <div style="text-align:right;">
                                        <input type="submit" name="Confirm-info" class="btn btn-primary"  value="Submit">
                                    </div>
                                </div>
                                <?php
                                if (isset($_POST['Confirm-info'])) {
                                    //get the post data from the submit form.
                                    $password = filter_input(INPUT_POST, 'edit_password', FILTER_SANITIZE_STRING);
                                    $password1 = filter_input(INPUT_POST, 'edit_confirmpassword', FILTER_SANITIZE_STRING);
                                    $salt = "62";
                                    $username=$_SESSION['User']['username'];
                                    $password_hash = $password . $username . $salt;
                                    $password_hash = hash('sha256', $password_hash);

                                    if (empty($password)) {
                                        die("Password not define!!");
                                    }
                                    if (empty($password1)) {
                                        die("Confirm password not define!!");
                                    }
                                    $statement = EditPassword($username, $password_hash);
                                    if ($statement) {
                                        session_destroy();
                                        echo "<script>alert('Update account password successfully, please login again!');location.href='index.php';</script>";
                                    } else {
                                        echo "<script>alert('Update account password fail, please try again!');location.href='My_account.php';</script>";
                                    }
                                }
                                ?>
                            </form>
                        </div>
                    </div>
                </div>
            </div>
            <div class="modal fade" id="edit_personal_information" role="dialog">
                <div class="modal-dialog">
                    <!-- Modal content-->
                    <div class="modal-content">
                        <div class="modal-header">
                            <div class="panel-heading">
                                <div class="panel-title pull-left"><font size="6" color="white">Edit personal information</font></div>
                                <button aria-hidden="true" data-dismiss="modal" class="close btn btn-xs " type="button"> <i class="fa fa-times"></i> </button>
                            </div>
                        </div>
                        <div class="modal-body">
                            <form id="editform2" class="form-horizontal"  method="post">
                                <label class="control-label">Firstname: 　　　　　　　　　　　　　　　　　　　　　　　　　　　　　　　　　
                                </label>
                                <input id="edit_firstname" type="text" style="width:100%" name="edit_firstname" class="form-control" required="">

                                <label class="control-label">Last name: 　　　　　　　　　　　　　　　　　　　　　　　　　　　　
                                </label>
                                <input id="edit_lastname" type="text" style="width:100%" name="edit_lastname" class="form-control" required="">
                                <label class="control-label">Phone: 　　　　　　　　　　　　　　　　　　　　　　　　　　　　　　　　　　
                                </label>
                                <input onkeyup="value=value.replace(/[^\d]/g,'')" id="edit_phone" type="text" class="form-control" style="width:100%" name="edit_phone" placeholder="Eg.+440123456789" required="">
                                <div style="float:left; width:32%">
                                    <label class="control-label">Post code:
                                    </label>
                                    <input id="edit_postcode" type="text" style="width:90%" class="form-control" name="edit_postcode" >
                                </div>
                                <div style="float:left; width:68%">
                                    <label class="control-label">Address(optional):
                                    </label>
                                    <input id="edit_address" type="text" style="width:100%" class="form-control" name="edit_address" >
                                </div>
                                <div class="form-group">
                                    <div style="text-align:right;">
                                        <input type="submit"  name="Confirm" class="btn btn-primary" value="Submit">
                                    </div>
                                </div>
                                <?php
                                if (isset($_POST['Confirm'])) {
                                    //get the post data from the submit form.
                                    $firstname = filter_input(INPUT_POST, 'edit_firstname', FILTER_SANITIZE_STRING);
                                    $lastname = filter_input(INPUT_POST, 'edit_lastname', FILTER_SANITIZE_STRING);
                                    $phone = filter_input(INPUT_POST, 'edit_phone', FILTER_SANITIZE_STRING);
                                    $post_code = filter_input(INPUT_POST, 'edit_postcode', FILTER_SANITIZE_STRING);
                                    $address = filter_input(INPUT_POST, 'edit_address', FILTER_SANITIZE_STRING);
                                    $username=$_SESSION['User']['username'];

                                    if (empty($firstname)) {
                                        die("First name not define!!");
                                    }
                                    if (empty($lastname)) {
                                        die("Last name  not define!!");
                                    }
                                    if (empty($phone)) {
                                        die("Phone not define!!");
                                    }

                                    $statement = EditInformation($username,$firstname,$lastname,$phone,$address,$post_code);
                                    if ($statement) {
                                        session_destroy();
                                        echo "<script>alert('Update your information successfully, please login again!');location.href='index.php';</script>";
                                    } else {
                                        echo "<script>alert('Update personal detail fail, please try again');location.href='My_account.php';</script>";
                                    }
                                }
                                ?>
                            </form>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</section>
<?php
require_once "footer.php";
?>
<script src="../js/vendor/jquery-1.11.3.min.js"></script>
<script src="../js/bootstrap.min.js"></script>
<script>
    // Show picture.
    document.getElementById('authentication_request').onchange = function() {
        var imgFile = this.files[0];
        var fr = new FileReader();
        fr.onload = function() {
            document.getElementById('image').getElementsByTagName('img')[0].src = fr.result;
        };
        fr.readAsDataURL(imgFile);
    };
</script>
<script>
    // Upload document to send request.
    $('#btn-authentication').click(function() {
        var file = document.getElementById('authentication_request').files[0];
        var user_id='<?php echo $_SESSION['User']['user_id'] ?>';
        var formData = new FormData();
        formData.append('file',file);
        formData.append('user_id',user_id);
        formData.append('type','verify');
        $.ajax({
            url: "Back-end/Manage_auction.php",
            data:formData,
            type: "post",
            processData: false,
            contentType: false,
            datatype: "json",
            success: function(data) {
                document.getElementById('authentication').style.display='none';
            }
        });
    })
</script>
</body>
</html>