<!-- footer-area start -->
<footer class="footer-area">
    <!-- footer-top start -->
    <div class="footer-top">
        <div class="container">
            <div class="row">
                <div class="col-xs-12 col-sm-3 col-md-2 col-lg-2">
                    <!-- single-footer start -->
                    <div class="single-footer">
                        <h2>My Account</h2>
                        <ul>
                            <li><a href="My_account.php">My Account</a></li>
                            <li><a href="#" data-toggle="modal" data-target="#login">Log in</a></li>
                        </ul>
                    </div>
                    <!-- single-footer end -->
                </div>
                <div class="col-xs-12 col-sm-4 col-md-2 col-lg-2 hidden-sm hidden-xs">
                    <!-- single-footer start -->
                    <div class="single-footer">
                        <h2>Information</h2>
                        <ul>
                            <li><a href="Contact_us.php">Contact Us</a></li>
                        </ul>
                    </div>
                    <!-- single-footer end -->
                </div>
                <div class="col-xs-12 col-sm-6 col-md-4 col-lg-4">
                    <!-- single-footer start -->
                    <div class="single-footer">
                        <h2>Contact Us</h2>
                        <div class="address-info">
                            <p><strong>Address: </strong> <span> Durham University.</span></p>
                            <p><strong>Phone: </strong> <span> +447422588161 </span></p>
                            <p><strong>Email:  </strong> <span> <a href="mailto:btrzoe@163.com">btrzoe@163.com</a></span></p>
                        </div>
                    </div>
                    <!-- single-footer end -->
                </div>
                <div class="banner-footer">
                    <img src="../img/logo.png" alt="E-auction" />
                </div>
            </div>
        </div>
    </div>
    <!-- footer-top end -->
</footer>
<!-- footer-area end -->