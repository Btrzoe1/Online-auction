<!doctype html>
<head>
    <meta charset="utf-8">
    <meta http-equiv="x-ua-compatible" content="ie=edge">
    <title>Online Auction | E-auction</title>
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <link rel="stylesheet" href="css/jquery.fancybox.css">
    <link rel="stylesheet" href="css/nivo-slider.css">
    <link rel="stylesheet" href="css/owl.carousel.css">
    <link rel="stylesheet" href="css/font-awesome.min.css">
    <link rel="stylesheet" href="css/bootstrap.min.css">
    <link rel="stylesheet" href="css/style.css">
    <link rel="stylesheet" href="css/responsive.css">
    <script src="../js/vendor/html5shiv.min.js"></script>
    <script src="../js/vendor/respond.min.js"></script>
    <script src="../js/script.js"></script>
</head>
<body>



<header class="header-area">
    <?php
    require_once "header.php";
    $product=$_GET['product'];
    $category=$_GET['category'];
    ?>
    <div class="header-bottom">
        <div class="container">
            <div class="header-bottom-bg">
                <div class="row">
                    <!-- mainmenu start -->
                    <div class="col-xs-12 col-md-9">
                        <div class="mainmenu">
                            <input type="hidden" id="product" name="product" value="<?php echo $product ?>">
                            <input type="hidden" id="type" name="type" value="<?php echo $category ?>">
                            <nav>
                                <ul>
                                    <li><a href="index.php">Home</a><i class="fa fa-angle-down"></i></li>
                                    <li><a href="Shop_list.php?auction_type=English auction">English Auction</a></li>
                                    <li><a href="Shop_list.php?auction_type=Dutch auction">Dutch Auction</a></li>
                                    <li><a href="Shop_list.php?auction_type=Repeated second-bid auction">Repeated second-bid Auction</a></li>
                                    <li><a href="Contact_us.php">Contact Us</a></li>
                                </ul>
                            </nav>
                        </div>
                    </div>
                    <!-- mainmenu end -->
                </div>
            </div>
        </div>
    </div>
    <!-- header-bottom end -->
</header>
<!-- header-area end -->
<!-- main content area start  -->
<section class="main-content-area">
    <div class="container">
        <!-- bradcame start -->
        <div class="row">
            <div class="col-xs-12 col-sm-12 col-md-12 col-lg-12">
                <div class="greentect_bradcame">
                    <ul>
                        <li><a href="index.php">home</a></li>
                    </ul>
                </div>
            </div>
        </div>
        <!-- bradcame end -->
        <div class="row">
            <div class="col-xs-12 col-sm-12 col-md-3 col-lg-3">
                <div class="page-sidebar-area">
                    <!-- shop-by-area start -->
                    <div class="single-sidebar shop-by-area">
                        <h2>Shop By</h2>
                        <!-- category-list-pro start -->
                        <div class="category-list-pro sidebar-list">
                            <h3>Category</h3>
                            <ul id="product_type">
                                <li value="All_category" >All Categories</li>
                                <li value="Electronics" >Electronics</li>
                                <li value="Appliances">Appliances</li>
                                <li value="Fashion">Fashion</li>
                                <li value="Sports">Sports</li>
                                <li value="'Beauty">Beauty</li>
                                <li value="Health">Health</li>
                                <li value="Kids">Kids</li>
                                <li value="Accessories">Accessories</li>
                            </ul>
                        </div>
                        <!-- category-list-pro end -->
                    </div>
                    <!-- shop-by-area end -->
                </div>
            </div>
            <div class="col-xs-12 col-sm-12 col-md-9 col-lg-9">
                <div class="right-main-product">
                    <!-- product-sgorting start -->
                    <div class="product-sgorting-bar">
                        <!-- shoort-by start -->
                        <div class="shoort-by">
                            <label>Sort by</label>
                            <div class="short-select-option">
                                <select id="sortby">
                                    <option value="newest">Newest auction</option>
                                    <option value="lowprice">Price low-high</option>
                                    <option value="highprice">Price high-low</option>
                                </select>
                            </div>
                            <a title="Set Descending Direction" href=""><i class="fa fa-long-arrow-up"></i></a>
                        </div>
                        <!-- shoort-by end -->
                    </div>
                    <!-- product-sgorting end -->
                    <!-- all-product start -->
                    <div class="row all-list-product">
                        <!-- single-product-item start -->
                        <table>
                            <tbody id='tbody'>
                            </tbody>
                        </table>
                        <!-- single-product-item end -->
                    </div>
                </div>
            </div>
        </div>
    </div>
</section>
<!-- main content area end  -->
<?php
require_once "footer.php";
?>
<script src="../js/vendor/jquery-1.11.3.min.js"></script>
<script src="../js/jqueryui.js"></script>
<script src="../js/jquery.meanmenu.js"></script>
<script src="../js/jquery.fancybox.js"></script>
<script src="../js/jquery.elevatezoom.js"></script>
<script src="../js/bootstrap.min.js"></script>
<script src="../js/owl.carousel.min.js"></script>
<script src="../js/jquery.nivo.slider.pack.js"></script>
<script src="../js/main.js"></script>
<script src="../js/main.js"></script>
<script>
    var product_type="";
    var product="";
    var category="All categories";
    var web = {
        init: function () {
            product =$("#product").val();
            category=$("#type").val();
            console.log(product);
            console.log(category);
            var data = {
                product:product,
                category:category,
                product_type:product_type
            };
            this.getAll(data);
            this.eleBind();
        },
        eleBind: function () {
            $('#product_type').find("li").click(function(){
                product_type = $(this).attr("value");
                product="";
                category="All categories";
                var data = {
                    product_type:product_type,
                    product:product,
                    category:category
                };
                web.getData(data);
            })
            $('#sortby').change(function(){
                var option = $("#sortby option:selected");
                var sortby = option.val();
                var data={
                    sortby:sortby,
                    product:product,
                    category:category,
                    product_type:product_type
                };
                web.sortBy(data);
            })
        },
        // Get all auctions.
        getAll: function (data) {
            $.ajax({
                url: "Back-end/Search_shoplist.php",
                type: "post",
                data: {
                    category:data.category,
                    product: data.product,
                    product_type:data.product_type,
                    sortby:'null'
                },
                datatype: 'json',
                success: function (data) {
                    web.setData(data);
                },
            });
        },
        // Get all auctions according to the input.
        getData: function (data) {
            $.ajax({
                url: "Back-end/Search_shoplist.php",
                type: "post",
                data: {
                    product_type: data.product_type,
                    product:data.product,
                    category:data.category,
                    sortby:'null',

                },
                datatype: 'json',
                success: function (data) {
                    web.setData(data);
                    $("#sortby option:first").prop("selected", 'selected');
                },
                error: function(){
                }
            })
        },
        // Auctions are sort by price or time.
        sortBy:function(data){
            $.ajax({
                url: "Back-end/Search_shoplist.php",
                type: "post",
                data:{
                    product_type:data.product_type,
                    product:data.product,
                    category:data.category,
                    sortby: data.sortby,
                },
                datatype: 'json',
                success: function (data) {
                    web.setData(data);
                },
                error: function(){
                }
            })
        },
        // Show all auctions.
        setData: function (data) {
            var html = "";
            data.forEach(function (data, index, array) {
                html += `
                        <div class="col-xs-12 col-sm-12 col-md-12 col-lg-12">
                            <div class="single-product-item">
                                <div class="product-image">
                                    <a href="Single_product.php?product=${data.product_id}"><img width="200vm" src="${data.picture}" alt="product image" /></a>
                                </div>
                                <div class="single-product-text">
                                    <h2><a class="product-title" href="Single_product.php?product=${data.product_id}">${data.product_name}</a></h2>
                                    <div class="price-rate-box">
                                        <div class="product-price">
                                            <span class="regular-price">Current Price: ￡${data.current_price} <h6>(${data.auction_type})</h6> </span>
                                        </div>
                                    </div>
                                    <div class="product-description">
                                        <p>${data.description} </p>
                                    </div>
                                </div>
                            </div>
                        </div>`
            })
            $('#tbody').html(html);
        }
    }

    $(document).ready(function () {
        web.init()
    })

</script>
</body>
</html>
