<?php
session_start();
?>

<script src="../js/script.js"></script>
<div class="header-top">
    <div class="container">
        <div class="row">
            <div class="col-xs-12 col-sm-6">
                <div class="welcome-mes">
                    <p>Welcome to E-auction!</p>
                </div>
            </div>
            <div class="col-xs-12 col-sm-6">
                <div class="header-right-menu">
                    <nav>
                        <ul>
                            <?php
                            if (!empty($_SESSION['User'])) {
                                echo "<li>" ."<a href='#Personalinfo' data-toggle='collapse' aria-expanded='false' class='dropdown-toggle'>"."Hi,". $_SESSION['User']['firstname'] ."</a>". "</li>";
                            } else {
                                echo "<li>"."<a href=\"#\" data-toggle=\"modal\" data-target=\"#login\">Login</a>
                                </li>
                                ";
                            }
                            ?>
                            <!--   Check the role of the user -->
                            <?php
                            if(!empty($_SESSION['User'])){
                                echo "<li>"."<a href='My_account.php'>My account</a>"
                                    ."<ul>"
                                    ."<li>"."<a href='My_account.php'>My Account</a>"."</li>"
                                    ."<li>"."<a href='My_auction.php'>My Auctions</a>"."</li>"
                                    ."<li>"."<a href='Bidding_history.php'>History Bidding</a>"."</li>"
                                    ."<li>"."<a href='Back-end/Log_out.php'>Log out</a>"."</li>"
                                    ."</ul>"
                                    ."</li>";
                            }
                            if(!empty($_SESSION['User'])&&$_SESSION['User']['role']=="admin"){
                                echo "<li class='cative'><a href='../Web_Admin/index.php'>Admin Page</a></li>";
                            }
                            ?>

                        </ul>
                    </nav>
                </div>
            </div>
            <!--Login Modal -->
            <div class="modal fade" id="login" role="dialog">
                <div class="modal-dialog">
                    <!-- Modal content-->
                    <div class="modal-content">
                        <div class="modal-header">
                            <div class="panel-heading">
                                <div class="panel-title pull-left"><font size="6" color="white">Login</font></div>
                                <div class="pull-right"><a href="#" data-dismiss="modal" data-target="#forget" aria-hidden="true" data-toggle="modal"><font color="white">Forgot password?</font></a>
                                    <button aria-hidden="true" data-dismiss="modal" class="close btn btn-xs " type="button"> <i class="fa fa-times"></i> </button>
                                </div>
                            </div>
                        </div>
                        <div class="modal-body">
                            <form id="loginform" action="Back-end/Login_verify.php" class="form-horizontal" method="post">
                                <div class="input-group"> <span class="input-group-addon"><i class="glyphicon glyphicon-user"></i></span>
                                    <input id="login_username" name="login_username" type="text" class="form-control" value="" placeholder="Email" required="">
                                </div>
                                <div class="input-group"> <span class="input-group-addon"><i class="glyphicon glyphicon-lock"></i></span>
                                    <input id="login_password" name="login_password" type="password" class="form-control" placeholder="Password" required="">
                                </div>
                                <div class="form-group">
                                    <div style="text-align:right;">
                                        <input type="submit" class="btn btn-primary"  value="Login">
                                    </div>
                                </div>
                            </form>
                        </div>
                        <div class="modal-footer">
                            <div class="form-group">
                                <div class="col-md-12 control">
                                    <div>Don't have an account? <a href="#" data-dismiss="modal" data-target="#signup" aria-hidden="true" data-toggle="modal">Sign Up Here</a>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
            <!-- Forget password Modal -->
            <div class="modal fade" id="forget" role="dialog">
                <div class="modal-dialog">
                    <!-- Modal content-->
                    <div class="modal-content">
                        <div class="modal-header">
                            <div class="panel-heading">
                                <div class="panel-title pull-left"><font size="6" color="white">Get verification code</font></div>
                                <button aria-hidden="true" data-dismiss="modal" class="close btn btn-xs " type="button"> <i class="fa fa-times"></i> </button>
                            </div>
                        </div>
                        <div class="modal-body">
                            <form id="resetform" class="form-horizontal" action="Back-end/Send_recoverycode.php" method="post">
                                <div class="input-group"> <span class="input-group-addon"><i class="glyphicon glyphicon-user"></i></span>
                                    <input id="forget_username" name="forget_username" type="text" class="form-control" value="" placeholder="Email">
                                </div>
                                <div class="form-group">
                                    <div style="text-align:right;">
                                        <input type="submit" class="btn btn-primary" value="Submit"></a>
                                    </div>
                                </div>
                            </form>
                        </div>
                        <div class="modal-footer">
                            <div class="form-group">
                                <div class="col-md-12 control">
                                    <div>Don't have an account? <a href="#" data-dismiss="modal" data-target="#signup" aria-hidden="true" data-toggle="modal">Sign Up Here</a>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
            <div class="modal fade" id="signup" role="dialog">
                <div class="modal-dialog">
                    <!-- Modal content-->
                    <div class="modal-content">
                        <div class="modal-header">
                            <div class="panel-heading">
                                <div class="panel-title pull-left"><font size="6" color="white">Sign up</font></div>
                                <button aria-hidden="true" data-dismiss="modal" class="close btn btn-xs " type="button"> <i class="fa fa-times"></i> </button>
                            </div>
                        </div>
                        <div class="modal-body">
                            <form id="signupform" onsubmit="return check_form()" action="Back-end/Sign_up.php"  method="post">
                                <label class="control-label">Email: 　　　　　　　　　　　　　　　　　　　　　　　　　　　　　　　　　
                                </label>
                                <input id="signup_username" type="text" style="width:100%" name="signup_username" class="form-control" value="" placeholder="Email" onblur="checkemail()" required="">
                                <i id="signup_username_i"></i>

                                <label class="control-label">Firstname: 　　　　　　　　　　　　　　　　　　　　　　　　　　　　　　　　　
                                </label>
                                <input id="signup_firstname" type="text" style="width:100%" name="signup_firstname" class="form-control" required="">

                                <label class="control-label">Last name: 　　　　　　　　　　　　　　　　　　　　　　　　　　　　
                                </label>
                                <input id="signup_lastname" type="text" style="width:100%" name="signup_lastname" class="form-control" required="">

                                <label class="control-label">Password: 　　　　　　　　　　　　　　　　　　　　　　　　　　　　　　　　　
                                </label>
                                <input id="signup_password" type="password" style="width:100%" name="signup_password" class="form-control" onblur="checkpassword()" required="">
                                <i id="signup_password_i"></i>

                                <label class="control-label">Confirm password: 　　　　　　　　　　　　　　　　　　　　　　　　　　　　　
                                </label>
                                <input id="signup_confirmpassword" type="password" style="width:100%" name="signup_confirmpassword"  class="form-control" onblur="checkconfirmpassword(signup_password,signup_confirmpassword)" required="">
                                <i id="signup_confirmpassword_i"></i>

                                <label class="control-label">Phone: 　　　　　　　　　　　　　　　　　　　　　　　　　　　　　　　　　　
                                </label>
                                <input onkeyup="value=value.replace(/[^\d]/g,'')" id="signup_phone" type="text" class="form-control" style="width:100%" name="signup_phone" placeholder="Eg.+440123456789" required="">
                                <div class="form-group">
                                    <div style="text-align:right;">
                                        <input type="submit" name="signUp" class="btn btn-primary" value="Sign Up">
                                    </div>
                                </div>
                            </form>
                        </div>
                        <div class="modal-footer">
                            <div class="form-group">
                                <div class="col-md-12 control">
                                    <div>Already have an account? <a href="#" data-dismiss="modal" data-target="#login" aria-hidden="true" data-toggle="modal">Sign In Here</a>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>
<div class="header-middle">
    <div class="container">
        <div class="row">
            <div class="col-xs-12 col-md-3">
                <!-- logo start -->
                <div class="logo">
                    <a href="index.php"><img src="../img/logo.png" alt="E-auction" /></a>
                </div>
                <!-- logo end -->
            </div>
            <div class="col-xs-12 col-md-9">
                <!-- category search start -->
                <div class="category-search-area">
                    <div class="search-cat">
                        <select id="category">
                            <option value="All categories">All Categories</option>
                            <option value="Electronics">Electronics</option>
                            <option value="Appliances">Appliances</option>
                            <option value="Fashion">Fashion</option>
                            <option value="Sports">Beauty</option>
                            <option value="Health">Health</option>
                            <option value="Kids">Kids</option>
                            <option value="Accessories">Accessories</option>
                        </select>
                    </div>
                    <div class="search-form">
                        <form action="#" method="post">
                            <input class="cat-search-box" type="text" id="product_name" placeholder="Search entire store here.." />
                            <a class="cat-search-btn"><i id="search" class="fa fa-search" ></i></a>
                        </form>
                    </div>
                </div>
                <!-- category search end -->
            </div>
        </div>
    </div>
</div>
<script>
    // Select category or input product name.
    window.onload = function(){
        var category = "All categories";
        $('#category').change(function() {
            var option = $("#category option:selected");
            category = option.val();
        })
        $('#search').click(function(){
            var product=$("#product_name").val();
            window.location.href ="Search_shop_list.php?product="+product+"&category="+category;
        })
    }

</script>
<script>
    // Use polling to chech auction status.
    var getting = {

        url:'Back-end/polling.php',
        type:"post",
        dataType:'json',

        success:function(res) {
            console.log(res);
            if(res.code==200){
                $("#info").append(res.info+'</br>');
            }else{
                console.log(res);
            }
        }
    };
    window.setInterval(function(){$.ajax(getting)},3000);
</script>
