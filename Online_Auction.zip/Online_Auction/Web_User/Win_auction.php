<!doctype html>
<!--[if IE 9]> <html class="no-js ie9" lang="en"> <![endif]-->
<!--[if gt IE 9]><!--> <html class="no-js " lang="en"> <!--<![endif]-->
<head>
    <meta charset="utf-8">
    <meta http-equiv="x-ua-compatible" content="ie=edge">
    <title>Online Auction | E-auction</title>
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <link rel="stylesheet" href="css/bootstrap.min.css">
    <link rel="stylesheet" href="css/style.css">
    <link rel="stylesheet" href="css/font-awesome.min.css">
    <link rel="stylesheet" href="css/responsive.css">
    <script src="../js/script.js"></script>
</head>
<body>
<header class="header-area">
    <?php
    require_once '../Database/database.php';
    require_once "header.php";
    ?>
</header>
<section class="main-content-area">
    <div class="container">
        <div class="row">
            <div class="col-xs-12 col-sm-12 col-md-3 col-lg-3">
                <div class="single-sidebar myaccount-info-area">
                    <h2>My Account</h2>
                    <div class="myaccount-info">
                        <ul>
                            <li><a href="My_account.php">My Details</a></li>
                            <li><a href="My_account.php">My Auctions</a></li>
                            <li><a href="Bidding_history.php">Bidding History</a></li>
                            <li class="active"><a href="Win_auction.php">Win Auction</a></li>
                        </ul>
                    </div>
                </div>
            </div>
            <div class="col-xs-12 col-sm-12 col-md-9 col-lg-9">
                <div class="myaccount-dashboard-area cart-page-main-area">
                    <div class="sec-heading-area">
                        <input type="hidden" id="user_id" name="user_id" value="<?php echo $_SESSION['User']['user_id']?>">
                        <h2>My Auctions</h2>
                    </div>
                    <div class="myaccount-dashboard">
                        <p>You have won these auctions below. Go to write review to them. </p>
                        <div class="acc-information">
                            <div class="modal fade" id="reviewModal" tabindex="-1" role="dialog" aria-labelledby="reviewModalLabel">
                                <div class="modal-dialog" role="document">
                                    <div class="modal-content">
                                        <div class="addmodal-header">
                                            <h4 class="addmodal-title" id="addModalLabel">Review</h4>
                                        </div>
                                        <div class="addmodal-body">
                                            <form id="editId" method="post" role="form"  enctype="multipart/form-data">
                                                <input id="comment" type="text" style="margin-top: 20px;margin-bottom: 20px; width:100%;height: 100px;" name="comment" required="">
                                                <div>
                                                    <input type="button" class="btn btn-default" data-dismiss="modal" value="Cancel">
                                                    <input id="review-btn" class="btn btn-success" value="Submit">
                                                </div>
                                            </form>
                                        </div>
                                    </div>
                                </div>
                            </div>
                            <div class="card-body">
                                <table class="table card-text">
                                    <thead>
                                    <tr>
                                        <th scope="row">Product Name</th>
                                        <th>Picture</th>
                                        <th>Final Price</th>
                                        <th>Auction Type</th>
                                        <th>Write Review</th>
                                    </tr>
                                    </thead>
                                    <tbody id='tbody'>
                                    </tbody>
                                </table>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</section>
<?php
require_once "footer.php";
?>
<script src="../js/vendor/jquery-1.11.3.min.js"></script>
<script src="../js/bootstrap.min.js"></script>
<script>
    // Get all records of winning auctions.
    window.onload=function(){
        var user_id='<?php echo $_SESSION['User']['user_id'] ?>';
        $.ajax({
            url: 'Back-end/Manage_auction.php',
            data:{
                user_id:user_id,
                type:'win'
            },
            type: "post",
            dataType: 'json',
            success: function (data) {
                    var html = "";
                    data.forEach(function (data, index, array) {
                        console.log(data.comment_status);
                        if(data.comment_status=='Review'){
                        html += `
                        <tr>
                            <td scope="row"><a href="Single_product.php?product=${data.product_id}">${data.product_name}</a></td>
                            <td><img src= "${data.picture}" height="100vw" width="100vw" alt=""></td>
                            <td class="auction-price">￡${data.bidding_price}</td>
                            <td >${data.auction_type} </td>
                            <td><a style="text-decoration:underline;" data-type='review' data-id='${data.auction_id}' id="item_${data.auction_id}" data-toggle="modal" data-target="#reviewModal">Review</a>
                                </td>
                        </tr>`;
                                }
                        else{
                            html += `
                        <tr>
                            <td scope="row"><a href="Single_product.php?product=${data.product_id}">${data.product_name}</a></td>
                            <td><img src= "${data.picture}" height="100vw" width="100vw" alt=""></td>
                            <td class="auction-price">￡${data.bidding_price}</td>
                            <td >${data.auction_type} </td>
                            <td><a>Commented</a>
                                </td>
                        </tr>`;
                        }
                    });
                    $('#tbody').html(html);
            }



        })
    };
    // Get auction id.
    $('#tbody').click(function (e) {
        let type = $(e.target).attr("data-type");
        let id = $(e.target).attr("data-id");
        if (type === 'review' && id) {
             $('#editId').val(id);
        }
    })
    // Review auction and hide 'Review' bottom.
    $('#review-btn').click(function() {
        var user_id=$("#user_id").val();
        var auction_id = $("#editId").val();
        var comment = $("#comment").val();
        $.ajax({
            url: "Back-end/Manage_auction.php",
            data: {
                user_id:user_id,
                auction_id: auction_id,
                comment: comment,
                type: 'review'
            },
            type: "post",
            datatype: "json",
            success: function(data) {
                console.log(data);
                $('#reviewModal').modal('hide');
                window.location.reload();
            }
        })
    })

</script>
</body>
</html>