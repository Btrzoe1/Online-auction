<!doctype html>
<!--[if IE 9]> <html class="no-js ie9" lang="en"> <![endif]-->
<!--[if gt IE 9]><!--> <html class="no-js " lang="en"> <!--<![endif]-->
<head>
    <meta charset="utf-8">
    <meta http-equiv="x-ua-compatible" content="ie=edge">
    <title>Online Auction | E-auction</title>
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <link rel="stylesheet" href="css/jquery.fancybox.css">
    <link rel="stylesheet" href="css/nivo-slider.css">
    <link rel="stylesheet" href="css/owl.carousel.css">
    <link rel="stylesheet" href="css/font-awesome.min.css">
    <link rel="stylesheet" href="css/bootstrap.min.css">
    <link rel="stylesheet" href="css/style.css">
    <link rel="stylesheet" href="css/responsive.css">
    <script src="../js/vendor/html5shiv.min.js"></script>
    <script src="../js/vendor/respond.min.js"></script>
    <script src="../js/script.js"></script>
</head>
<body>
<header class="header-area">
    <?php
    require_once "header.php";
    ?>
    <!-- header-bottom start -->
    <div class="header-bottom">
        <div class="container">
            <div class="header-bottom-bg">
                <div class="row">
                    <!-- mainmenu start -->
                    <div class="col-xs-12 col-md-9">
                        <div class="mainmenu">
                            <nav>
                                <ul>
                                    <li class="active"><a href="index.php">Home</a><i class="fa fa-angle-down"></i></li>
                                    <li><a href="Shop_list.php?auction_type=English auction">English Auction</a></li>
                                    <li><a href="Shop_list.php?auction_type=Dutch auction">Dutch Auction</a></li>
                                    <li><a href="Shop_list.php?auction_type=Repeated second-bid auction">Repeated second-bid Auction</a></li>
                                    <li><a href="Contact_us.php">Contact Us</a></li>
                                </ul>
                            </nav>
                        </div>
                    </div>
                    <!-- mainmenu end -->
                </div>
                <!-- mobile menu start -->
                <div class="row">
                    <div class="col-sm-12 mobile-menu-area">
                        <div class="mobile-menu hidden-md hidden-lg" id="mob-menu">
                            <span class="mobile-menu-title">Menu</span>
                            <nav>
                                <ul>
                                    <li><a href="index.php">Home</a></li>
                                    <li><a href="#">Home Appliances</a>
                                        <ul>
                                            <li><a href="#">Kitchen Appliance</a></li>
                                            <li><a href="#">Bath fixtures</a></li>
                                            <li><a href="#">Accessories</a></li>
                                        </ul>
                                    </li>
                                    <li><a href="#">Electronics</a>
                                        <ul>
                                            <li><a href="#">Computer</a></li>
                                            <li><a href="#">Car Electronics</a></li>
                                            <li><a href="#">Accessories</a></li>
                                        </ul>
                                    </li>
                                    <li><a href="#">About Us</a></li>
                                    <li><a href="#">Contact Us</a></li>
                                </ul>
                            </nav>
                        </div>
                    </div>
                </div>
                <!-- mobile menu end -->
            </div>
        </div>
        <!-- header-bottom end -->
</header>
<center>
    <div class="contact-us-form">
        <div style="text-align: center;padding-top: 5%">
            <h2>Reset Password</h2>
        </div>
        <div style="text-align: center;padding-top: 3%">
            <form  onsubmit="return check_reset()" method="post">
                <div class="form-top">
                    <div style="text-align: center">
                        <label>Verification code: <sup>*ㅤ</sup></label><input name="code"  type="text"  required=""/>
                    </div>
                    <div style="text-align: center;padding-top: 3%">
                        <label>New password <sup>*ㅤㅤㅤ</sup></label><input id="new_password" name="new_password" type="password"  required=""/>
                    </div>
                    <div style="text-align: center;padding: 3%">
                        <label>Confirm password <sup>*ㅤ</sup></label><input id="confirm_newpassword" name="confirm_newpassword" type="password"  required=""/>
                    </div>
                    <label><sup>*ㅤ</sup> Required Fields</label> <input type="submit" class="add-tag-btn" name="reset-password" value="Submit">
                </div>
            </form>
        </div>
        <?php
        require_once '../Database/database.php';
        if (isset($_POST['reset-password'])) {
            // Get the post data from the submit form.
            $code = $_POST['code'];
            $password = $_POST['new_password'];
            $comfirm_password = $_POST['confirm_newpassword'];
            $Comparecode = $_SESSION['code'];
            $username = $_SESSION['username'];

            if (empty($code)) {
                die("Code not define!!");
            }
            if ($password != $comfirm_password) {
                echo "<script>alert('Reset fail, confirm password is not match the reset password');location.href='Reset_password.php';</script>";
            } else {

                // Hash the password.
                $salt = "62";
                $password_hash = $password . $username . $salt;
                $password_hash = hash('sha256', $password_hash);

                if ($code == $Comparecode) {
                    // if no error occured, continue ....
                    $statement = ResetPassword($username, $password_hash);
                    if ($statement) {
                        echo "<script>alert('Reset password success!');location.href='index.php';</script>";
                    } else {
                        echo "<script>alert('Reset fail, please try again');location.href='Reset_password.php';</script>";
                    }

                }else{
                    echo "<script>alert('Reset fail, please enter the correct verification code');location.href='Reset_password.php';</script>";
                }
            }
        }
        ?>
    </div>
</center>
<?php
require_once "footer.php";
?>
<script src="../js/vendor/jquery-1.11.3.min.js"></script>
<script src="../js/jqueryui.js"></script>
<script src="../js/jquery.meanmenu.js"></script>
<script src="../js/jquery.fancybox.js"></script>
<script src="../js/jquery.elevatezoom.js"></script>
<script src="../js/bootstrap.min.js"></script>
<script src="../js/owl.carousel.min.js"></script>
<script src="../js/jquery.nivo.slider.pack.js"></script>
<script src="../js/main.js"></script>
<script src="../js/main.js"></script>

</body>
</html>