<!doctype html>
<head>
    <meta charset="utf-8">
    <meta http-equiv="x-ua-compatible" content="ie=edge">
    <title>Online Auction | E-auction</title>
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <link rel="stylesheet" href="css/bootstrap.min.css">
    <link rel="stylesheet" href="css/style.css">
    <link rel="stylesheet" href="css/font-awesome.min.css">
    <link rel="stylesheet" href="css/responsive.css">
    <script src="../js/script.js"></script>
</head>
<body>
<header class="header-area">
    <?php
    require_once '../Database/database.php';
    require_once "header.php";
    ?>
</header>
<section class="main-content-area">
    <div class="container">
        <div class="row">
            <div class="col-xs-12 col-sm-12 col-md-3 col-lg-3">
                <div class="single-sidebar myaccount-info-area">
                    <h2>My Account</h2>
                    <div class="myaccount-info">
                        <ul>
                            <li><a href="My_account.php">My Details</a></li>
                            <li><a href="My_account.php">My Auctions</a></li>
                            <li class="active"><a href="Bidding_history.php">Bidding History</a></li>
                            <li ><a href="Win_auction.php">Win Auction</a></li>

                        </ul>
                    </div>
                </div>
            </div>
            <div class="col-xs-12 col-sm-12 col-md-9 col-lg-9">
                <div class="myaccount-dashboard-area cart-page-main-area">
                    <div class="sec-heading-area">
                        <input type="hidden" id="user_id" name="user_id" value="<?php echo $_SESSION['User']['user_id']?>">
                        <h2>My Auctions</h2>
                    </div>
                    <div class="myaccount-dashboard">
                        <p>You can view your history bidding. Click the product name or picture, you can jump to the page of this auction detail.
                        </p><p style="margin-bottom: 50px"><a class="btn btn-primary" href="Search_shop_list.php?product=&&category=All categories">Go to bid now</a></p>
                        <div class="acc-information">
                            <div class="card-body">
                                <table class="table card-text">
                                    <tr>
                                        <th scope="row">Auction Type</th>
                                        <th>Picture</th>
                                        <th>Product Name</th>
                                        <th>Bidding Price</th>
                                        <th>Bidding Time</th>
                                        <th>Auction Status</th>
                                    </tr>
                                    <tbody id='tbody'>
                                    </tbody>
                                </table>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</section>
<?php
require_once "footer.php";
?>
<script src="../js/vendor/jquery-1.11.3.min.js"></script>
<script src="../js/bootstrap.min.js"></script>
<script>
    // Show picture.
    document.getElementById('add_auction_picture').onchange = function() {
        var imgFile = this.files[0];
        var fr = new FileReader();
        fr.onload = function() {
            document.getElementById('image').getElementsByTagName('img')[0].src = fr.result;
        };
        fr.readAsDataURL(imgFile);
    };
</script>
<script>
    var web = {
        init: function () {
            var user_id =$("#user_id").val();
            var data = {
                user_id:user_id,
            }
            this.getAll(data);
            this.eleBind();
        },
        // Get all bidding history.
        getAll: function (data) {
            $.ajax({
                url: "Back-end/Manage_auction.php",
                type: "post",
                data: {
                    user_id: data.user_id,
                    type: 'bidding'
                },
                datatype: 'json',
                success: function (data) {
                    web.setData(data);
                },
            });
        },
        // Show all bidding history.
        setData: function (data) {
            var html = "";
            data.forEach(function (data, index, array) {
                html += `
                        <tr>
                            <td scope="row"> ${data.auction_type}</td>
                            <td><a href="Single_product.php?product=${data.product_id}"><img src= "${data.picture}" height="100vw" width="100vw" alt=""></a> </td>
                            <td><a href="Single_product.php?product=${data.product_id}"> ${data.product_name}</a></td>
                            <td>￡${data.bidding_price} </td>
                            <td>${data.bidding_time} </td>
                            <td>${data.result}</td>
                        </tr>`
            })
            $('#tbody').html(html);
        }
    }

    $(document).ready(function () {
        web.init()
    })

</script>
</body>
</html>